import { parse } from 'cookie'
import type { Options } from '../../../../typings/globals'
import type { FACET_CROSS_SELLING_MAP } from '../../utils/facets'
import { fetchAPI } from '../fetch'

import {
  BadRequestError,
  type CommercialAuthorizationResponse,
  type ICommercialAuthorizationByOrderId,
  type IProcessOrderAuthorization,
  type IUserOrderCancel,
  type QueryListUserOrdersArgs,
  type SavedCard,
  type StoreMarketingData,
  type UserOrder,
  type UserOrderCancel,
  type UserOrderListResult,
} from '../../../..'
import { isNotFoundError } from '../../../errors'
import type { GraphqlContext } from '../../index'
import { getWithAppKeyAndToken } from '../../utils/auth'
import type { Channel } from '../../utils/channel'
import {
  getAuthCookie,
  getStoreCookie,
  getUpdatedCookie,
  getWithCookie,
} from '../../utils/cookies'
import type { ContractResponse } from './Contract'
import type { Address, AddressInput } from './types/Address'
import type { Brand } from './types/Brand'
import type {
  ByLinkIdBrandResponse,
  ByLinkIdCategoryResponse,
  ByLinkIdCollectionResponse,
} from './types/ByLinkId'
import type { CategoryTree } from './types/CategoryTree'
import type { MasterDataResponse } from './types/Newsletter'
import type {
  ClientPreferencesData,
  OrderForm,
  OrderFormInputItem,
} from './types/OrderForm'
import type { PortalPagetype } from './types/Portal'
import type { PortalProduct } from './types/Product'
import type { Region, RegionInput } from './types/Region'
import type { SalesChannel } from './types/SalesChannel'
import type { Session } from './types/Session'
import type { AttachedContractsResponse } from './types/StoreFrontContracts'
import type { DeliveryMode, SelectedAddress } from './types/ShippingData'
import type {
  Simulation,
  SimulationArgs,
  SimulationOptions,
} from './types/Simulation'
import type {
  RecommendationResult,
  StartRecommendationSessionResult,
} from './types/RecommendationResult'
import type { ScopesByUnit, UnitResponse } from './types/Unit'
import type { VtexIdResponse } from './types/VtexId'
import type { QuoteListResult, ListUserQuotesArgs } from './types/Quote'

type ValueOf<T> = T extends Record<string, infer K> ? K : never

// Identifies the storefront origin to the Recommendations BFF, as required by
// the API (`x-vtex-rec-origin` header).
const REC_ORIGIN_SUFFIX = 'storefront/faststore.recommendation-shelf@v4'

export interface RecommendationArgs {
  campaignVrn: string
  userId?: string
  products?: string[]
  salesChannel?: string
  locale?: string
}

const BASE_INIT = {
  method: 'POST',
  headers: {
    'content-type': 'application/json',
  },
}

/**
 * Encode a by-linkid path for the category endpoint. Category link paths can be
 * multi-segment (e.g. "computer---software/eletronicos"); the Catalog endpoint
 * expects the "/" separators to stay literal so it can validate each level,
 * while each segment is individually URL-encoded. Running encodeURIComponent on
 * the whole string would turn "/" into "%2F" and break multi-segment resolution.
 */
const encodeLinkIdPath = (linkId: string): string =>
  linkId.split('/').map(encodeURIComponent).join('/')

/**
 * Build the fetch init that forwards a locale to a by-linkid endpoint. When no
 * locale is provided the endpoint falls back to the store's default registered
 * language (non-localized stores behavior).
 */
const byLinkIdInit = (locale?: string): RequestInit | undefined =>
  locale ? { headers: { 'Accept-Language': locale } } : undefined

const QUOTE_ISO_DATE = /^\d{4}-\d{2}-\d{2}$/
const QUOTE_VALID_STATUSES = new Set([
  'Draft',
  'Requested',
  'InReview',
  'Reviewed',
  'Approved',
  'Declined',
  'Expired',
  'ConvertedToCart',
  'ConvertedToOrder',
])

function validateListUserQuotesArgs({
  page,
  perPage,
  status,
  createdAtFrom,
  createdAtTo,
  expiresAtFrom,
  expiresAtTo,
}: ListUserQuotesArgs): void {
  if (page !== undefined && (!Number.isInteger(page) || page < 1)) {
    throw new Error(
      `listUserQuotes: invalid page "${page}" — must be a positive integer`
    )
  }
  if (perPage !== undefined && (!Number.isInteger(perPage) || perPage < 1)) {
    throw new Error(
      `listUserQuotes: invalid perPage "${perPage}" — must be a positive integer`
    )
  }
  for (const [field, value] of [
    ['createdAtFrom', createdAtFrom],
    ['createdAtTo', createdAtTo],
    ['expiresAtFrom', expiresAtFrom],
    ['expiresAtTo', expiresAtTo],
  ] as [string, string | undefined][]) {
    if (value && !QUOTE_ISO_DATE.test(value)) {
      throw new Error(
        `listUserQuotes: invalid ${field} "${value}" — must be YYYY-MM-DD`
      )
    }
  }
  if (status && status.length > 0) {
    const invalid = status.filter((s) => !QUOTE_VALID_STATUSES.has(s))
    if (invalid.length > 0) {
      throw new Error(
        `listUserQuotes: invalid status values: ${invalid.join(', ')}`
      )
    }
  }
}

function buildListUserQuotesParams({
  page,
  perPage,
  status,
  createdAtFrom,
  createdAtTo,
  expiresAtFrom,
  expiresAtTo,
  label,
}: ListUserQuotesArgs): URLSearchParams {
  const params = new URLSearchParams()

  if (page) params.append('pageNumber', page.toString())
  if (perPage) params.append('pageSize', perPage.toString())
  status?.forEach((s) => params.append('status', s))
  if (createdAtFrom) params.append('createdAtFrom', createdAtFrom)
  if (createdAtTo) params.append('createdAtTo', createdAtTo)
  if (expiresAtFrom) params.append('expiresAtFrom', expiresAtFrom)
  if (expiresAtTo) params.append('expiresAtTo', expiresAtTo)
  if (label?.trim()) params.append('label', label.trim())

  return params
}

export const VtexCommerce = (
  { account, environment, incrementAddress, subDomainPrefix }: Options,
  ctx: GraphqlContext
) => {
  const base = `https://${account}.${environment}.com.br`
  const storeCookies = getStoreCookie(ctx)
  const withCookie = getWithCookie(ctx)
  const withAppKeyAndToken = getWithAppKeyAndToken()

  const host =
    new Headers(ctx.headers).get('x-forwarded-host') ?? ctx.headers?.host ?? ''

  const selectedPrefix = subDomainPrefix
    ? subDomainPrefix
        .map((prefix) => prefix + '.')
        .find((prefix) => host.includes(prefix)) || ''
    : ''

  const forwardedHost = host.replace(selectedPrefix, '')

  // Recommendations BFF (`/api/recommend-bff/v2`) lives under the same account
  // host as the other commerce APIs, so it's exposed here as a namespace.
  const recommendationBase = `${base}/api/recommend-bff/v2`
  const recommendationHeaders: HeadersInit = withCookie({
    accept: 'application/json',
    'content-type': 'application/json',
    'x-vtex-rec-origin': `${account}/${REC_ORIGIN_SUFFIX}`,
  })
  const withBuyerAuthHeaders = (
    additionalHeaders: Record<string, string> = {}
  ): HeadersInit => {
    const authToken = getAuthCookie(getUpdatedCookie(ctx) ?? '', account)

    return withCookie({
      ...additionalHeaders,
      'X-FORWARDED-HOST': forwardedHost,
      ...(authToken ? { [`VtexIdclientAutCookie_${account}`]: authToken } : {}),
    })
  }

  return {
    catalog: {
      salesChannel: (sc: string): Promise<SalesChannel> =>
        fetchAPI(
          `${base}/api/catalog_system/pub/saleschannel/${sc}`,
          undefined,
          { storeCookies }
        ),
      brand: {
        list: (): Promise<Brand[]> =>
          fetchAPI(`${base}/api/catalog_system/pub/brand/list`, undefined, {
            storeCookies,
          }),
      },
      category: {
        tree: (depth = 3): Promise<CategoryTree[]> =>
          fetchAPI(
            `${base}/api/catalog_system/pub/category/tree/${depth}`,
            undefined,
            { storeCookies }
          ),
      },
      portal: {
        pagetype: (slug: string): Promise<PortalPagetype> =>
          fetchAPI(
            `${base}/api/catalog_system/pub/portal/pagetype/${slug}`,
            undefined,
            { storeCookies }
          ),
      },
      byLinkId: {
        // The by-linkid endpoints resolve a slug to a single catalog entity
        // (or 404 when there is no match). We surface a 404 as `null` so the
        // loader can cascade category → brand → collection.
        category: async (
          linkId: string,
          locale?: string
        ): Promise<ByLinkIdCategoryResponse | null> => {
          try {
            return await fetchAPI(
              `${base}/api/catalog_system/pub/category/by-linkid/${encodeLinkIdPath(linkId)}`,
              byLinkIdInit(locale)
            )
          } catch (error) {
            if (isNotFoundError(error)) return null
            throw error
          }
        },
        brand: async (
          linkId: string,
          locale?: string
        ): Promise<ByLinkIdBrandResponse | null> => {
          try {
            return await fetchAPI(
              `${base}/api/catalog_system/pub/brand/by-linkid/${encodeURIComponent(linkId)}`,
              byLinkIdInit(locale)
            )
          } catch (error) {
            if (isNotFoundError(error)) return null
            throw error
          }
        },
        collection: async (
          linkId: string,
          locale?: string
        ): Promise<ByLinkIdCollectionResponse | null> => {
          try {
            return await fetchAPI(
              `${base}/api/catalog_system/pub/collection/by-linkid/${encodeURIComponent(linkId)}`,
              byLinkIdInit(locale)
            )
          } catch (error) {
            if (isNotFoundError(error)) return null
            throw error
          }
        },
      },
      products: {
        crossselling: ({
          type,
          productId,
          groupByProduct = true,
        }: {
          type: ValueOf<typeof FACET_CROSS_SELLING_MAP>
          productId: string
          groupByProduct?: boolean
        }): Promise<PortalProduct[]> => {
          const params = new URLSearchParams({
            sc: ctx.storage.channel.salesChannel,
            groupByProduct: groupByProduct.toString(),
          })

          return fetchAPI(
            `${base}/api/catalog_system/pub/products/crossselling/${type}/${productId}?${params}`,
            undefined,
            { storeCookies }
          )
        },
      },
    },
    checkout: {
      simulation: (
        args: SimulationArgs,
        { salesChannel }: SimulationOptions = ctx.storage.channel
      ): Promise<Simulation> => {
        const params = new URLSearchParams({
          sc: salesChannel,
        })

        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/checkout/pub/orderForms/simulation?${params.toString()}`,
          {
            ...BASE_INIT,
            headers,
            body: JSON.stringify(args),
          },
          { storeCookies }
        )
      },
      shippingData: (
        {
          id,
          index,
          deliveryMode,
          selectedAddresses,
        }: {
          id: string
          index: number
          deliveryMode?: DeliveryMode | null
          selectedAddresses: SelectedAddress[]
        },
        setDeliveryWindow?: boolean
      ): Promise<OrderForm> => {
        const deliveryWindow = setDeliveryWindow
          ? {
              startDateUtc: deliveryMode?.deliveryWindow?.startDate,
              endDateUtc: deliveryMode?.deliveryWindow?.endDate,
            }
          : null

        const mappedBody = {
          logisticsInfo: Array.from({ length: index }, (_, itemIndex) => ({
            itemIndex,
            selectedDeliveryChannel: deliveryMode?.deliveryChannel || null,
            selectedSla: deliveryMode?.deliveryMethod || null,
            deliveryWindow: deliveryWindow,
          })),
          selectedAddresses: selectedAddresses,
          clearAddressIfPostalCodeNotFound: incrementAddress,
        }

        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/checkout/pub/orderForm/${id}/attachments/shippingData`,
          {
            ...BASE_INIT,
            headers,
            body: JSON.stringify(mappedBody),
          },
          { storeCookies }
        )
      },
      marketingData: ({
        id,
        marketingData,
      }: {
        id: string
        marketingData: StoreMarketingData
      }): Promise<OrderForm> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/checkout/pub/orderForm/${id}/attachments/marketingData`,
          {
            headers,
            body: JSON.stringify(marketingData),
            method: 'POST',
          },
          { storeCookies }
        )
      },
      clientPreferencesData: ({
        id,
        clientPreferencesData,
      }: {
        id: string
        clientPreferencesData: ClientPreferencesData
      }): Promise<OrderForm> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/checkout/pub/orderForm/${id}/attachments/clientPreferencesData`,
          {
            headers,
            body: JSON.stringify(clientPreferencesData),
            method: 'POST',
          },
          { storeCookies }
        )
      },
      orderForm: ({
        id,
        refreshOutdatedData = true,
        channel = ctx.storage.channel,
        preserveSalesChannel = false,
      }: {
        id?: string
        refreshOutdatedData?: boolean
        channel?: Required<Channel>
        /**
         * When true, omit the `sc` query param so Checkout keeps the cart's
         * current sales channel. Use this when the session SC may be stale
         * relative to an external flow (e.g. Quick Order) that already
         * advanced the orderForm.
         */
        preserveSalesChannel?: boolean
      }): Promise<OrderForm> => {
        const { salesChannel } = channel
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })
        const params = new URLSearchParams()
        // New carts (no id) always need an explicit SC. Existing carts may
        // omit it so Checkout does not recalculate under a stale session SC.
        if (!preserveSalesChannel || !id) {
          params.set('sc', salesChannel)
        }
        if (id) {
          params.set('refreshOutdatedData', refreshOutdatedData.toString())
        }
        const orderFormPath = id ? `/${id}` : ''
        // Always has at least `sc` (new cart) or `refreshOutdatedData` (existing).
        const url = `${base}/api/checkout/pub/orderForm${orderFormPath}?${params}`

        return fetchAPI(
          url,
          {
            ...BASE_INIT,
            headers,
            ...(id ? {} : { body: '{}' }),
          },
          { storeCookies }
        )
      },
      clearOrderFormMessages: ({ id }: { id: string }) => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/checkout/pub/orderForm/${id}/messages/clear`,
          {
            ...BASE_INIT,
            headers,
            body: '{}',
          }
        )
      },
      updateOrderFormItems: ({
        id,
        orderItems,
        allowOutdatedData = 'paymentData',
        salesChannel = ctx.storage.channel.salesChannel,
        shouldSplitItem = true,
      }: {
        id: string
        orderItems: OrderFormInputItem[]
        allowOutdatedData?: 'paymentData'
        salesChannel?: string
        shouldSplitItem?: boolean | null
      }): Promise<OrderForm> => {
        const params = new URLSearchParams({
          allowOutdatedData,
          sc: salesChannel,
        })

        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/checkout/pub/orderForm/${id}/items?${params}`,
          {
            headers,
            body: JSON.stringify({
              orderItems,
              noSplitItem: !shouldSplitItem,
            }),
            method: 'PATCH',
          },
          { storeCookies }
        )
      },
      setCustomData: ({
        id,
        appId,
        key,
        value,
      }: {
        id: string
        appId: string
        key: string
        value: string
      }): Promise<OrderForm> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/checkout/pub/orderForm/${id}/customData/${appId}/${key}`,
          {
            headers,
            body: JSON.stringify({ value }),
            method: 'PUT',
          }
        )
      },
      region: async ({
        postalCode,
        geoCoordinates,
        country,
        salesChannel,
      }: RegionInput): Promise<Region[]> => {
        const params = new URLSearchParams({
          country: country,
          sc: salesChannel ?? '',
        })

        postalCode
          ? params.append('postalCode', postalCode)
          : params.append(
              'geoCoordinates',
              `${geoCoordinates?.longitude};${geoCoordinates?.latitude}`
            )

        const url = `${base}/api/checkout/pub/regions/?${params.toString()}`
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          url,
          {
            headers,
          },
          { storeCookies }
        )
      },
      address: async ({
        postalCode,
        country,
      }: AddressInput): Promise<Address> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/checkout/pub/postal-code/${country}/${postalCode}`,
          {
            headers,
          },
          { storeCookies }
        )
      },
      cancelOrder: ({
        orderId,
        customerEmail,
        reason,
      }: IUserOrderCancel): Promise<UserOrderCancel> | undefined => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/checkout/pub/orders/${orderId}/user-cancel-request`,
          {
            method: 'POST',
            headers,
            body: JSON.stringify({
              customerEmail,
              reason,
            }),
          },
          {}
        )
      },
    },
    session: (search: string): Promise<Session> => {
      const params = new URLSearchParams(search)

      params.set(
        'items',
        'profile.id,profile.email,profile.firstName,profile.lastName,profile.phone,shopper.firstName,shopper.lastName,shopper.organizationManager,shopper.availableContracts,shopper.activeContractId,store.channel,store.countryCode,store.cultureInfo,store.currencyCode,store.currencySymbol,authentication.customerId,authentication.storeUserId,authentication.storeUserEmail,authentication.unitId,authentication.unitName,checkout.regionId,public.postalCode'
      )

      const headers: HeadersInit = withCookie({
        'content-type': 'application/json',
      })

      const sessionCookie = parse(ctx?.headers?.cookie ?? '')?.vtex_session

      return fetchAPI(
        `${base}/api/sessions?${params.toString()}`,
        {
          method: sessionCookie ? 'PATCH' : 'POST',
          headers,
          body: '{}',
        },
        { storeCookies }
      )
    },
    storeFront: {
      /**
       * Attached contracts of an Org Unit from the buyer-portal store-front BFF
       * (requires the `buyer-portal-graphql` IO app). Buyer cookie forwarded;
       * no app keys involved.
       */
      attachedContracts: (
        orgUnitId: string
      ): Promise<AttachedContractsResponse> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
        })

        return fetchAPI(
          `https://${account}.myvtex.com/_v/store-front/units/${encodeURIComponent(
            orgUnitId
          )}/contracts/attached?details=true`,
          { headers },
          { storeCookies }
        )
      },
    },
    subscribeToNewsletter: (data: {
      name: string
      email: string
    }): Promise<MasterDataResponse> => {
      return fetchAPI(
        `${base}/api/dataentities/NL/documents/`,
        {
          ...BASE_INIT,
          body: JSON.stringify({ ...data, isNewsletterOptIn: true }),
          method: 'PATCH',
        },
        { storeCookies }
      )
    },
    profile: {
      addresses: async (userId: string): Promise<Record<string, string>> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/profile-system/pvt/profiles/${userId}/addresses`,
          { headers },
          { storeCookies }
        )
      },
    },
    oms: {
      userOrder: ({ orderId }: { orderId: string }): Promise<UserOrder> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/oms/user/orders/${orderId}`,
          {
            method: 'GET',
            headers,
          },
          { storeCookies }
        )
      },
      listUserOrders: ({
        page,
        status,
        dateInitial,
        dateFinal,
        text,
        clientEmail,
        perPage,
        pendingMyApproval,
      }: QueryListUserOrdersArgs): Promise<UserOrderListResult> => {
        const params = new URLSearchParams()

        if (dateInitial) {
          const dateInitialTimestamp = new Date(dateInitial).setHours(
            0,
            0,
            0,
            0
          )
          dateInitial = new Date(dateInitialTimestamp).toISOString()
        }
        if (dateFinal) {
          const dateFinalTimestamp = new Date(dateFinal).setHours(
            23,
            59,
            59,
            999
          )
          dateFinal = new Date(dateFinalTimestamp).toISOString()
        }

        if (text) params.append('text', text)

        if (status && status.length > 0) {
          params.append('status', status.filter(Boolean).join(','))
        }

        if (dateInitial && dateFinal) {
          params.append(
            'creation_date',
            `creationDate:[${dateInitial} TO ${dateFinal}]`
          )
        } else if (dateInitial) {
          params.append('creation_date', `creationDate:[${dateInitial} TO *]`)
        } else if (dateFinal) {
          params.append('creation_date', `creationDate:[* TO ${dateFinal}]`)
        }

        if (clientEmail) params.append('clientEmail', clientEmail)
        if (page) params.append('page', page.toString())
        if (perPage) params.append('per_page', perPage.toString())
        if (pendingMyApproval) {
          params.append('my_pending_approvals', String(true))
        }

        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/oms/user/orders?${params.toString()}`,
          {
            method: 'GET',
            headers,
          },
          { storeCookies }
        )
      },
      getCommercialAuthorizationsByOrderId: ({
        orderId,
      }: ICommercialAuthorizationByOrderId): Promise<CommercialAuthorizationResponse> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/${account}/commercial-authorizations/order/${orderId}`,
          {
            method: 'GET',
            headers,
          },
          { storeCookies }
        )
      },
      processOrderAuthorization: async ({
        orderAuthorizationId,
        dimensionId,
        ruleId,
        approved,
      }: IProcessOrderAuthorization): Promise<CommercialAuthorizationResponse> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        const APPROVAL_SCORE = 100
        const REJECTION_SCORE = 0

        const body = {
          params: {
            ruleId,
            dimensionId,
            score: approved ? APPROVAL_SCORE : REJECTION_SCORE,
          },
        }

        return fetchAPI(
          `${base}/${account}/commercial-authorizations/${orderAuthorizationId}/callback`,
          {
            method: 'POST',
            headers,
            body: JSON.stringify(body),
          },
          { storeCookies }
        )
      },
    },
    savedCards: {
      listCreditCards: (): Promise<SavedCard[]> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/saved-cards/credit-card?an=${account}`,
          {
            method: 'GET',
            headers,
          },
          { storeCookies }
        )
      },
    },
    units: {
      getUnitByUserId: ({
        userId,
      }: { userId: string }): Promise<UnitResponse> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/units/v1/${userId}/unit`,
          {
            method: 'GET',
            headers,
          },
          {}
        )
      },
      getOrgUnitById: ({
        orgUnitId,
      }: { orgUnitId: string }): Promise<UnitResponse> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/units/v1/${orgUnitId}`,
          {
            method: 'GET',
            headers,
          },
          {}
        )
      },
      getScopesByOrgUnit: ({
        orgUnitId,
      }: { orgUnitId: string }): Promise<ScopesByUnit> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/units/v1/${orgUnitId}/scopes`,
          {
            method: 'GET',
            headers,
          },
          {}
        )
      },
    },
    licenseManager: {
      getUserById: ({
        userId,
      }: { userId: string }): Promise<{
        id: string
        name: string
        email: string
      }> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/license-manager/users/${userId}`,
          {
            method: 'GET',
            headers,
          },
          {}
        )
      },
      getUserByEmail: ({
        email,
      }: { email: string }): Promise<{
        id: string
        name: string
        email: string
      }> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/license-manager/pvt/users/${email}`,
          {
            method: 'GET',
            headers,
          },
          {}
        )
      },
      getUserRoles: ({
        userId,
      }: { userId: string }): Promise<{
        Email: string
        Roles: Array<{ Id: number; Name: string }>
      }> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/license-manager/storefront/users/${userId}/roles`,
          {
            method: 'GET',
            headers,
          },
          {}
        )
      },
      /**
       * Whether a License Manager resource key is granted to the user. The
       * endpoint resolves the user's roles into the resource key server-side,
       * so callers never have to match role names (which are account-
       * configurable). Responds with a bare boolean.
       */
      isResourceGranted: ({
        userId,
        resourceKey,
      }: { userId: string; resourceKey: string }): Promise<boolean> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/license-manager/storefront/bff/users/${userId}/resources/${resourceKey}/granted?an=${account}`,
          {
            method: 'GET',
            headers,
          },
          {}
        )
      },
    },
    masterData: {
      getContractById: ({
        contractId,
      }: { contractId: string }): Promise<ContractResponse> => {
        if (!contractId) {
          throw new BadRequestError('Missing contractId to fetch CL fields.')
        }

        const headers: HeadersInit = withBuyerAuthHeaders({
          Accept: 'application/json',
          'content-type': 'application/json',
        })

        return fetchAPI(
          `${base}/api/dataentities/CL/documents/${contractId}?_fields=_all`,
          {
            method: 'GET',
            headers,
          },
          {}
        )
      },
      getShopperById: ({
        userId,
      }: { userId: string }): Promise<
        Array<{
          firstName: string
          lastName: string
          email: string
          phone: string
        }>
      > => {
        if (!userId) {
          throw new BadRequestError('Missing userId to fetch shopper name.')
        }

        const headers: HeadersInit = withAppKeyAndToken({
          Accept: 'application/json',
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        const userIdNormalized = userId.replace(/-/g, '') // Normalize userId by removing hyphens

        return fetchAPI(
          `${base}/api/dataentities/shopper/search?_where=(userId=${userIdNormalized} OR userId=${userId})&_fields=_all&_schema=v1`,
          {
            method: 'GET',
            headers,
          },
          {}
        )
      },
    },
    quotes: {
      listUserQuotes: (args: ListUserQuotesArgs): Promise<QuoteListResult> => {
        validateListUserQuotesArgs(args)

        const params = buildListUserQuotesParams(args)

        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/quoting/quotes?${params.toString()}`,
          {
            method: 'GET',
            headers,
          },
          { storeCookies }
        )
      },
    },
    vtexid: {
      validate: (): Promise<VtexIdResponse> => {
        const headers: HeadersInit = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })
        // Read from the merged cookie set so the body token stays in sync with
        // the `cookie` header (both pull from request + storage updates).
        const token = getAuthCookie(getUpdatedCookie(ctx) ?? '', account)

        return fetchAPI(
          `${base}/api/vtexid/credential/validate`,
          {
            headers,
            body: JSON.stringify({ token }),
            method: 'POST',
          },
          { storeCookies }
        )
      },
    },
    orderEntry: {
      uploadFile: ({
        fileBuffer,
        fileName,
        mimeType,
      }: {
        fileBuffer: Buffer
        fileName: string
        mimeType: string
      }): Promise<{ objectKey: string }> => {
        const autHeaders = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })
        const boundary = `----FastStoreUploadBoundary${Date.now()}`
        const CRLF = '\r\n'

        const SAFE_MIME_PATTERN =
          /^[a-zA-Z0-9][a-zA-Z0-9!#$&\-.^_]*\/[a-zA-Z0-9][a-zA-Z0-9!#$&\-.^_+]*$/
        const safeMimeType = SAFE_MIME_PATTERN.test(mimeType)
          ? mimeType
          : 'application/octet-stream'
        const safeFileName = fileName.replaceAll(/[\r\n"]/g, '_')

        const headerPart = [
          `--${boundary}`,
          `Content-Disposition: form-data; name="file"; filename="${safeFileName}"`,
          `Content-Type: ${safeMimeType}`,
          '',
          '',
        ].join(CRLF)

        const footer = `${CRLF}--${boundary}--${CRLF}`

        const headerBytes = Buffer.from(headerPart)
        const footerBytes = Buffer.from(footer)
        const body = new Uint8Array(
          headerBytes.byteLength +
            fileBuffer.byteLength +
            footerBytes.byteLength
        )
        let offset = 0
        body.set(headerBytes, offset)
        offset += headerBytes.byteLength
        body.set(fileBuffer, offset)
        offset += fileBuffer.byteLength
        body.set(footerBytes, offset)

        return fetchAPI(
          `${base}/api/order-entry/upload?an=${account}`,
          {
            method: 'POST',
            headers: {
              ...autHeaders,
              'content-type': `multipart/form-data; boundary=${boundary}`,
            },
            body: body.buffer,
          },
          {}
        )
      },

      startOperation: ({
        objectKey,
        orderFormId,
        sessionToken,
      }: {
        objectKey: string
        orderFormId: string
        sessionToken?: string
      }): Promise<{ operationId: string }> => {
        const autHeaders = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })
        const body = JSON.stringify({
          objectKey,
          orderFormId,
          operation: 'CreateCart',
          ...(sessionToken ? { sessionToken } : {}),
        })

        return fetchAPI(
          `${base}/api/order-entry/operation?an=${account}`,
          {
            method: 'POST',
            headers: autHeaders,
            body,
          },
          {}
        )
      },

      getOperation: ({
        operationId,
      }: {
        operationId: string
      }): Promise<{
        status: string
        entityId: string
        message?: string
        missingItems?: Array<{
          itemId: string
          itemName?: string
          reason: string
        }>
      }> => {
        const autHeaders = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })

        return fetchAPI(
          `${base}/api/order-entry/operation/${operationId}?an=${account}`,
          {
            method: 'GET',
            headers: autHeaders,
          },
          {}
        )
      },

      createOrderForm: (): Promise<{ orderFormId: string }> => {
        const autHeaders = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })
        return fetchAPI(
          `${base}/api/checkout/pub/orderForm?sc=${ctx.storage.channel.salesChannel}`,
          {
            method: 'POST',
            headers: autHeaders,
            body: '{}',
          },
          {}
        )
      },

      getOrderFormItems: ({
        orderFormId,
      }: {
        orderFormId: string
      }): Promise<{ items: import('./types/OrderForm').OrderFormItem[] }> => {
        const autHeaders = withCookie({
          'content-type': 'application/json',
          'X-FORWARDED-HOST': forwardedHost,
        })
        return fetchAPI(
          `${base}/api/checkout/pub/orderForm/${orderFormId}`,
          {
            method: 'GET',
            headers: autHeaders,
          },
          {}
        )
      },
    },

    // Anonymous personalization / recommendations served by the VTEX
    // Recommendations BFF. The BFF replies with `vtex-rec-*` Set-Cookie headers
    // (forwarded to the browser via `ctx.storage.cookies`) and returns products
    // already hydrated in the Intelligent Search shape.
    recommendation: {
      recommendations: ({
        campaignVrn,
        userId,
        products = [],
        salesChannel,
        locale,
      }: RecommendationArgs): Promise<RecommendationResult> => {
        const params = new URLSearchParams({ an: account, campaignVrn })

        if (userId) {
          params.append('userId', userId)
        }

        if (products.length > 0) {
          params.append('products', products.join(','))
        }

        if (salesChannel) {
          params.append('salesChannel', salesChannel)
        }

        if (locale) {
          params.append('locale', locale)
        }

        return fetchAPI(
          `${recommendationBase}/recommendations?${params.toString()}`,
          { headers: recommendationHeaders },
          { storeCookies }
        )
      },

      startRecommendationSession: (): Promise<
        StartRecommendationSessionResult | undefined
      > => {
        const params = new URLSearchParams({ an: account })

        return fetchAPI(
          `${recommendationBase}/users/start-session?${params.toString()}`,
          { method: 'POST', headers: recommendationHeaders },
          { storeCookies }
        )
      },
    },
  }
}
