type ErrorType =
  | 'BadRequestError'
  | 'UnauthorizedError'
  | 'NotFoundError'
  | 'RedirectError'
  | 'ForbiddenError'
  | 'UnknownError'

interface Extension {
  type: ErrorType
  status: number
}

export class FastStoreError<T extends Extension = Extension> extends Error {
  constructor(
    public extensions: T,
    message?: string
  ) {
    super(message)
    this.name = 'FastStoreError'
  }
}

export class BadRequestError extends FastStoreError {
  constructor(message?: string) {
    super({ status: 400, type: 'BadRequestError' }, message)
  }
}

export class UnauthorizedError extends FastStoreError {
  constructor(message?: string) {
    super({ status: 401, type: 'UnauthorizedError' }, message)
  }
}

export class ForbiddenError extends FastStoreError {
  constructor(message?: string) {
    super({ status: 403, type: 'ForbiddenError' }, message)
  }
}

export class NotFoundError extends FastStoreError {
  constructor(message?: string) {
    super({ status: 404, type: 'NotFoundError' }, message)
  }
}

export const isFastStoreError = (error: any): error is FastStoreError =>
  error?.name === 'FastStoreError'

export const isBadRequestError = (error: any): error is BadRequestError =>
  error?.extensions?.type === 'BadRequestError'

export const isUnauthorizedError = (error: any): error is UnauthorizedError =>
  error?.extensions?.type === 'UnauthorizedError'

export const isForbiddenError = (error: any): error is ForbiddenError =>
  error?.extensions?.type === 'ForbiddenError'

export const isNotFoundError = (error: any): error is NotFoundError =>
  error?.extensions?.type === 'NotFoundError'
