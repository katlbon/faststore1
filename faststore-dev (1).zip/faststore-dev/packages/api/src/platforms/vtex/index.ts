import { mergeSchemas } from '@graphql-tools/schema'
import { type GraphQLSchema, isSchema } from 'graphql'
import { withDirectives } from '../../directives'
import authDirective from '../../directives/auth'
import cacheControlDirective from '../../directives/cacheControl'
import { ResolverTrace } from '../../observability/telemetry'
import type { FeatureFlags, Options, Resolver } from '../../typings/globals'
import type { Clients } from './clients'
import { getClients } from './clients'
import type { SearchArgs } from './clients/search'
import type { Loaders } from './loaders'
import { getLoaders } from './loaders'
import { getResolvers as nativeGetResolvers } from './resolvers'
import typeDefs from './typeDefs'
import type { Channel } from './utils/channel'
import ChannelMarshal from './utils/channel'

export interface GraphqlContext {
  /** Request scope ID */
  id: string
  clients: Clients
  loaders: Loaders
  /**
   * @description Storage updated at each request.
   *
   * Use this datastructure to store and share small values in the context.
   * Use it with caution since dependecy injection leads to a more complex code
   * */
  storage: {
    channel: Required<Channel>
    locale: string
    flags: FeatureFlags
    /** Project-supplied extension of the sort map. See `Options.customSortMap`. */
    customSortMap: Record<string, string>
    searchArgs?: Omit<SearchArgs, 'type'>
    cookies: Map<string, Record<string, string>>
    /**
     * Cached in-flight localized product lookups keyed by "productId:locale".
     * Stores the promise (not just the resolved value) so concurrent sibling
     * resolvers (slug validation, otherLocales, breadcrumb) dedupe to a single
     * Catalog Dataplane request within the same request.
     */
    productTranslationsCache?: Map<
      string,
      Promise<import('./clients/catalog').LocalizedProductEntry | null>
    >
  }
  headers: Record<string, string>
  account: string
  OTEL_ENABLED: boolean
  /** Discovery config passed from @faststore/core, including localization settings. */
  discoveryConfig?: Record<string, unknown>
}

export const GraphqlVtexContextFactory = async (options: Options) => {
  return (ctx: any): GraphqlContext => {
    ctx.storage = {
      channel: ChannelMarshal.parse(options.channel),
      flags: options.flags ?? {},
      locale: options.locale,
      customSortMap: options.customSortMap ?? {},
      cookies: new Map<string, Record<string, string>>(),
    }
    ctx.account = options.account
    ctx.OTEL_ENABLED = options.OTEL_ENABLED
    ctx.discoveryConfig = options.discoveryConfig
    // Build clients/loaders last: they capture `ctx` and read storage,
    // discoveryConfig, etc. at request time, so everything they may depend on
    // must already be assigned.
    ctx.clients = getClients(options, ctx)
    ctx.loaders = getLoaders(options, ctx)

    return ctx
  }
}

export type GraphqlResolver<S = any, V = any, R = any> = Resolver<
  GraphqlContext,
  S,
  V,
  R
>

export function getResolvers() {
  const resolvers = nativeGetResolvers()

  const finalResolvers: any = {}
  for (const [key, resolver] of Object.entries(resolvers)) {
    finalResolvers[key] = Object.fromEntries(
      Object.entries(resolver).map(([name, resolverFunction]) => {
        if (typeof resolverFunction !== 'function')
          return [name, resolverFunction]

        return [name, ResolverTrace(resolverFunction, `${key}(${name})`)]
      })
    )
  }

  return finalResolvers as typeof resolvers
}

export function GraphqlVtexSchema(mergeSchema?: GraphQLSchema) {
  const withCacheControl = withDirectives([
    cacheControlDirective,
    authDirective,
  ])

  const platformSchema = withCacheControl(getResolvers(), typeDefs)

  if (mergeSchema && isSchema(mergeSchema)) {
    return mergeSchemas({
      schemas: [platformSchema, mergeSchema],
    })
  }

  return platformSchema
}
