# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [4.10.1-dev.2](https://github.com/vtex/faststore/compare/v4.10.1-dev.1...v4.10.1-dev.2) (2026-10-27)

**Note:** Version bump only for package @faststore/cli

## [4.10.1-dev.1](https://github.com/vtex/faststore/compare/v4.10.1-dev.0...v4.10.1-dev.1) (2026-10-21)

**Note:** Version bump only for package @faststore/cli

## [4.10.1-dev.0](https://github.com/vtex/faststore/compare/v4.10.0...v4.10.1-dev.0) (2026-10-15)

**Note:** Version bump only for package @faststore/cli

# [4.10.0](https://github.com/vtex/faststore/compare/v4.10.0-dev.1...v4.10.0) (2026-10-15)

**Note:** Version bump only for package @faststore/cli

# [4.10.0-dev.1](https://github.com/vtex/faststore/compare/v4.10.0-dev.0...v4.10.0-dev.1) (2026-10-15)

**Note:** Version bump only for package @faststore/cli

# [4.10.0-dev.0](https://github.com/vtex/faststore/compare/v4.9.3-dev.2...v4.10.0-dev.0) (2026-10-08)

**Note:** Version bump only for package @faststore/cli

## [4.9.3-dev.2](https://github.com/vtex/faststore/compare/v4.9.3-dev.1...v4.9.3-dev.2) (2026-10-07)

**Note:** Version bump only for package @faststore/cli

## [4.9.3-dev.1](https://github.com/vtex/faststore/compare/v4.9.3-dev.0...v4.9.3-dev.1) (2026-10-06)

**Note:** Version bump only for package @faststore/cli

## [4.9.3-dev.0](https://github.com/vtex/faststore/compare/v4.9.1-dev.0...v4.9.3-dev.0) (2026-10-05)

**Note:** Version bump only for package @faststore/cli

## [4.9.2](https://github.com/vtex/faststore/compare/v4.9.1...v4.9.2) (2026-10-02)

**Note:** Version bump only for package @faststore/cli

## [4.9.1](https://github.com/vtex/faststore/compare/v4.9.0...v4.9.1) (2026-10-02)

**Note:** Version bump only for package @faststore/cli

# [4.9.0](https://github.com/vtex/faststore/compare/v4.9.0-dev.8...v4.9.0) (2026-09-30)

**Note:** Version bump only for package @faststore/cli

# [4.9.0-dev.8](https://github.com/vtex/faststore/compare/v4.9.0-dev.7...v4.9.0-dev.8) (2026-09-30)

**Note:** Version bump only for package @faststore/cli

# [4.9.0-dev.7](https://github.com/vtex/faststore/compare/v4.9.0-dev.6...v4.9.0-dev.7) (2026-09-29)

**Note:** Version bump only for package @faststore/cli

# [4.9.0-dev.6](https://github.com/vtex/faststore/compare/v4.9.0-dev.5...v4.9.0-dev.6) (2026-09-29)

### Bug Fixes

- normalize next bin path to forward slashes on Windows ([a1231d0](https://github.com/vtex/faststore/commit/a1231d0e9687ddf1324ad46f158412f0af7231bb))
- run the CLI test suite on Windows ([2182bdf](https://github.com/vtex/faststore/commit/2182bdf9690fd81713d268faeb17349ba2480a37))

# [4.9.0-dev.5](https://github.com/vtex/faststore/compare/v4.9.0-dev.4...v4.9.0-dev.5) (2026-09-29)

### Bug Fixes

- **cli:** satisfy biome formatting in generate.test.ts ([5fbfb69](https://github.com/vtex/faststore/commit/5fbfb6931d449734901c0240faa28452a73012ef)), closes [#3486](https://github.com/vtex/faststore/issues/3486)
- **core:** avoid Yarn Classic Windows tar-extraction bug dropping src/pages/s.tsx ([1d9cec9](https://github.com/vtex/faststore/commit/1d9cec97a7b1eee249ed4521fe8c103eee81921a))

# [4.9.0-dev.4](https://github.com/vtex/faststore/compare/v4.9.0-dev.3...v4.9.0-dev.4) (2026-09-28)

**Note:** Version bump only for package @faststore/cli

# [4.9.0-dev.3](https://github.com/vtex/faststore/compare/v4.9.0-dev.2...v4.9.0-dev.3) (2026-09-28)

### Bug Fixes

- refuse an unquotable next path inside the package.json builder ([#3503](https://github.com/vtex/faststore/issues/3503)) ([da85b46](https://github.com/vtex/faststore/commit/da85b4626e127c268a87c2e6533e012d4787670a)), closes [#3494](https://github.com/vtex/faststore/issues/3494)

# [4.9.0-dev.2](https://github.com/vtex/faststore/compare/v4.9.0-dev.1...v4.9.0-dev.2) (2026-09-28)

### Bug Fixes

- always quote the resolved next bin path ([#3494](https://github.com/vtex/faststore/issues/3494)) ([407a05a](https://github.com/vtex/faststore/commit/407a05aa7c1fe946c701d7c70097a13ed9bf5f68))

# [4.9.0-dev.1](https://github.com/vtex/faststore/compare/v4.9.0-dev.0...v4.9.0-dev.1) (2026-09-28)

### Bug Fixes

- resolve the store root by folder name when merging custom typeDefs ([#3502](https://github.com/vtex/faststore/issues/3502)) ([756baef](https://github.com/vtex/faststore/commit/756baefb20eccc97d35f9c40635dc757d7c73961))

# [4.9.0-dev.0](https://github.com/vtex/faststore/compare/v4.8.1-dev.3...v4.9.0-dev.0) (2026-09-24)

**Note:** Version bump only for package @faststore/cli

## [4.8.1-dev.3](https://github.com/vtex/faststore/compare/v4.8.1-dev.2...v4.8.1-dev.3) (2026-09-22)

**Note:** Version bump only for package @faststore/cli

## [4.8.1-dev.2](https://github.com/vtex/faststore/compare/v4.8.1-dev.1...v4.8.1-dev.2) (2026-09-21)

**Note:** Version bump only for package @faststore/cli

## [4.8.1-dev.1](https://github.com/vtex/faststore/compare/v4.8.1-dev.0...v4.8.1-dev.1) (2026-09-18)

**Note:** Version bump only for package @faststore/cli

## [4.8.1-dev.0](https://github.com/vtex/faststore/compare/v4.8.0...v4.8.1-dev.0) (2026-09-15)

**Note:** Version bump only for package @faststore/cli

# [4.8.0](https://github.com/vtex/faststore/compare/v4.7.0...v4.8.0) (2026-09-15)

### Features

- release 4.8.0 (graduate dev → main) ([#3488](https://github.com/vtex/faststore/issues/3488)) ([09ff84a](https://github.com/vtex/faststore/commit/09ff84aabe1f5a5a74fe52c191f37e5521dd8e9b)), closes [#3466](https://github.com/vtex/faststore/issues/3466) [#3481](https://github.com/vtex/faststore/issues/3481) [#3487](https://github.com/vtex/faststore/issues/3487) [#3453](https://github.com/vtex/faststore/issues/3453) [#3484](https://github.com/vtex/faststore/issues/3484) [#3482](https://github.com/vtex/faststore/issues/3482) [#3476](https://github.com/vtex/faststore/issues/3476) [#3477](https://github.com/vtex/faststore/issues/3477) [#3474](https://github.com/vtex/faststore/issues/3474) [#3422](https://github.com/vtex/faststore/issues/3422) [#3470](https://github.com/vtex/faststore/issues/3470)

# [4.8.0-dev.8](https://github.com/vtex/faststore/compare/v4.8.0-dev.7...v4.8.0-dev.8) (2026-09-14)

**Note:** Version bump only for package @faststore/cli

# [4.8.0-dev.7](https://github.com/vtex/faststore/compare/v4.8.0-dev.6...v4.8.0-dev.7) (2026-09-14)

**Note:** Version bump only for package @faststore/cli

# [4.8.0-dev.6](https://github.com/vtex/faststore/compare/v4.8.0-dev.5...v4.8.0-dev.6) (2026-09-11)

### Bug Fixes

- normalize outputFileTracingRoot to forward slashes on Windows ([#3484](https://github.com/vtex/faststore/issues/3484)) ([5c24f4a](https://github.com/vtex/faststore/commit/5c24f4a551853b1e93c898f4fa7d9729ceca44cc)), closes [#3483](https://github.com/vtex/faststore/issues/3483) [#3450](https://github.com/vtex/faststore/issues/3450) [#3483](https://github.com/vtex/faststore/issues/3483) [#3450](https://github.com/vtex/faststore/issues/3450) [#3450](https://github.com/vtex/faststore/issues/3450)

# [4.8.0-dev.5](https://github.com/vtex/faststore/compare/v4.8.0-dev.4...v4.8.0-dev.5) (2026-09-09)

### Bug Fixes

- forward contentSource.project as --storeId in cms-sync CP flow ([#3482](https://github.com/vtex/faststore/issues/3482)) ([c52365e](https://github.com/vtex/faststore/commit/c52365e74e00120961702ff3301f0f0d8fbe5449))

# [4.8.0-dev.4](https://github.com/vtex/faststore/compare/v4.8.0-dev.3...v4.8.0-dev.4) (2026-09-08)

### Bug Fixes

- generate GraphQL types when the project path contains spaces ([#3476](https://github.com/vtex/faststore/issues/3476)) ([b20c134](https://github.com/vtex/faststore/commit/b20c134eb5618f15e7e8328d6fa8ecc588d8e149)), closes [#3454](https://github.com/vtex/faststore/issues/3454) [#3454](https://github.com/vtex/faststore/issues/3454) [#3454](https://github.com/vtex/faststore/issues/3454) [#3454](https://github.com/vtex/faststore/issues/3454) [#3474](https://github.com/vtex/faststore/issues/3474) [#3475](https://github.com/vtex/faststore/issues/3475) [#3477](https://github.com/vtex/faststore/issues/3477)

# [4.8.0-dev.3](https://github.com/vtex/faststore/compare/v4.8.0-dev.2...v4.8.0-dev.3) (2026-09-08)

**Note:** Version bump only for package @faststore/cli

# [4.8.0-dev.2](https://github.com/vtex/faststore/compare/v4.8.0-dev.1...v4.8.0-dev.2) (2026-09-07)

**Note:** Version bump only for package @faststore/cli

# [4.8.0-dev.1](https://github.com/vtex/faststore/compare/v4.8.0-dev.0...v4.8.0-dev.1) (2026-09-03)

### Bug Fixes

- **cli:** keep store stories and Jest mocks out of the .faststore type-check ([2caafc1](https://github.com/vtex/faststore/commit/2caafc1112d5870c69a6673d7fd4d6b601404e3f)), closes [#3459](https://github.com/vtex/faststore/issues/3459)

# [4.8.0-dev.0](https://github.com/vtex/faststore/compare/v4.7.1-dev.2...v4.8.0-dev.0) (2026-09-03)

**Note:** Version bump only for package @faststore/cli

## [4.7.1-dev.2](https://github.com/vtex/faststore/compare/v4.7.1-dev.1...v4.7.1-dev.2) (2026-09-02)

### Bug Fixes

- keep package manager spawn off a shell and out of generate.ts ([4807b0a](https://github.com/vtex/faststore/commit/4807b0af08c214b58160a90246234e5242280224))
- refuse package manager substitution when installing dependencies ([1a06a13](https://github.com/vtex/faststore/commit/1a06a13dd7feafab89f4792831a863c786c7ded8)), closes [#3422](https://github.com/vtex/faststore/issues/3422)
- resolve the package manager against the target directory ([86f1732](https://github.com/vtex/faststore/commit/86f1732025d187d6c24899258642379872b7a8e7)), closes [#3422](https://github.com/vtex/faststore/issues/3422)
- stop forwarding unvalidated ni output to the shell in the CLI ([84eb880](https://github.com/vtex/faststore/commit/84eb88052aec6625d9deb5d535e7d182a08e1cbb))

## [4.7.1-dev.1](https://github.com/vtex/faststore/compare/v4.7.1-dev.0...v4.7.1-dev.1) (2026-09-01)

**Note:** Version bump only for package @faststore/cli

## [4.7.1-dev.0](https://github.com/vtex/faststore/compare/v4.7.0...v4.7.1-dev.0) (2026-08-31)

**Note:** Version bump only for package @faststore/cli

# [4.7.0](https://github.com/vtex/faststore/compare/v4.7.0-dev.9...v4.7.0) (2026-08-31)

**Note:** Version bump only for package @faststore/cli

# [4.7.0-dev.9](https://github.com/vtex/faststore/compare/v4.7.0-dev.8...v4.7.0-dev.9) (2026-08-31)

**Note:** Version bump only for package @faststore/cli

# [4.7.0-dev.8](https://github.com/vtex/faststore/compare/v4.7.0-dev.7...v4.7.0-dev.8) (2026-08-28)

### Bug Fixes

- **deps:** keep Yarn 1 from hoisting an incompatible @inquirer/type into the CLI ([6e5cfca](https://github.com/vtex/faststore/commit/6e5cfca1a8d029390bcc3b463a328d513481d457))
- keep core unit tests out of the storefront .faststore app ([c7fed58](https://github.com/vtex/faststore/commit/c7fed5822d24066efdd44ec86d69f61d0d309bd7))

# [4.7.0-dev.7](https://github.com/vtex/faststore/compare/v4.7.0-dev.6...v4.7.0-dev.7) (2026-08-28)

**Note:** Version bump only for package @faststore/cli

# [4.7.0-dev.6](https://github.com/vtex/faststore/compare/v4.7.0-dev.5...v4.7.0-dev.6) (2026-08-26)

**Note:** Version bump only for package @faststore/cli

# [4.7.0-dev.5](https://github.com/vtex/faststore/compare/v4.7.0-dev.4...v4.7.0-dev.5) (2026-08-25)

**Note:** Version bump only for package @faststore/cli

# [4.7.0-dev.4](https://github.com/vtex/faststore/compare/v4.7.0-dev.3...v4.7.0-dev.4) (2026-08-25)

**Note:** Version bump only for package @faststore/cli

# [4.7.0-dev.3](https://github.com/vtex/faststore/compare/v4.7.0-dev.2...v4.7.0-dev.3) (2026-08-25)

**Note:** Version bump only for package @faststore/cli

# [4.7.0-dev.2](https://github.com/vtex/faststore/compare/v4.7.0-dev.1...v4.7.0-dev.2) (2026-08-24)

**Note:** Version bump only for package @faststore/cli

# [4.7.0-dev.1](https://github.com/vtex/faststore/compare/v4.7.0-dev.0...v4.7.0-dev.1) (2026-08-24)

### Bug Fixes

- let Sonar recognise test files ([a7b966a](https://github.com/vtex/faststore/commit/a7b966a6e3eafe51fec687169781f2f78137c9e9))
- reference next by a path relative to .faststore ([372b66e](https://github.com/vtex/faststore/commit/372b66e328d73802f7cffcc05bae48e966eabc97))
- resolve the next binary from @faststore/core ([5478a4d](https://github.com/vtex/faststore/commit/5478a4dd24ffa7ab5d12907b945698cd04cb2f79))
- write the resolved next path with forward slashes ([95c07f9](https://github.com/vtex/faststore/commit/95c07f935037f419304eb792bebc6d6f4af983ac))

# [4.7.0-dev.0](https://github.com/vtex/faststore/compare/v4.6.1-dev.0...v4.7.0-dev.0) (2026-08-24)

**Note:** Version bump only for package @faststore/cli

## [4.6.1-dev.0](https://github.com/vtex/faststore/compare/v4.6.0...v4.6.1-dev.0) (2026-08-18)

**Note:** Version bump only for package @faststore/cli

# [4.6.0](https://github.com/vtex/faststore/compare/v4.6.0-dev.6...v4.6.0) (2026-08-18)

**Note:** Version bump only for package @faststore/cli

# [4.6.0-dev.6](https://github.com/vtex/faststore/compare/v4.6.0-dev.5...v4.6.0-dev.6) (2026-08-14)

### Bug Fixes

- resolve node_modules bins when running scripts inside .faststore ([#3440](https://github.com/vtex/faststore/issues/3440)) ([2bf174a](https://github.com/vtex/faststore/commit/2bf174a7295d106354d97d7ca2c161ed706cff9a)), closes [#3439](https://github.com/vtex/faststore/issues/3439) [#3419](https://github.com/vtex/faststore/issues/3419)

# [4.6.0-dev.5](https://github.com/vtex/faststore/compare/v4.6.0-dev.4...v4.6.0-dev.5) (2026-08-13)

**Note:** Version bump only for package @faststore/cli

# [4.6.0-dev.4](https://github.com/vtex/faststore/compare/v4.6.0-dev.3...v4.6.0-dev.4) (2026-08-12)

### Bug Fixes

- custom GraphQL typeDefs silently ignored on Windows ([#3419](https://github.com/vtex/faststore/issues/3419)) ([bdeb6a7](https://github.com/vtex/faststore/commit/bdeb6a757c44dda24b96cffc73d34652de165adf))

# [4.6.0-dev.3](https://github.com/vtex/faststore/compare/v4.6.0-dev.2...v4.6.0-dev.3) (2026-08-12)

**Note:** Version bump only for package @faststore/cli

# [4.6.0-dev.2](https://github.com/vtex/faststore/compare/v4.6.0-dev.1...v4.6.0-dev.2) (2026-08-12)

**Note:** Version bump only for package @faststore/cli

# [4.6.0-dev.1](https://github.com/vtex/faststore/compare/v4.6.0-dev.0...v4.6.0-dev.1) (2026-08-11)

## [4.5.1](https://github.com/vtex/faststore/compare/v4.5.1-dev.4...v4.5.1) (2026-08-11)

**Note:** Version bump only for package @faststore/cli

# [4.6.0-dev.0](https://github.com/vtex/faststore/compare/v4.5.1-dev.4...v4.6.0-dev.0) (2026-08-11)

**Note:** Version bump only for package @faststore/cli

## [4.5.1-dev.4](https://github.com/vtex/faststore/compare/v4.5.1-dev.3...v4.5.1-dev.4) (2026-08-10)

### Bug Fixes

- restore account, path, port arg order on cli dev command ([#3439](https://github.com/vtex/faststore/issues/3439)) ([b13e834](https://github.com/vtex/faststore/commit/b13e8341539fb8108c35a63f26218c4671d308f8)), closes [#3111](https://github.com/vtex/faststore/issues/3111) [#2491](https://github.com/vtex/faststore/issues/2491) [#2491](https://github.com/vtex/faststore/issues/2491) [#3111](https://github.com/vtex/faststore/issues/3111)

## [4.5.1-dev.3](https://github.com/vtex/faststore/compare/v4.5.1-dev.2...v4.5.1-dev.3) (2026-08-10)

## [4.5.1](https://github.com/vtex/faststore/compare/v4.5.1-dev.2...v4.5.1) (2026-08-11)

**Note:** Version bump only for package @faststore/cli

## [4.5.1-dev.2](https://github.com/vtex/faststore/compare/v4.5.1-dev.1...v4.5.1-dev.2) (2026-08-04)

**Note:** Version bump only for package @faststore/cli

## [4.5.1-dev.1](https://github.com/vtex/faststore/compare/v4.5.1-dev.0...v4.5.1-dev.1) (2026-08-04)

**Note:** Version bump only for package @faststore/cli

## [4.5.1-dev.0](https://github.com/vtex/faststore/compare/v4.5.0...v4.5.1-dev.0) (2026-08-03)

**Note:** Version bump only for package @faststore/cli

# [4.5.0](https://github.com/vtex/faststore/compare/v4.5.0-dev.7...v4.5.0) (2026-08-03)

**Note:** Version bump only for package @faststore/cli

# [4.5.0-dev.7](https://github.com/vtex/faststore/compare/v4.5.0-dev.6...v4.5.0-dev.7) (2026-08-03)

### Features

- CMS-driven custom My Account pages ([#3411](https://github.com/vtex/faststore/issues/3411)) ([e38b278](https://github.com/vtex/faststore/commit/e38b2780bb7386a8ef7b83a9e3de5956bf6de50e))

# [4.5.0-dev.6](https://github.com/vtex/faststore/compare/v4.5.0-dev.5...v4.5.0-dev.6) (2026-07-28)

**Note:** Version bump only for package @faststore/cli

# [4.5.0-dev.5](https://github.com/vtex/faststore/compare/v4.5.0-dev.4...v4.5.0-dev.5) (2026-07-27)

**Note:** Version bump only for package @faststore/cli

# [4.5.0-dev.4](https://github.com/vtex/faststore/compare/v4.5.0-dev.3...v4.5.0-dev.4) (2026-07-24)

**Note:** Version bump only for package @faststore/cli

# [4.5.0-dev.3](https://github.com/vtex/faststore/compare/v4.5.0-dev.2...v4.5.0-dev.3) (2026-07-22)

**Note:** Version bump only for package @faststore/cli

# [4.5.0-dev.2](https://github.com/vtex/faststore/compare/v4.5.0-dev.1...v4.5.0-dev.2) (2026-07-20)

### Features

- copy fonts and nested assets from public/ to build ([#3412](https://github.com/vtex/faststore/issues/3412)) ([ce07376](https://github.com/vtex/faststore/commit/ce07376a7c6aabf727746afdd7e486e3e6afaa76)), closes [#3332](https://github.com/vtex/faststore/issues/3332)

# [4.5.0-dev.1](https://github.com/vtex/faststore/compare/v4.5.0-dev.0...v4.5.0-dev.1) (2026-07-14)

**Note:** Version bump only for package @faststore/cli

# [4.5.0-dev.0](https://github.com/vtex/faststore/compare/v4.4.1-dev.0...v4.5.0-dev.0) (2026-07-03)

**Note:** Version bump only for package @faststore/cli

## [4.4.1-dev.0](https://github.com/vtex/faststore/compare/v4.4.0...v4.4.1-dev.0) (2026-07-02)

**Note:** Version bump only for package @faststore/cli

# [4.4.0](https://github.com/vtex/faststore/compare/v4.4.0-dev.6...v4.4.0) (2026-07-02)

**Note:** Version bump only for package @faststore/cli

# [4.4.0-dev.6](https://github.com/vtex/faststore/compare/v4.4.0-dev.5...v4.4.0-dev.6) (2026-07-02)

**Note:** Version bump only for package @faststore/cli

# [4.4.0-dev.5](https://github.com/vtex/faststore/compare/v4.4.0-dev.4...v4.4.0-dev.5) (2026-07-01)

### Features

- make cms-sync content-source aware (CMS + CP) ([#3406](https://github.com/vtex/faststore/issues/3406)) ([8e4e4ca](https://github.com/vtex/faststore/commit/8e4e4cab61b6e6fec05b8ae014e4ed2298028b92)), closes [#5c1a1](https://github.com/vtex/faststore/issues/5c1a1) [#ff6b6](https://github.com/vtex/faststore/issues/ff6b6) [#3a0d0](https://github.com/vtex/faststore/issues/3a0d0) [#ff6b6](https://github.com/vtex/faststore/issues/ff6b6) [#10391](https://github.com/vtex/faststore/issues/10391) [#3ddc84](https://github.com/vtex/faststore/issues/3ddc84) [#1](https://github.com/vtex/faststore/issues/1) [#14](https://github.com/vtex/faststore/issues/14) [#15](https://github.com/vtex/faststore/issues/15) [#18](https://github.com/vtex/faststore/issues/18)

# [4.4.0-dev.4](https://github.com/vtex/faststore/compare/v4.4.0-dev.3...v4.4.0-dev.4) (2026-06-30)

**Note:** Version bump only for package @faststore/cli

# [4.4.0-dev.3](https://github.com/vtex/faststore/compare/v4.4.0-dev.2...v4.4.0-dev.3) (2026-06-29)

**Note:** Version bump only for package @faststore/cli

# [4.4.0-dev.2](https://github.com/vtex/faststore/compare/v4.4.0-dev.1...v4.4.0-dev.2) (2026-06-25)

**Note:** Version bump only for package @faststore/cli

# [4.4.0-dev.1](https://github.com/vtex/faststore/compare/v4.4.0-dev.0...v4.4.0-dev.1) (2026-06-24)

### Features

- my account cms ([#3354](https://github.com/vtex/faststore/issues/3354)) ([2400c45](https://github.com/vtex/faststore/commit/2400c4537e58d5f4093d8c10275443a0876f62f8))

# [4.4.0-dev.0](https://github.com/vtex/faststore/compare/v4.3.1-dev.0...v4.4.0-dev.0) (2026-06-19)

**Note:** Version bump only for package @faststore/cli

## [4.3.1-dev.0](https://github.com/vtex/faststore/compare/v4.3.0-dev.8...v4.3.1-dev.0) (2026-06-17)

**Note:** Version bump only for package @faststore/cli

# [4.3.0](https://github.com/vtex/faststore/compare/v4.2.0...v4.3.0) (2026-06-17)

### Bug Fixes

- fix vtex message ([e9b2105](https://github.com/vtex/faststore/commit/e9b21055dba0ba24658eda1511056ef29d6b0274))

### Features

- graduate v4.3.0 ([#3396](https://github.com/vtex/faststore/issues/3396)) ([b489766](https://github.com/vtex/faststore/commit/b4897664c7826dcd59bfde7c3599c93259d4d11f)), closes [#3276](https://github.com/vtex/faststore/issues/3276) [#3334](https://github.com/vtex/faststore/issues/3334) [#3386](https://github.com/vtex/faststore/issues/3386) [#3380](https://github.com/vtex/faststore/issues/3380) [#3394](https://github.com/vtex/faststore/issues/3394) [#3395](https://github.com/vtex/faststore/issues/3395) [#3381](https://github.com/vtex/faststore/issues/3381) [#3379](https://github.com/vtex/faststore/issues/3379) [#3375](https://github.com/vtex/faststore/issues/3375)

# [4.3.0-dev.8](https://github.com/vtex/faststore/compare/v4.3.0-dev.7...v4.3.0-dev.8) (2026-06-17)

### Features

- Password Protection (v4) ([#3276](https://github.com/vtex/faststore/issues/3276)) ([575f162](https://github.com/vtex/faststore/commit/575f162f6ec6fda9d3134ab61f673a897dcc2f56))

# [4.3.0-dev.7](https://github.com/vtex/faststore/compare/v4.3.0-dev.6...v4.3.0-dev.7) (2026-06-17)

**Note:** Version bump only for package @faststore/cli

# [4.3.0-dev.6](https://github.com/vtex/faststore/compare/v4.3.0-dev.5...v4.3.0-dev.6) (2026-06-17)

**Note:** Version bump only for package @faststore/cli

# [4.3.0-dev.5](https://github.com/vtex/faststore/compare/v4.3.0-dev.4...v4.3.0-dev.5) (2026-06-16)

**Note:** Version bump only for package @faststore/cli

# [4.3.0-dev.4](https://github.com/vtex/faststore/compare/v4.3.0-dev.3...v4.3.0-dev.4) (2026-06-15)

**Note:** Version bump only for package @faststore/cli

# [4.3.0-dev.3](https://github.com/vtex/faststore/compare/v4.3.0-dev.2...v4.3.0-dev.3) (2026-06-15)

**Note:** Version bump only for package @faststore/cli

# [4.3.0-dev.2](https://github.com/vtex/faststore/compare/v4.3.0-dev.1...v4.3.0-dev.2) (2026-06-10)

**Note:** Version bump only for package @faststore/cli

# [4.3.0-dev.1](https://github.com/vtex/faststore/compare/v4.3.0-dev.0...v4.3.0-dev.1) (2026-06-08)

**Note:** Version bump only for package @faststore/cli

# [4.3.0-dev.0](https://github.com/vtex/faststore/compare/v4.2.0...v4.3.0-dev.0) (2026-06-01)

**Note:** Version bump only for package @faststore/cli

# [4.2.0](https://github.com/vtex/faststore/compare/v4.1.2...v4.2.0) (2026-06-01)

### Features

- release version 2026 06 01 ([#3370](https://github.com/vtex/faststore/issues/3370)) ([61fcbdf](https://github.com/vtex/faststore/commit/61fcbdfde6a8bb6eb6f0f00d9b5ac3f28421dbf3))
- Release version 2026 06 01 1 ([#3373](https://github.com/vtex/faststore/issues/3373)) ([df3cb4d](https://github.com/vtex/faststore/commit/df3cb4de391a252831dd28cf3bd46f7493bea742))

# [4.2.0-dev.5](https://github.com/vtex/faststore/compare/v4.2.0-dev.4...v4.2.0-dev.5) (2026-06-01)

**Note:** Version bump only for package @faststore/cli

# 4.2.0-dev.4 (2026-06-01)

### Bug Fixes

- preview pnpm pack ([#3367](https://github.com/vtex/faststore/issues/3367)) ([186579c](https://github.com/vtex/faststore/commit/186579c4cca44e4d21c25068f075c0fbb6a56d96))

# [4.2.0-dev.3](https://github.com/vtex/faststore/compare/v4.2.0-dev.2...v4.2.0-dev.3) (2026-06-01)

**Note:** Version bump only for package @faststore/cli

# [4.2.0-dev.2](https://github.com/vtex/faststore/compare/v4.2.0-dev.1...v4.2.0-dev.2) (2026-06-01)

### Bug Fixes

- strip packageManager from generated .faststore/package.json ([#3335](https://github.com/vtex/faststore/issues/3335)) ([5a2b793](https://github.com/vtex/faststore/commit/5a2b793c4b12f986c72e801fb03809b568a99344))

# 4.2.0-dev.1 (2026-06-01)

### Bug Fixes

- createNextJSPages throwing preventing copy of store discovery-co… ([#3356](https://github.com/vtex/faststore/issues/3356)) ([cf318ab](https://github.com/vtex/faststore/commit/cf318abfecf4c6497d40bfe58203acc90b199696))

# [4.2.0-dev.0](https://github.com/vtex/faststore/compare/v4.1.2-dev.8...v4.2.0-dev.0) (2026-06-01)

**Note:** Version bump only for package @faststore/cli

## [4.1.2-dev.8](https://github.com/vtex/faststore/compare/v4.1.2-dev.7...v4.1.2-dev.8) (2026-05-28)

**Note:** Version bump only for package @faststore/cli

## [4.1.2-dev.7](https://github.com/vtex/faststore/compare/v4.1.2-dev.6...v4.1.2-dev.7) (2026-05-28)

**Note:** Version bump only for package @faststore/cli

## [4.1.2-dev.6](https://github.com/vtex/faststore/compare/v4.1.2-dev.5...v4.1.2-dev.6) (2026-05-27)

**Note:** Version bump only for package @faststore/cli

## [4.1.2-dev.5](https://github.com/vtex/faststore/compare/v4.1.2-dev.4...v4.1.2-dev.5) (2026-05-21)

### Bug Fixes

- url resolution in windows ([#3337](https://github.com/vtex/faststore/issues/3337)) ([2476091](https://github.com/vtex/faststore/commit/24760916bdcfc73c7d4ef7f92829976d4f1f97d6))

## [4.1.2-dev.4](https://github.com/vtex/faststore/compare/v4.1.2-dev.3...v4.1.2-dev.4) (2026-05-20)

**Note:** Version bump only for package @faststore/cli

## [4.1.2-dev.3](https://github.com/vtex/faststore/compare/v4.1.2-dev.2...v4.1.2-dev.3) (2026-05-20)

**Note:** Version bump only for package @faststore/cli

## [4.1.2-dev.2](https://github.com/vtex/faststore/compare/v4.1.2-dev.1...v4.1.2-dev.2) (2026-05-19)

### Bug Fixes

- generate plugin themes with Sass [@use](https://github.com/use) instead of [@import](https://github.com/import) ([#3283](https://github.com/vtex/faststore/issues/3283)) ([22c0e74](https://github.com/vtex/faststore/commit/22c0e74d7d3b3714a5e9b6917d7cc60aa36eeb69))

## 4.1.2-dev.1 (2026-05-19)

**Note:** Version bump only for package @faststore/cli

## 4.1.2-dev.0 (2026-05-15)

**Note:** Version bump only for package @faststore/cli

## 4.1.1 (2026-05-15)

### Bug Fixes

- graduate version 4.1.1 ([#3331](https://github.com/vtex/faststore/issues/3331)) ([c26d990](https://github.com/vtex/faststore/commit/c26d990010d8643ceb2ed95ab1737f4eca80e240))
- version bump 4.1.1 ([#3329](https://github.com/vtex/faststore/issues/3329)) ([59345b3](https://github.com/vtex/faststore/commit/59345b3584c3ec5fc6f532e1b5c1bcce9c5c5b97)), closes [#3318](https://github.com/vtex/faststore/issues/3318) [#3312](https://github.com/vtex/faststore/issues/3312) [#3319](https://github.com/vtex/faststore/issues/3319) [#3327](https://github.com/vtex/faststore/issues/3327) [#3320](https://github.com/vtex/faststore/issues/3320) [#3314](https://github.com/vtex/faststore/issues/3314) [#3317](https://github.com/vtex/faststore/issues/3317)

## [4.1.1-dev.1](https://github.com/vtex/faststore/compare/v4.1.0-dev.11...v4.1.1-dev.1) (2026-05-15)

**Note:** Version bump only for package @faststore/cli

# 4.1.0-dev.11 (2026-05-15)

**Note:** Version bump only for package @faststore/cli

# [4.1.0-dev.10](https://github.com/vtex/faststore/compare/v4.1.0...v4.1.0-dev.10) (2026-05-15)

**Note:** Version bump only for package @faststore/cli

# [4.1.0-dev.9](https://github.com/vtex/faststore/compare/v4.1.0-dev.8...v4.1.0-dev.9) (2026-05-15)

**Note:** Version bump only for package @faststore/cli

# [4.1.0-dev.8](https://github.com/vtex/faststore/compare/v4.1.0-dev.7...v4.1.0-dev.8) (2026-05-15)

**Note:** Version bump only for package @faststore/cli

# [4.1.0-dev.7](https://github.com/vtex/faststore/compare/v4.1.0-dev.6...v4.1.0-dev.7) (2026-05-15)

**Note:** Version bump only for package @faststore/cli

# [4.1.0-dev.6](https://github.com/vtex/faststore/compare/v4.1.0-dev.5...v4.1.0-dev.6) (2026-05-14)

**Note:** Version bump only for package @faststore/cli

# [4.1.0-dev.5](https://github.com/vtex/faststore/compare/v4.1.0-dev.4...v4.1.0-dev.5) (2026-05-14)

**Note:** Version bump only for package @faststore/cli

# [4.1.0-dev.4](https://github.com/vtex/faststore/compare/v4.1.0-dev.3...v4.1.0-dev.4) (2026-05-13)

**Note:** Version bump only for package @faststore/cli

# [4.1.0-dev.3](https://github.com/vtex/faststore/compare/v4.1.0-dev.2...v4.1.0-dev.3) (2026-05-13)

**Note:** Version bump only for package @faststore/cli

# [4.1.0-dev.2](https://github.com/vtex/faststore/compare/v4.1.0-dev.1...v4.1.0-dev.2) (2026-05-12)

**Note:** Version bump only for package @faststore/cli

# 4.1.0 (2026-05-11)

### Features

- version bump 4.1.0 ([#3310](https://github.com/vtex/faststore/issues/3310)) ([1ea7bac](https://github.com/vtex/faststore/commit/1ea7bac649d783e50a9e79f8fe412009ae4a87f7)), closes [#3309](https://github.com/vtex/faststore/issues/3309) [#3308](https://github.com/vtex/faststore/issues/3308) [#3306](https://github.com/vtex/faststore/issues/3306) [#3304](https://github.com/vtex/faststore/issues/3304) [#3301](https://github.com/vtex/faststore/issues/3301)

# [4.1.0-dev.1](https://github.com/vtex/faststore/compare/v4.1.0-dev.0...v4.1.0-dev.1) (2026-05-11)

**Note:** Version bump only for package @faststore/cli

# [4.1.0-dev.0](https://github.com/vtex/faststore/compare/v4.0.1-dev.2...v4.1.0-dev.0) (2026-05-11)

**Note:** Version bump only for package @faststore/cli

## [4.0.1-dev.2](https://github.com/vtex/faststore/compare/v4.0.1-dev.1...v4.0.1-dev.2) (2026-05-11)

**Note:** Version bump only for package @faststore/cli

## [4.0.1-dev.1](https://github.com/vtex/faststore/compare/v4.0.1-dev.0...v4.0.1-dev.1) (2026-05-07)

**Note:** Version bump only for package @faststore/cli

## [4.0.1-dev.0](https://github.com/vtex/faststore/compare/v4.0.0...v4.0.1-dev.0) (2026-05-07)

# 4.0.0-dev.4 (2026-05-07)

**Note:** Version bump only for package @faststore/cli

# [4.0.0](https://github.com/vtex/faststore/compare/v3.99.0...v4.0.0) (2026-05-07)

### Features

- FastStore v4 ([#3302](https://github.com/vtex/faststore/issues/3302)) ([c7ca1a2](https://github.com/vtex/faststore/commit/c7ca1a2a9a6161bdf30e33a965ecf2fda9ef3fbf))

# [4.0.0-dev.4](https://github.com/vtex/faststore/compare/v4.0.0-dev.3...v4.0.0-dev.4) (2026-05-07)

**Note:** Version bump only for package @faststore/cli

# [4.0.0-dev.3](https://github.com/vtex/faststore/compare/v4.0.0-dev.2...v4.0.0-dev.3) (2026-05-07)

**Note:** Version bump only for package @faststore/cli

# [4.0.0-dev.2](https://github.com/vtex/faststore/compare/v4.0.0-dev.1...v4.0.0-dev.2) (2026-05-07)

**Note:** Version bump only for package @faststore/cli

# [4.0.0-dev.1](https://github.com/vtex/faststore/compare/v4.0.0-dev.0...v4.0.0-dev.1) (2026-05-07)

**Note:** Version bump only for package @faststore/cli

# 3.99.0-dev.9 (2026-05-07)

### Bug Fixes

- release command ([e912b5e](https://github.com/vtex/faststore/commit/e912b5e10cf61e65f24502fb077c06799009da61))

# 3.99.0-dev.8 (2026-05-04)

**Note:** Version bump only for package @faststore/cli

# [3.99.0-dev.7](https://github.com/vtex/faststore/compare/v3.99.0-dev.6...v3.99.0-dev.7) (2026-05-04)

**Note:** Version bump only for package @faststore/cli

# 3.99.0-dev.6 (2026-05-04)

**Note:** Version bump only for package @faststore/cli

# 3.99.0-dev.5 (2026-05-04)

### Bug Fixes

- Enhance session validation logic to skip token refresh in local … ([#3285](https://github.com/vtex/faststore/issues/3285)) ([41a330a](https://github.com/vtex/faststore/commit/41a330a9704a29369141e6e78b1f6d01e5a2e1a5))

# 3.99.0-dev.4 (2026-04-28)

**Note:** Version bump only for package @faststore/cli

# 3.99.0-dev.3 (2026-04-23)

### Features

- add isGift field to StoreOffer type and resolvers - SFS-3040 ([#3220](https://github.com/vtex/faststore/issues/3220)) ([e10fc92](https://github.com/vtex/faststore/commit/e10fc92633a5296a5b03286028d31d9c280561c6))

# [3.99.0-dev.2](https://github.com/vtex/faststore/compare/v3.99.0-dev.1...v3.99.0-dev.2) (2026-04-21)

**Note:** Version bump only for package @faststore/cli

# [3.99.0-dev.1](https://github.com/vtex/faststore/compare/v3.99.0-dev.0...v3.99.0-dev.1) (2026-04-15)

**Note:** Version bump only for package @faststore/cli

# [3.99.0-dev.0](https://github.com/vtex/faststore/compare/v3.98.1-dev.0...v3.99.0-dev.0) (2026-03-31)

**Note:** Version bump only for package @faststore/cli

## [3.98.4](https://github.com/vtex/faststore/compare/v3.98.3...v3.98.4) (2026-04-15)

**Note:** Version bump only for package @faststore/cli

## [3.98.3](https://github.com/vtex/faststore/compare/v3.98.2...v3.98.3) (2026-04-09)

**Note:** Version bump only for package @faststore/cli

## [3.98.2](https://github.com/vtex/faststore/compare/v3.98.1...v3.98.2) (2026-04-09)

**Note:** Version bump only for package @faststore/cli

## [3.98.1](https://github.com/vtex/faststore/compare/v3.98.0...v3.98.1) (2026-04-07)

**Note:** Version bump only for package @faststore/cli

## [3.98.1-dev.0](https://github.com/vtex/faststore/compare/v3.98.0-dev.10...v3.98.1-dev.0) (2026-03-27)

# 3.98.0 (2026-03-27)

### Bug Fixes

- Set `after` attribute as string instead of integer ([#3245](https://github.com/vtex/faststore/issues/3245)) ([c40d3fc](https://github.com/vtex/faststore/commit/c40d3fcf0018099cc067bb7082757535ca9839b0))

### Features

- version 2026 03 27 ([#3251](https://github.com/vtex/faststore/issues/3251)) ([f330a43](https://github.com/vtex/faststore/commit/f330a43661567ad8edb468acd3416bb7ffacd8b6))

# [3.98.0-dev.10](https://github.com/vtex/faststore/compare/v3.98.0-dev.9...v3.98.0-dev.10) (2026-03-27)

**Note:** Version bump only for package @faststore/cli

# [3.98.0-dev.9](https://github.com/vtex/faststore/compare/v3.98.0-dev.8...v3.98.0-dev.9) (2026-03-27)

**Note:** Version bump only for package @faststore/cli

# [3.98.0-dev.8](https://github.com/vtex/faststore/compare/v3.98.0-dev.7...v3.98.0-dev.8) (2026-03-27)

### Features

- Add Quick Order Full Feature ([#3197](https://github.com/vtex/faststore/issues/3197)) ([f5518d7](https://github.com/vtex/faststore/commit/f5518d7f205dccad99b6ea0a127fd09cf77d1edb))

# [3.98.0-dev.7](https://github.com/vtex/faststore/compare/v3.98.0-dev.6...v3.98.0-dev.7) (2026-03-26)

**Note:** Version bump only for package @faststore/cli

# [3.98.0-dev.6](https://github.com/vtex/faststore/compare/v3.98.0-dev.5...v3.98.0-dev.6) (2026-03-24)

**Note:** Version bump only for package @faststore/cli

# [3.98.0-dev.5](https://github.com/vtex/faststore/compare/v3.98.0-dev.4...v3.98.0-dev.5) (2026-03-24)

**Note:** Version bump only for package @faststore/cli

# [3.98.0-dev.4](https://github.com/vtex/faststore/compare/v3.98.0-dev.3...v3.98.0-dev.4) (2026-03-23)

**Note:** Version bump only for package @faststore/cli

# [3.98.0-dev.3](https://github.com/vtex/faststore/compare/v3.98.0-dev.2...v3.98.0-dev.3) (2026-03-12)

**Note:** Version bump only for package @faststore/cli

# [3.98.0-dev.2](https://github.com/vtex/faststore/compare/v3.98.0-dev.1...v3.98.0-dev.2) (2026-03-03)

**Note:** Version bump only for package @faststore/cli

# 3.98.0-dev.1 (2026-02-24)

**Note:** Version bump only for package @faststore/cli

# [3.98.0-dev.0](https://github.com/vtex/faststore/compare/v3.97.0-dev.6...v3.98.0-dev.0) (2026-02-24)

### Features

- release version 20260224 ([#3225](https://github.com/vtex/faststore/issues/3225)) ([7a52516](https://github.com/vtex/faststore/commit/7a5251677a8f67066a2e060191b896ae6d0b0d9a))

## [3.97.1](https://github.com/vtex/faststore/compare/v3.97.0...v3.97.1) (2026-02-24)

**Note:** Version bump only for package @faststore/cli

# [3.97.0](https://github.com/vtex/faststore/compare/v3.96.5...v3.97.0) (2026-02-03)

**Note:** Version bump only for package @faststore/cli

# [3.97.0-dev.6](https://github.com/vtex/faststore/compare/v3.97.0-dev.5...v3.97.0-dev.6) (2026-02-19)

**Note:** Version bump only for package @faststore/cli

# [3.97.0-dev.5](https://github.com/vtex/faststore/compare/v3.97.0-dev.4...v3.97.0-dev.5) (2026-02-19)

**Note:** Version bump only for package @faststore/cli

# [3.97.0-dev.4](https://github.com/vtex/faststore/compare/v3.97.0-dev.3...v3.97.0-dev.4) (2026-02-10)

**Note:** Version bump only for package @faststore/cli

# [3.97.0-dev.3](https://github.com/vtex/faststore/compare/v3.97.0-dev.2...v3.97.0-dev.3) (2026-02-06)

### Features

- add budget to order details ([#3130](https://github.com/vtex/faststore/issues/3130)) ([f109b02](https://github.com/vtex/faststore/commit/f109b0271542aef02810d2996f00e075a9b9bde6))

# 3.97.0-dev.2 (2026-02-06)

**Note:** Version bump only for package @faststore/cli

# [3.97.0-dev.1](https://github.com/vtex/faststore/compare/v3.96.5...v3.97.0-dev.1) (2026-02-03)

# 3.97.0-dev.0 (2026-01-27)

**Note:** Version bump only for package @faststore/cli

# [3.97.0-dev.0](https://github.com/vtex/faststore/compare/v3.96.4-dev.0...v3.97.0-dev.0) (2026-01-27)

**Note:** Version bump only for package @faststore/cli

## [3.96.4-dev.0](https://github.com/vtex/faststore/compare/v3.96.3...v3.96.4-dev.0) (2026-01-21)

## [3.96.3](https://github.com/vtex/faststore/compare/v3.96.2...v3.96.3) (2026-01-21)

**Note:** Version bump only for package @faststore/cli

## [3.96.2](https://github.com/vtex/faststore/compare/v3.96.1...v3.96.2) (2026-01-14)

**Note:** Version bump only for package @faststore/cli

## [3.96.1](https://github.com/vtex/faststore/compare/v3.96.0...v3.96.1) (2026-01-09)

**Note:** Version bump only for package @faststore/cli

# [3.96.0](https://github.com/vtex/faststore/compare/v3.95.0...v3.96.0) (2025-12-24)

### Features

- version 20251223 ([#3161](https://github.com/vtex/faststore/issues/3161)) ([ad5e8d1](https://github.com/vtex/faststore/commit/ad5e8d12fe45f1fb8e1134165172bf1c6b2a91e2))

# 3.96.0-dev.22 (2026-01-21)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.21](https://github.com/vtex/faststore/compare/v3.96.0-dev.20...v3.96.0-dev.21) (2026-01-08)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.20](https://github.com/vtex/faststore/compare/v3.96.0-dev.19...v3.96.0-dev.20) (2026-01-08)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.19](https://github.com/vtex/faststore/compare/v3.96.0-dev.18...v3.96.0-dev.19) (2026-01-08)

**Note:** Version bump only for package @faststore/cli

# 3.96.0-dev.18 (2025-12-24)

**Note:** Version bump only for package @faststore/cli

# 3.96.0-dev.17 (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.16](https://github.com/vtex/faststore/compare/v3.96.0-dev.15...v3.96.0-dev.16) (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.15](https://github.com/vtex/faststore/compare/v3.96.0-dev.14...v3.96.0-dev.15) (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.14](https://github.com/vtex/faststore/compare/v3.96.0-dev.13...v3.96.0-dev.14) (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.13](https://github.com/vtex/faststore/compare/v3.96.0-dev.12...v3.96.0-dev.13) (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.12](https://github.com/vtex/faststore/compare/v3.96.0-dev.11...v3.96.0-dev.12) (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# 3.96.0-dev.11 (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# 3.96.0-dev.10 (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.9](https://github.com/vtex/faststore/compare/v3.96.0-dev.8...v3.96.0-dev.9) (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.8](https://github.com/vtex/faststore/compare/v3.96.0-dev.7...v3.96.0-dev.8) (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# 3.96.0-dev.7 (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# 3.96.0-dev.6 (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# 3.96.0-dev.5 (2025-12-23)

### Features

- Trigger build ([28b6ec0](https://github.com/vtex/faststore/commit/28b6ec0489080be0a3431ec2ead7bfce0da75a34))

# 3.96.0-dev.4 (2025-12-23)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.3](https://github.com/vtex/faststore/compare/v3.96.0-dev.2...v3.96.0-dev.3) (2025-12-22)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.2](https://github.com/vtex/faststore/compare/v3.96.0-dev.1...v3.96.0-dev.2) (2025-12-18)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.1](https://github.com/vtex/faststore/compare/v3.96.0-dev.0...v3.96.0-dev.1) (2025-12-16)

**Note:** Version bump only for package @faststore/cli

# [3.96.0-dev.0](https://github.com/vtex/faststore/compare/v3.95.1-dev.0...v3.96.0-dev.0) (2025-12-10)

**Note:** Version bump only for package @faststore/cli

## [3.95.1-dev.0](https://github.com/vtex/faststore/compare/v3.95.0...v3.95.1-dev.0) (2025-12-02)

# 3.95.0 (2025-12-02)

### Features

- release version 20250212 ([#3138](https://github.com/vtex/faststore/issues/3138)) ([5e51548](https://github.com/vtex/faststore/commit/5e5154898e3756aa8d95efd54d76db0c90248d8d))

# 3.95.0-dev.3 (2025-12-02)

**Note:** Version bump only for package @faststore/cli

# [3.95.0-dev.2](https://github.com/vtex/faststore/compare/v3.94.0...v3.95.0-dev.2) (2025-12-02)

### Features

- release version 20250112 ([#3135](https://github.com/vtex/faststore/issues/3135)) ([65440cd](https://github.com/vtex/faststore/commit/65440cd5607e6946b4023882eacf711c215aa138))

# 3.95.0-dev.1 (2025-12-01)

### Bug Fixes

- Update `validateCart` mutation tests ([#3132](https://github.com/vtex/faststore/issues/3132)) ([c8cbb52](https://github.com/vtex/faststore/commit/c8cbb5204562ddee126c63a576ba1f4d264092f7))

# [3.95.0-dev.0](https://github.com/vtex/faststore/compare/v3.94.1-dev.0...v3.95.0-dev.0) (2025-11-20)

### Features

- Add svg extension to public folder copy's allow list ([#3123](https://github.com/vtex/faststore/issues/3123)) ([15aca77](https://github.com/vtex/faststore/commit/15aca77a3e4309d780dcb2c1511618a450c61e0f))

## [3.94.1-dev.0](https://github.com/vtex/faststore/compare/v3.94.0...v3.94.1-dev.0) (2025-11-19)

# 3.94.0 (2025-11-19)

### Features

- release version 20251119 17 05 ([#3126](https://github.com/vtex/faststore/issues/3126)) ([9753c3f](https://github.com/vtex/faststore/commit/9753c3ff5ea760767978c41ec138b661a87ad731))
- update version to 3.93.0-dev.4 and clean up changelogs ([#3127](https://github.com/vtex/faststore/issues/3127)) ([0c29d74](https://github.com/vtex/faststore/commit/0c29d749dc2222d01d848ffda9c2ae95dfba22af))

# 3.93.0-dev.4 (2025-11-17)

**Note:** Version bump only for package @faststore/cli

# [3.93.0-dev.4](https://github.com/vtex/faststore/compare/v3.93.0-dev.3...v3.93.0-dev.4) (2025-11-17)

**Note:** Version bump only for package @faststore/cli

# 3.93.0-dev.3 (2025-11-17)

**Note:** Version bump only for package @faststore/cli

# [3.93.0-dev.2](https://github.com/vtex/faststore/compare/v3.93.0-dev.1...v3.93.0-dev.2) (2025-11-07)

**Note:** Version bump only for package @faststore/cli

# 3.93.0-dev.1 (2025-11-06)

**Note:** Version bump only for package @faststore/cli

# [3.93.0-dev.0](https://github.com/vtex/faststore/compare/v3.92.1-dev.0...v3.93.0-dev.0) (2025-11-03)

**Note:** Version bump only for package @faststore/cli

## [3.92.1-dev.0](https://github.com/vtex/faststore/compare/v3.91.3-dev.1...v3.92.1-dev.0) (2025-11-03)

**Note:** Version bump only for package @faststore/cli

# [3.92.0](https://github.com/vtex/faststore/compare/v3.91.2...v3.92.0) (2025-11-03)

### Features

- release ([#3092](https://github.com/vtex/faststore/issues/3092)) ([6dfe2ba](https://github.com/vtex/faststore/commit/6dfe2ba42dd03137ea53c85ad5aa3ee5a13c2fbf))

## [3.91.3-dev.1](https://github.com/vtex/faststore/compare/v3.91.3-dev.0...v3.91.3-dev.1) (2025-10-30)

**Note:** Version bump only for package @faststore/cli

## 3.91.3-dev.0 (2025-10-30)

### Bug Fixes

- add background color to TextareaField label ([#3079](https://github.com/vtex/faststore/issues/3079)) ([9e5a64d](https://github.com/vtex/faststore/commit/9e5a64d51d9983f028ec5cf0004cfed633b1ee8d)), closes [#2705](https://github.com/vtex/faststore/issues/2705) [/github.com/vtex/faststore/pull/2705#pullrequestreview-2710467780](https://github.com//github.com/vtex/faststore/pull/2705/issues/pullrequestreview-2710467780) [#2705](https://github.com/vtex/faststore/issues/2705) [/github.com/vtex/faststore/pull/2705#pullrequestreview-2710467780](https://github.com//github.com/vtex/faststore/pull/2705/issues/pullrequestreview-2710467780)

## 3.91.2 (2025-10-27)

### Bug Fixes

- update buying policy alert message to include dynamic description SFS-2861 ([#3076](https://github.com/vtex/faststore/issues/3076)) ([f8f470e](https://github.com/vtex/faststore/commit/f8f470e7d70a0a2556e6136d84f57540b734b528))

## [3.91.1](https://github.com/vtex/faststore/compare/v3.91.0...v3.91.1) (2025-10-24)

**Note:** Version bump only for package @faststore/cli

# [3.91.0](https://github.com/vtex/faststore/compare/v3.90.1...v3.91.0) (2025-10-24)

### Features

- user validation improvements + refresh token SSR and api - SFS-2909 ([#3065](https://github.com/vtex/faststore/issues/3065)) ([97071ee](https://github.com/vtex/faststore/commit/97071ee21fcee0b038dfafa06633ef597136898e))

## [3.90.1](https://github.com/vtex/faststore/compare/v3.90.0...v3.90.1) (2025-10-20)

**Note:** Version bump only for package @faststore/cli

# [3.90.0](https://github.com/vtex/faststore/compare/v3.89.6...v3.90.0) (2025-10-13)

**Note:** Version bump only for package @faststore/cli

## [3.89.6](https://github.com/vtex/faststore/compare/v3.89.5...v3.89.6) (2025-10-09)

**Note:** Version bump only for package @faststore/cli

## [3.89.5](https://github.com/vtex/faststore/compare/v3.89.4...v3.89.5) (2025-10-08)

**Note:** Version bump only for package @faststore/cli

## [3.89.4](https://github.com/vtex/faststore/compare/v3.89.3...v3.89.4) (2025-10-06)

**Note:** Version bump only for package @faststore/cli

## [3.89.3](https://github.com/vtex/faststore/compare/v3.89.2...v3.89.3) (2025-10-03)

**Note:** Version bump only for package @faststore/cli

## 3.89.2 (2025-10-02)

### Bug Fixes

- refactor `ProductShelf` component to import directly - SFS-2895 ([#3059](https://github.com/vtex/faststore/issues/3059)) ([24ee8fb](https://github.com/vtex/faststore/commit/24ee8fb8020cf037f4fe83b7ace1a747c383cbcf))

## [3.89.1](https://github.com/vtex/faststore/compare/v3.89.0...v3.89.1) (2025-10-02)

**Note:** Version bump only for package @faststore/cli

# [3.89.0](https://github.com/vtex/faststore/compare/v3.88.7...v3.89.0) (2025-10-02)

**Note:** Version bump only for package @faststore/cli

## [3.88.7](https://github.com/vtex/faststore/compare/v3.88.6...v3.88.7) (2025-09-25)

**Note:** Version bump only for package @faststore/cli

## [3.88.6](https://github.com/vtex/faststore/compare/v3.88.5...v3.88.6) (2025-09-23)

**Note:** Version bump only for package @faststore/cli

## [3.88.5](https://github.com/vtex/faststore/compare/v3.88.4...v3.88.5) (2025-09-22)

**Note:** Version bump only for package @faststore/cli

## [3.88.4](https://github.com/vtex/faststore/compare/v3.88.3...v3.88.4) (2025-09-22)

**Note:** Version bump only for package @faststore/cli

## [3.88.3](https://github.com/vtex/faststore/compare/v3.88.2...v3.88.3) (2025-09-22)

**Note:** Version bump only for package @faststore/cli

## [3.88.2](https://github.com/vtex/faststore/compare/v3.88.1...v3.88.2) (2025-09-19)

**Note:** Version bump only for package @faststore/cli

## [3.88.1](https://github.com/vtex/faststore/compare/v3.88.0...v3.88.1) (2025-09-19)

**Note:** Version bump only for package @faststore/cli

# [3.88.0](https://github.com/vtex/faststore/compare/v3.87.0...v3.88.0) (2025-09-18)

**Note:** Version bump only for package @faststore/cli

# [3.87.0](https://github.com/vtex/faststore/compare/v3.86.4...v3.87.0) (2025-09-18)

**Note:** Version bump only for package @faststore/cli

## [3.86.4](https://github.com/vtex/faststore/compare/v3.86.3...v3.86.4) (2025-09-17)

**Note:** Version bump only for package @faststore/cli

## [3.86.3](https://github.com/vtex/faststore/compare/v3.86.2...v3.86.3) (2025-09-17)

### Bug Fixes

- add all the path to the plugin API route after the /plugins prefix ([#3042](https://github.com/vtex/faststore/issues/3042)) ([dca59ac](https://github.com/vtex/faststore/commit/dca59ac05ed28a0dbfbbbd9d1d3aa1980f42cf9a))

## [3.86.2](https://github.com/vtex/faststore/compare/v3.86.1...v3.86.2) (2025-09-16)

**Note:** Version bump only for package @faststore/cli

## [3.86.1](https://github.com/vtex/faststore/compare/v3.86.0...v3.86.1) (2025-09-16)

**Note:** Version bump only for package @faststore/cli

# [3.86.0](https://github.com/vtex/faststore/compare/v3.85.0...v3.86.0) (2025-09-15)

**Note:** Version bump only for package @faststore/cli

# [3.85.0](https://github.com/vtex/faststore/compare/v3.84.5...v3.85.0) (2025-09-15)

**Note:** Version bump only for package @faststore/cli

## [3.84.5](https://github.com/vtex/faststore/compare/v3.84.4...v3.84.5) (2025-09-15)

**Note:** Version bump only for package @faststore/cli

## [3.84.4](https://github.com/vtex/faststore/compare/v3.84.3...v3.84.4) (2025-09-15)

**Note:** Version bump only for package @faststore/cli

## [3.84.3](https://github.com/vtex/faststore/compare/v3.84.2...v3.84.3) (2025-09-12)

### Bug Fixes

- don't require restart when switching themes ([#3018](https://github.com/vtex/faststore/issues/3018)) ([52afa59](https://github.com/vtex/faststore/commit/52afa59addae3c050786463a4aa39f3390c84971))

## [3.84.2](https://github.com/vtex/faststore/compare/v3.84.1...v3.84.2) (2025-09-12)

**Note:** Version bump only for package @faststore/cli

## [3.84.1](https://github.com/vtex/faststore/compare/v3.84.0...v3.84.1) (2025-09-11)

**Note:** Version bump only for package @faststore/cli

# [3.84.0](https://github.com/vtex/faststore/compare/v3.83.1...v3.84.0) (2025-09-09)

**Note:** Version bump only for package @faststore/cli

## [3.83.1](https://github.com/vtex/faststore/compare/v3.83.0...v3.83.1) (2025-09-09)

**Note:** Version bump only for package @faststore/cli

# [3.83.0](https://github.com/vtex/faststore/compare/v3.82.4...v3.83.0) (2025-09-09)

**Note:** Version bump only for package @faststore/cli

## [3.82.4](https://github.com/vtex/faststore/compare/v3.82.3...v3.82.4) (2025-09-08)

**Note:** Version bump only for package @faststore/cli

## [3.82.3](https://github.com/vtex/faststore/compare/v3.82.2...v3.82.3) (2025-09-08)

**Note:** Version bump only for package @faststore/cli

## [3.82.2](https://github.com/vtex/faststore/compare/v3.82.1...v3.82.2) (2025-09-05)

**Note:** Version bump only for package @faststore/cli

## [3.82.1](https://github.com/vtex/faststore/compare/v3.82.0...v3.82.1) (2025-09-05)

### Bug Fixes

- CMS Sync with default contentSource.project ([#3021](https://github.com/vtex/faststore/issues/3021)) ([f223738](https://github.com/vtex/faststore/commit/f2237388b38a527d64b07cd4d5ba4e9c9efd6b8f))

# [3.82.0](https://github.com/vtex/faststore/compare/v3.81.0...v3.82.0) (2025-09-05)

**Note:** Version bump only for package @faststore/cli

# 3.81.0 (2025-09-05)

### Bug Fixes

- avoid unnecessary server restarts by moving updateNextConfig to setup only ([#2983](https://github.com/vtex/faststore/issues/2983)) ([b26238e](https://github.com/vtex/faststore/commit/b26238e9484108196b067f135e29e3360eecdaeb)), closes [#2500](https://github.com/vtex/faststore/issues/2500)

### Features

- Allow users to select which CMS builder to use ([#2997](https://github.com/vtex/faststore/issues/2997)) ([3862832](https://github.com/vtex/faststore/commit/3862832aaf366453b8a26844e2c452647a534b4d))

# 3.80.0 (2025-09-04)

### Features

- add shopper phone and email in ordered by card ([#3014](https://github.com/vtex/faststore/issues/3014)) ([31bf49b](https://github.com/vtex/faststore/commit/31bf49bb717f740ad6ff741ce2ae77322ec3f5a6))

## [3.79.1](https://github.com/vtex/faststore/compare/v3.79.0...v3.79.1) (2025-09-04)

**Note:** Version bump only for package @faststore/cli

# [3.79.0](https://github.com/vtex/faststore/compare/v3.78.0...v3.79.0) (2025-09-03)

**Note:** Version bump only for package @faststore/cli

# [3.78.0](https://github.com/vtex/faststore/compare/v3.77.3...v3.78.0) (2025-09-02)

**Note:** Version bump only for package @faststore/cli

## [3.77.3](https://github.com/vtex/faststore/compare/v3.77.2...v3.77.3) (2025-09-01)

**Note:** Version bump only for package @faststore/cli

## [3.77.2](https://github.com/vtex/faststore/compare/v3.77.1...v3.77.2) (2025-08-21)

**Note:** Version bump only for package @faststore/cli

## [3.77.1](https://github.com/vtex/faststore/compare/v3.77.0...v3.77.1) (2025-08-20)

**Note:** Version bump only for package @faststore/cli

# [3.77.0](https://github.com/vtex/faststore/compare/v3.76.0...v3.77.0) (2025-08-18)

### Features

- Better monorepo support ([#2978](https://github.com/vtex/faststore/issues/2978)) ([c32b23b](https://github.com/vtex/faststore/commit/c32b23baaed5269527661beee7bcde0db9887c36))

# [3.76.0](https://github.com/vtex/faststore/compare/v3.75.1...v3.76.0) (2025-08-14)

**Note:** Version bump only for package @faststore/cli

## [3.75.1](https://github.com/vtex/faststore/compare/v3.75.0...v3.75.1) (2025-08-08)

**Note:** Version bump only for package @faststore/cli

# [3.75.0](https://github.com/vtex/faststore/compare/v3.74.0...v3.75.0) (2025-08-07)

**Note:** Version bump only for package @faststore/cli

# [3.74.0](https://github.com/vtex/faststore/compare/v3.73.0...v3.74.0) (2025-08-07)

### Features

- add flag --watch-plugins on dev command ([#2880](https://github.com/vtex/faststore/issues/2880)) ([5816538](https://github.com/vtex/faststore/commit/5816538786aff756c8a3f035096dfb35c6530d60)), closes [#2563](https://github.com/vtex/faststore/issues/2563)

# [3.73.0](https://github.com/vtex/faststore/compare/v3.72.1...v3.73.0) (2025-08-07)

**Note:** Version bump only for package @faststore/cli

## [3.72.1](https://github.com/vtex/faststore/compare/v3.72.0...v3.72.1) (2025-08-07)

**Note:** Version bump only for package @faststore/cli

# [3.72.0](https://github.com/vtex/faststore/compare/v3.71.0...v3.72.0) (2025-08-05)

**Note:** Version bump only for package @faststore/cli

# [3.71.0](https://github.com/vtex/faststore/compare/v3.70.2...v3.71.0) (2025-08-05)

**Note:** Version bump only for package @faststore/cli

## [3.70.2](https://github.com/vtex/faststore/compare/v3.70.1...v3.70.2) (2025-08-05)

**Note:** Version bump only for package @faststore/cli

## [3.70.1](https://github.com/vtex/faststore/compare/v3.70.0...v3.70.1) (2025-08-04)

**Note:** Version bump only for package @faststore/cli

# [3.70.0](https://github.com/vtex/faststore/compare/v3.69.1...v3.70.0) (2025-08-01)

**Note:** Version bump only for package @faststore/cli

## [3.69.1](https://github.com/vtex/faststore/compare/v3.69.0...v3.69.1) (2025-08-01)

**Note:** Version bump only for package @faststore/cli

# [3.69.0](https://github.com/vtex/faststore/compare/v3.68.2...v3.69.0) (2025-07-31)

**Note:** Version bump only for package @faststore/cli

## [3.68.2](https://github.com/vtex/faststore/compare/v3.68.1...v3.68.2) (2025-07-29)

**Note:** Version bump only for package @faststore/cli

## [3.68.1](https://github.com/vtex/faststore/compare/v3.68.0...v3.68.1) (2025-07-29)

**Note:** Version bump only for package @faststore/cli

# [3.68.0](https://github.com/vtex/faststore/compare/v3.67.0...v3.68.0) (2025-07-28)

### Features

- Delivery Promise 1.2 - filters by shipping method ([#2784](https://github.com/vtex/faststore/issues/2784)) ([dacf843](https://github.com/vtex/faststore/commit/dacf843c81f19984a01f7a97ff25e3801e41ed07)), closes [#2803](https://github.com/vtex/faststore/issues/2803) [#2826](https://github.com/vtex/faststore/issues/2826) [#2845](https://github.com/vtex/faststore/issues/2845) [#2847](https://github.com/vtex/faststore/issues/2847) [#2851](https://github.com/vtex/faststore/issues/2851) [#2852](https://github.com/vtex/faststore/issues/2852) [#2847](https://github.com/vtex/faststore/issues/2847) [#2872](https://github.com/vtex/faststore/issues/2872) [#2886](https://github.com/vtex/faststore/issues/2886) [#2909](https://github.com/vtex/faststore/issues/2909) [#2916](https://github.com/vtex/faststore/issues/2916) [#2918](https://github.com/vtex/faststore/issues/2918) [#2922](https://github.com/vtex/faststore/issues/2922) [#2887](https://github.com/vtex/faststore/issues/2887) [#2944](https://github.com/vtex/faststore/issues/2944) [#2953](https://github.com/vtex/faststore/issues/2953) [#2956](https://github.com/vtex/faststore/issues/2956) [#2955](https://github.com/vtex/faststore/issues/2955) [#2961](https://github.com/vtex/faststore/issues/2961) [#2962](https://github.com/vtex/faststore/issues/2962)

# [3.67.0](https://github.com/vtex/faststore/compare/v3.66.0...v3.67.0) (2025-07-23)

**Note:** Version bump only for package @faststore/cli

# [3.66.0](https://github.com/vtex/faststore/compare/v3.65.2...v3.66.0) (2025-07-23)

**Note:** Version bump only for package @faststore/cli

## [3.65.2](https://github.com/vtex/faststore/compare/v3.65.1...v3.65.2) (2025-07-22)

**Note:** Version bump only for package @faststore/cli

## [3.65.1](https://github.com/vtex/faststore/compare/v3.65.0...v3.65.1) (2025-07-17)

**Note:** Version bump only for package @faststore/cli

# [3.65.0](https://github.com/vtex/faststore/compare/v3.64.1...v3.65.0) (2025-07-16)

### Features

- my account release 3 ([#2883](https://github.com/vtex/faststore/issues/2883)) ([be2c32a](https://github.com/vtex/faststore/commit/be2c32ae5cb0d892e34a96c2d73b06d31f8af137))

## [3.64.1](https://github.com/vtex/faststore/compare/v3.64.0...v3.64.1) (2025-07-16)

**Note:** Version bump only for package @faststore/cli

# [3.64.0](https://github.com/vtex/faststore/compare/v3.63.1...v3.64.0) (2025-07-15)

**Note:** Version bump only for package @faststore/cli

## [3.63.1](https://github.com/vtex/faststore/compare/v3.63.0...v3.63.1) (2025-07-15)

**Note:** Version bump only for package @faststore/cli

# [3.63.0](https://github.com/vtex/faststore/compare/v3.62.0...v3.63.0) (2025-07-14)

**Note:** Version bump only for package @faststore/cli

# [3.62.0](https://github.com/vtex/faststore/compare/v3.61.0...v3.62.0) (2025-07-11)

**Note:** Version bump only for package @faststore/cli

# [3.61.0](https://github.com/vtex/faststore/compare/v3.60.4...v3.61.0) (2025-07-04)

**Note:** Version bump only for package @faststore/cli

## [3.60.4](https://github.com/vtex/faststore/compare/v3.60.3...v3.60.4) (2025-07-04)

**Note:** Version bump only for package @faststore/cli

## [3.60.3](https://github.com/vtex/faststore/compare/v3.60.2...v3.60.3) (2025-07-02)

**Note:** Version bump only for package @faststore/cli

## [3.60.2](https://github.com/vtex/faststore/compare/v3.60.1...v3.60.2) (2025-07-02)

**Note:** Version bump only for package @faststore/cli

## [3.60.1](https://github.com/vtex/faststore/compare/v3.60.0...v3.60.1) (2025-06-24)

**Note:** Version bump only for package @faststore/cli

# [3.60.0](https://github.com/vtex/faststore/compare/v3.59.0...v3.60.0) (2025-06-23)

### Features

- add check for deprecated secret files in build and dev commands ([#2797](https://github.com/vtex/faststore/issues/2797)) ([88f6870](https://github.com/vtex/faststore/commit/88f687080ab7d1f6781e076591ef082f9cfc197a)), closes [/#diff-3b0340e6f408eb23ee2bdd40008c9ca70e2f115de9f8369097574ab4c0b67c2fR9](https://github.com///issues/diff-3b0340e6f408eb23ee2bdd40008c9ca70e2f115de9f8369097574ab4c0b67c2fR9) [/#diff-3b0340e6f408eb23ee2bdd40008c9ca70e2f115de9f8369097574ab4c0b67c2fR30-R32](https://github.com///issues/diff-3b0340e6f408eb23ee2bdd40008c9ca70e2f115de9f8369097574ab4c0b67c2fR30-R32) [/#diff-d107b455dc30a6f411ae4210b2d8e1297f4116ffac62f8c4e4081bebc5a21eddL7-R14](https://github.com///issues/diff-d107b455dc30a6f411ae4210b2d8e1297f4116ffac62f8c4e4081bebc5a21eddL7-R14) [/#diff-d107b455dc30a6f411ae4210b2d8e1297f4116ffac62f8c4e4081bebc5a21eddR148-R149](https://github.com///issues/diff-d107b455dc30a6f411ae4210b2d8e1297f4116ffac62f8c4e4081bebc5a21eddR148-R149)

# [3.59.0](https://github.com/vtex/faststore/compare/v3.58.0...v3.59.0) (2025-06-20)

**Note:** Version bump only for package @faststore/cli

# [3.58.0](https://github.com/vtex/faststore/compare/v3.57.0...v3.58.0) (2025-06-20)

**Note:** Version bump only for package @faststore/cli

# [3.57.0](https://github.com/vtex/faststore/compare/v3.56.3...v3.57.0) (2025-06-20)

**Note:** Version bump only for package @faststore/cli

## [3.56.3](https://github.com/vtex/faststore/compare/v3.56.2...v3.56.3) (2025-06-20)

**Note:** Version bump only for package @faststore/cli

## [3.56.2](https://github.com/vtex/faststore/compare/v3.56.1...v3.56.2) (2025-06-19)

**Note:** Version bump only for package @faststore/cli

## 3.56.1 (2025-06-19)

### Bug Fixes

- redirect order details ([#2910](https://github.com/vtex/faststore/issues/2910)) ([a9b1f59](https://github.com/vtex/faststore/commit/a9b1f59952aff8084f47f6d85fc6d4c3356f5017))

# [3.56.0](https://github.com/vtex/faststore/compare/v3.55.1...v3.56.0) (2025-06-19)

**Note:** Version bump only for package @faststore/cli

## [3.55.1](https://github.com/vtex/faststore/compare/v3.55.0...v3.55.1) (2025-06-18)

**Note:** Version bump only for package @faststore/cli

# [3.55.0](https://github.com/vtex/faststore/compare/v3.54.0...v3.55.0) (2025-06-18)

**Note:** Version bump only for package @faststore/cli

# [3.54.0](https://github.com/vtex/faststore/compare/v3.53.0...v3.54.0) (2025-06-17)

**Note:** Version bump only for package @faststore/cli

# [3.53.0](https://github.com/vtex/faststore/compare/v3.52.1...v3.53.0) (2025-06-16)

### Features

- sfs 2523 contract name main menu ([#2895](https://github.com/vtex/faststore/issues/2895)) ([60adc92](https://github.com/vtex/faststore/commit/60adc92721a4a9eef6db66d1f7c3b563474b554d))

## [3.52.1](https://github.com/vtex/faststore/compare/v3.52.0...v3.52.1) (2025-06-16)

**Note:** Version bump only for package @faststore/cli

# [3.52.0](https://github.com/vtex/faststore/compare/v3.51.0...v3.52.0) (2025-06-12)

**Note:** Version bump only for package @faststore/cli

# [3.51.0](https://github.com/vtex/faststore/compare/v3.50.4...v3.51.0) (2025-06-04)

**Note:** Version bump only for package @faststore/cli

## [3.50.4](https://github.com/vtex/faststore/compare/v3.50.3...v3.50.4) (2025-06-03)

**Note:** Version bump only for package @faststore/cli

## 3.50.3 (2025-06-02)

**Note:** Version bump only for package @faststore/cli

## [3.50.2](https://github.com/vtex/faststore/compare/v3.50.1...v3.50.2) (2025-05-27)

### Bug Fixes

- theme styles import ([#2868](https://github.com/vtex/faststore/issues/2868)) ([91724d7](https://github.com/vtex/faststore/commit/91724d78ee71a000957716e6ebc06ee105d1c024))

## [3.50.1](https://github.com/vtex/faststore/compare/v3.50.0...v3.50.1) (2025-05-27)

**Note:** Version bump only for package @faststore/cli

# [3.50.0](https://github.com/vtex/faststore/compare/v3.49.2...v3.50.0) (2025-05-27)

**Note:** Version bump only for package @faststore/cli

## [3.49.2](https://github.com/vtex/faststore/compare/v3.49.1...v3.49.2) (2025-05-27)

**Note:** Version bump only for package @faststore/cli

## 3.49.1 (2025-05-27)

**Note:** Version bump only for package @faststore/cli

# [3.49.0](https://github.com/vtex/faststore/compare/v3.48.0...v3.49.0) (2025-05-26)

**Note:** Version bump only for package @faststore/cli

# [3.48.0](https://github.com/vtex/faststore/compare/v3.47.2...v3.48.0) (2025-05-26)

**Note:** Version bump only for package @faststore/cli

## [3.47.2](https://github.com/vtex/faststore/compare/v3.47.1...v3.47.2) (2025-05-23)

### Bug Fixes

- Prevent `checkDeps` error ([#2864](https://github.com/vtex/faststore/issues/2864)) ([228a56f](https://github.com/vtex/faststore/commit/228a56ffa85bb7eb0663841aa74efe60d0531171))

## [3.47.1](https://github.com/vtex/faststore/compare/v3.47.0...v3.47.1) (2025-05-22)

**Note:** Version bump only for package @faststore/cli

# [3.47.0](https://github.com/vtex/faststore/compare/v3.46.0...v3.47.0) (2025-05-22)

**Note:** Version bump only for package @faststore/cli

# [3.46.0](https://github.com/vtex/faststore/compare/v3.45.0...v3.46.0) (2025-05-21)

**Note:** Version bump only for package @faststore/cli

# 3.45.0 (2025-05-20)

**Note:** Version bump only for package @faststore/cli

## [3.44.3](https://github.com/vtex/faststore/compare/v3.44.2...v3.44.3) (2025-05-16)

**Note:** Version bump only for package @faststore/cli

## [3.44.2](https://github.com/vtex/faststore/compare/v3.44.1...v3.44.2) (2025-05-14)

**Note:** Version bump only for package @faststore/cli

## [3.44.1](https://github.com/vtex/faststore/compare/v3.44.0...v3.44.1) (2025-05-13)

**Note:** Version bump only for package @faststore/cli

# [3.44.0](https://github.com/vtex/faststore/compare/v3.43.0...v3.44.0) (2025-05-13)

**Note:** Version bump only for package @faststore/cli

# [3.43.0](https://github.com/vtex/faststore/compare/v3.42.0...v3.43.0) (2025-05-12)

**Note:** Version bump only for package @faststore/cli

# [3.42.0](https://github.com/vtex/faststore/compare/v3.41.9...v3.42.0) (2025-05-08)

**Note:** Version bump only for package @faststore/cli

## [3.41.9](https://github.com/vtex/faststore/compare/v3.41.8...v3.41.9) (2025-05-01)

**Note:** Version bump only for package @faststore/cli

## [3.41.8](https://github.com/vtex/faststore/compare/v3.41.7...v3.41.8) (2025-04-30)

**Note:** Version bump only for package @faststore/cli

## [3.41.7](https://github.com/vtex/faststore/compare/v3.41.6...v3.41.7) (2025-04-24)

**Note:** Version bump only for package @faststore/cli

## [3.41.6](https://github.com/vtex/faststore/compare/v3.41.5...v3.41.6) (2025-04-24)

**Note:** Version bump only for package @faststore/cli

## [3.41.5](https://github.com/vtex/faststore/compare/v3.41.4...v3.41.5) (2025-04-22)

**Note:** Version bump only for package @faststore/cli

## [3.41.4](https://github.com/vtex/faststore/compare/v3.41.3...v3.41.4) (2025-04-17)

**Note:** Version bump only for package @faststore/cli

## [3.41.3](https://github.com/vtex/faststore/compare/v3.41.2...v3.41.3) (2025-04-16)

**Note:** Version bump only for package @faststore/cli

## [3.41.2](https://github.com/vtex/faststore/compare/v3.41.1...v3.41.2) (2025-04-16)

**Note:** Version bump only for package @faststore/cli

## [3.41.1](https://github.com/vtex/faststore/compare/v3.41.0...v3.41.1) (2025-04-16)

**Note:** Version bump only for package @faststore/cli

# [3.41.0](https://github.com/vtex/faststore/compare/v3.40.2...v3.41.0) (2025-04-15)

**Note:** Version bump only for package @faststore/cli

## [3.40.2](https://github.com/vtex/faststore/compare/v3.40.1...v3.40.2) (2025-04-15)

**Note:** Version bump only for package @faststore/cli

## [3.40.1](https://github.com/vtex/faststore/compare/v3.40.0...v3.40.1) (2025-04-14)

**Note:** Version bump only for package @faststore/cli

# [3.40.0](https://github.com/vtex/faststore/compare/v3.39.0...v3.40.0) (2025-04-11)

**Note:** Version bump only for package @faststore/cli

# [3.39.0](https://github.com/vtex/faststore/compare/v3.38.3...v3.39.0) (2025-04-11)

**Note:** Version bump only for package @faststore/cli

## 3.38.3 (2025-04-11)

### Bug Fixes

- properly end response for unsupported HTTP methods in GraphQL API ([#2781](https://github.com/vtex/faststore/issues/2781)) ([58f6caf](https://github.com/vtex/faststore/commit/58f6cafa7946ddd3970994dece423f7fff8e55c8))

## [3.38.2](https://github.com/vtex/faststore/compare/v3.38.1...v3.38.2) (2025-04-10)

**Note:** Version bump only for package @faststore/cli

## [3.38.1](https://github.com/vtex/faststore/compare/v3.38.0...v3.38.1) (2025-04-10)

**Note:** Version bump only for package @faststore/cli

# [3.38.0](https://github.com/vtex/faststore/compare/v3.37.0...v3.38.0) (2025-04-10)

**Note:** Version bump only for package @faststore/cli

# [3.37.0](https://github.com/vtex/faststore/compare/v3.36.0...v3.37.0) (2025-04-10)

**Note:** Version bump only for package @faststore/cli

# [3.36.0](https://github.com/vtex/faststore/compare/v3.35.1...v3.36.0) (2025-04-09)

### Features

- My Account Menu and Extensibility ([#2761](https://github.com/vtex/faststore/issues/2761)) ([0daf07a](https://github.com/vtex/faststore/commit/0daf07a7fdf524992472d9f9b4a013885aa175a2)), closes [#2729](https://github.com/vtex/faststore/issues/2729) [#2720](https://github.com/vtex/faststore/issues/2720) [#2738](https://github.com/vtex/faststore/issues/2738) [#2752](https://github.com/vtex/faststore/issues/2752)

## [3.35.1](https://github.com/vtex/faststore/compare/v3.35.0...v3.35.1) (2025-04-08)

**Note:** Version bump only for package @faststore/cli

# [3.35.0](https://github.com/vtex/faststore/compare/v3.34.0...v3.35.0) (2025-04-08)

**Note:** Version bump only for package @faststore/cli

# [3.34.0](https://github.com/vtex/faststore/compare/v3.33.5...v3.34.0) (2025-04-08)

**Note:** Version bump only for package @faststore/cli

## [3.33.5](https://github.com/vtex/faststore/compare/v3.33.4...v3.33.5) (2025-04-03)

**Note:** Version bump only for package @faststore/cli

## [3.33.4](https://github.com/vtex/faststore/compare/v3.33.3...v3.33.4) (2025-04-02)

**Note:** Version bump only for package @faststore/cli

## [3.33.3](https://github.com/vtex/faststore/compare/v3.33.2...v3.33.3) (2025-04-01)

**Note:** Version bump only for package @faststore/cli

## [3.33.2](https://github.com/vtex/faststore/compare/v3.33.1...v3.33.2) (2025-04-01)

**Note:** Version bump only for package @faststore/cli

## [3.33.1](https://github.com/vtex/faststore/compare/v3.33.0...v3.33.1) (2025-04-01)

**Note:** Version bump only for package @faststore/cli

# [3.33.0](https://github.com/vtex/faststore/compare/v3.32.1...v3.33.0) (2025-03-31)

**Note:** Version bump only for package @faststore/cli

## [3.32.1](https://github.com/vtex/faststore/compare/v3.32.0...v3.32.1) (2025-03-28)

**Note:** Version bump only for package @faststore/cli

# [3.32.0](https://github.com/vtex/faststore/compare/v3.31.0...v3.32.0) (2025-03-27)

**Note:** Version bump only for package @faststore/cli

# [3.31.0](https://github.com/vtex/faststore/compare/v3.30.1...v3.31.0) (2025-03-26)

**Note:** Version bump only for package @faststore/cli

## [3.30.1](https://github.com/vtex/faststore/compare/v3.30.0...v3.30.1) (2025-03-25)

**Note:** Version bump only for package @faststore/cli

# [3.30.0](https://github.com/vtex/faststore/compare/v3.29.1...v3.30.0) (2025-03-21)

### Features

- Add plugins apis support ([#2664](https://github.com/vtex/faststore/issues/2664)) ([11f2fb7](https://github.com/vtex/faststore/commit/11f2fb718ba4b414d2da09d066711cd6e448b5c0))

## [3.29.1](https://github.com/vtex/faststore/compare/v3.29.0...v3.29.1) (2025-03-21)

**Note:** Version bump only for package @faststore/cli

# [3.29.0](https://github.com/vtex/faststore/compare/v3.28.1...v3.29.0) (2025-03-21)

**Note:** Version bump only for package @faststore/cli

## [3.28.1](https://github.com/vtex/faststore/compare/v3.28.0...v3.28.1) (2025-03-20)

**Note:** Version bump only for package @faststore/cli

# 3.28.0 (2025-03-20)

### Bug Fixes

- add pnpm-lock.yaml to ignored files in biome.json ([#2737](https://github.com/vtex/faststore/issues/2737)) ([e308698](https://github.com/vtex/faststore/commit/e308698a406e27f0112ff1dc2e83564c42c83d85))

# [3.27.0](https://github.com/vtex/faststore/compare/v3.26.1...v3.27.0) (2025-03-20)

**Note:** Version bump only for package @faststore/cli

## [3.26.1](https://github.com/vtex/faststore/compare/v3.26.0...v3.26.1) (2025-03-19)

**Note:** Version bump only for package @faststore/cli

# 3.26.0 (2025-03-19)

**Note:** Version bump only for package @faststore/cli

## [3.25.11](https://github.com/vtex/faststore/compare/v3.25.10...v3.25.11) (2025-03-17)

**Note:** Version bump only for package @faststore/cli

## [3.25.10](https://github.com/vtex/faststore/compare/v3.25.9...v3.25.10) (2025-03-11)

**Note:** Version bump only for package @faststore/cli

## [3.25.9](https://github.com/vtex/faststore/compare/v3.25.8...v3.25.9) (2025-03-10)

**Note:** Version bump only for package @faststore/cli

## [3.25.8](https://github.com/vtex/faststore/compare/v3.25.7...v3.25.8) (2025-03-10)

**Note:** Version bump only for package @faststore/cli

## [3.25.7](https://github.com/vtex/faststore/compare/v3.25.6...v3.25.7) (2025-03-10)

**Note:** Version bump only for package @faststore/cli

## [3.25.6](https://github.com/vtex/faststore/compare/v3.25.5...v3.25.6) (2025-03-07)

**Note:** Version bump only for package @faststore/cli

## [3.25.5](https://github.com/vtex/faststore/compare/v3.25.4...v3.25.5) (2025-03-07)

**Note:** Version bump only for package @faststore/cli

## [3.25.4](https://github.com/vtex/faststore/compare/v3.25.3...v3.25.4) (2025-03-07)

**Note:** Version bump only for package @faststore/cli

## [3.25.3](https://github.com/vtex/faststore/compare/v3.25.2...v3.25.3) (2025-03-07)

**Note:** Version bump only for package @faststore/cli

## [3.25.2](https://github.com/vtex/faststore/compare/v3.25.1...v3.25.2) (2025-03-06)

**Note:** Version bump only for package @faststore/cli

## [3.25.1](https://github.com/vtex/faststore/compare/v3.25.0...v3.25.1) (2025-02-28)

**Note:** Version bump only for package @faststore/cli

# [3.25.0](https://github.com/vtex/faststore/compare/v3.24.1...v3.25.0) (2025-02-28)

**Note:** Version bump only for package @faststore/cli

## [3.24.1](https://github.com/vtex/faststore/compare/v3.24.0...v3.24.1) (2025-02-26)

**Note:** Version bump only for package @faststore/cli

# [3.24.0](https://github.com/vtex/faststore/compare/v3.23.0...v3.24.0) (2025-02-26)

**Note:** Version bump only for package @faststore/cli

# [3.23.0](https://github.com/vtex/faststore/compare/v3.22.3...v3.23.0) (2025-02-26)

**Note:** Version bump only for package @faststore/cli

## [3.22.3](https://github.com/vtex/faststore/compare/v3.22.2...v3.22.3) (2025-02-24)

**Note:** Version bump only for package @faststore/cli

## 3.22.2 (2025-02-20)

### Bug Fixes

- Removes CI invalid input ([#2689](https://github.com/vtex/faststore/issues/2689)) ([30ea4b5](https://github.com/vtex/faststore/commit/30ea4b5d38fee5f9aacda60c0bd3b3296875864c))

## [3.22.1](https://github.com/vtex/faststore/compare/v3.22.0...v3.22.1) (2025-02-18)

**Note:** Version bump only for package @faststore/cli

# [3.22.0](https://github.com/vtex/faststore/compare/v3.21.0...v3.22.0) (2025-02-18)

**Note:** Version bump only for package @faststore/cli

# [3.21.0](https://github.com/vtex/faststore/compare/v3.20.0...v3.21.0) (2025-02-18)

**Note:** Version bump only for package @faststore/cli

# [3.20.0](https://github.com/vtex/faststore/compare/v3.19.0...v3.20.0) (2025-02-18)

**Note:** Version bump only for package @faststore/cli

# [3.19.0](https://github.com/vtex/faststore/compare/v3.18.0...v3.19.0) (2025-02-18)

**Note:** Version bump only for package @faststore/cli

# [3.18.0](https://github.com/vtex/faststore/compare/v3.17.0...v3.18.0) (2025-02-17)

**Note:** Version bump only for package @faststore/cli

# [3.17.0](https://github.com/vtex/faststore/compare/v3.16.0...v3.17.0) (2025-02-17)

**Note:** Version bump only for package @faststore/cli

# [3.16.0](https://github.com/vtex/faststore/compare/v3.15.3...v3.16.0) (2025-02-13)

**Note:** Version bump only for package @faststore/cli

## 3.15.3 (2025-02-13)

### Bug Fixes

- attempts to run publish directly in ci ([#2683](https://github.com/vtex/faststore/issues/2683)) ([44bb50d](https://github.com/vtex/faststore/commit/44bb50d0f03285cb3e48284004675a81385ade9b))

## [3.15.2](https://github.com/vtex/faststore/compare/v3.15.1...v3.15.2) (2025-02-05)

**Note:** Version bump only for package @faststore/cli

## [3.15.1](https://github.com/vtex/faststore/compare/v3.15.0...v3.15.1) (2025-02-04)

**Note:** Version bump only for package @faststore/cli

# 3.15.0 (2025-02-04)

### Features

- Offer SDK ([#2575](https://github.com/vtex/faststore/issues/2575)) ([f4e11ac](https://github.com/vtex/faststore/commit/f4e11ac68ae4afd79a1a89c122155e18bc452ad5))

## [3.14.3](https://github.com/vtex/faststore/compare/v3.14.2...v3.14.3) (2025-02-04)

**Note:** Version bump only for package @faststore/cli

## 3.14.2 (2025-02-03)

**Note:** Version bump only for package @faststore/cli

## [3.14.1](https://github.com/vtex/faststore/compare/v3.14.0...v3.14.1) (2025-02-03)

**Note:** Version bump only for package @faststore/cli

# [3.14.0](https://github.com/vtex/faststore/compare/v3.13.1...v3.14.0) (2025-02-03)

**Note:** Version bump only for package @faststore/cli

## 3.13.1 (2025-01-31)

**Note:** Version bump only for package @faststore/cli

# [3.13.0](https://github.com/vtex/faststore/compare/v3.12.1...v3.13.0) (2025-01-31)

**Note:** Version bump only for package @faststore/cli

## [3.12.1](https://github.com/vtex/faststore/compare/v3.12.0...v3.12.1) (2025-01-30)

**Note:** Version bump only for package @faststore/cli

# [3.12.0](https://github.com/vtex/faststore/compare/v3.11.4...v3.12.0) (2025-01-29)

**Note:** Version bump only for package @faststore/cli

## [3.11.4](https://github.com/vtex/faststore/compare/v3.11.3...v3.11.4) (2025-01-29)

**Note:** Version bump only for package @faststore/cli

## [3.11.3](https://github.com/vtex/faststore/compare/v3.11.2...v3.11.3) (2025-01-29)

**Note:** Version bump only for package @faststore/cli

## [3.11.2](https://github.com/vtex/faststore/compare/v3.11.1...v3.11.2) (2025-01-29)

**Note:** Version bump only for package @faststore/cli

## [3.11.1](https://github.com/vtex/faststore/compare/v3.11.0...v3.11.1) (2025-01-29)

**Note:** Version bump only for package @faststore/cli

# [3.11.0](https://github.com/vtex/faststore/compare/v3.10.0...v3.11.0) (2025-01-29)

### Features

- search page with SSR ([#2619](https://github.com/vtex/faststore/issues/2619)) ([6fd2d0d](https://github.com/vtex/faststore/commit/6fd2d0d5e92f0922f8d97237d9d04a7eadc5e894))

# [3.10.0](https://github.com/vtex/faststore/compare/v3.9.3...v3.10.0) (2025-01-29)

**Note:** Version bump only for package @faststore/cli

## [3.9.3](https://github.com/vtex/faststore/compare/v3.9.2...v3.9.3) (2025-01-28)

**Note:** Version bump only for package @faststore/cli

## [3.9.2](https://github.com/vtex/faststore/compare/v3.9.1...v3.9.2) (2025-01-27)

**Note:** Version bump only for package @faststore/cli

## [3.9.1](https://github.com/vtex/faststore/compare/v3.9.0...v3.9.1) (2025-01-27)

**Note:** Version bump only for package @faststore/cli

# 3.9.0 (2025-01-22)

### Features

- Adds Plugins feature ([#2563](https://github.com/vtex/faststore/issues/2563)) ([83c1bf9](https://github.com/vtex/faststore/commit/83c1bf904f744842060e0dfdb7449406800df157))

# [3.8.0](https://github.com/vtex/faststore/compare/v3.7.0...v3.8.0) (2025-01-15)

**Note:** Version bump only for package @faststore/cli

# [3.7.0](https://github.com/vtex/faststore/compare/v3.6.0...v3.7.0) (2025-01-15)

**Note:** Version bump only for package @faststore/cli

# [3.6.0](https://github.com/vtex/faststore/compare/v3.5.1...v3.6.0) (2025-01-13)

**Note:** Version bump only for package @faststore/cli

## [3.5.1](https://github.com/vtex/faststore/compare/v3.5.0...v3.5.1) (2025-01-09)

**Note:** Version bump only for package @faststore/cli

# 3.5.0 (2025-01-09)

### Bug Fixes

- revert the commit ccfbac80a8694b8e674c4657d51e3478ff2605bd ([#2609](https://github.com/vtex/faststore/issues/2609)) ([49679ae](https://github.com/vtex/faststore/commit/49679ae3a735f7fa29d716b6e9f6d4941d73a647))

## 3.4.4 (2024-12-20)

**Note:** Version bump only for package @faststore/cli

## 3.4.3 (2024-12-20)

**Note:** Version bump only for package @faststore/cli

## 3.4.2 (2024-12-20)

**Note:** Version bump only for package @faststore/cli

## 3.4.1 (2024-12-20)

**Note:** Version bump only for package @faststore/cli

# [3.4.0](https://github.com/vtex/faststore/compare/v3.3.0...v3.4.0) (2024-12-19)

**Note:** Version bump only for package @faststore/cli

# [3.3.0](https://github.com/vtex/faststore/compare/v3.2.1...v3.3.0) (2024-12-18)

**Note:** Version bump only for package @faststore/cli

## [3.2.1](https://github.com/vtex/faststore/compare/v3.2.0...v3.2.1) (2024-12-16)

**Note:** Version bump only for package @faststore/cli

# [3.2.0](https://github.com/vtex/faststore/compare/v3.1.4...v3.2.0) (2024-12-16)

**Note:** Version bump only for package @faststore/cli

## [3.1.4](https://github.com/vtex/faststore/compare/v3.1.3...v3.1.4) (2024-12-16)

**Note:** Version bump only for package @faststore/cli

## 3.1.3 (2024-12-13)

**Note:** Version bump only for package @faststore/cli

## [3.1.2](https://github.com/vtex/faststore/compare/v3.1.1...v3.1.2) (2024-12-11)

**Note:** Version bump only for package @faststore/cli

## [3.1.1](https://github.com/vtex/faststore/compare/v3.1.0...v3.1.1) (2024-12-09)

**Note:** Version bump only for package @faststore/cli

# [3.1.0](https://github.com/vtex/faststore/compare/v3.0.160...v3.1.0) (2024-12-09)

**Note:** Version bump only for package @faststore/cli

## 3.0.160 (2024-12-09)

**Note:** Version bump only for package @faststore/cli
