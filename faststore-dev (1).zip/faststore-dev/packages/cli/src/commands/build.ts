import { Args, Command, Flags } from '@oclif/core'
import chalk from 'chalk'
import { spawnSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import fsExtra from 'fs-extra'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { withNodeModulesBins } from '../utils/binPaths'
import { getPreferredPackageManager } from '../utils/commands'
import { checkDeprecatedSecretFiles } from '../utils/deprecations'
import { getBasePath, withBasePath } from '../utils/directory'
import { logger } from '../utils/logger'

const { copySync, moveSync, readdirSync, removeSync } = fsExtra

export default class Build extends Command {
  static args = {
    account: Args.string({
      description:
        'The account for which the Discovery is running. Currently noop.',
    }),
    path: Args.string({
      description:
        'The path where the FastStore being built is. Defaults to cwd.',
    }),
  }

  static flags = {
    ['no-verify']: Flags.boolean({
      description:
        'Skips verification of faststore dependencies version string to prevent usage of packages outside npm registry.',
    }),
  }

  async run() {
    const { args, flags } = await this.parse(Build)

    const basePath = getBasePath(args.path)

    // Check for deprecated secret files
    checkDeprecatedSecretFiles(basePath)

    if (!flags['no-verify']) {
      const invalidPackages = await checkDeps(basePath)
      invalidPackages.forEach((pkg) =>
        logger.warn(
          `${chalk.yellow(
            'warning'
          )} - Dependency ${pkg} has invalid version signature. Please use a semver like ^1.0.0 (check the official releases on https://github.com/vtex/faststore)`
        )
      )
    }

    const { tmpDir } = withBasePath(basePath)

    const packageManager = await getPreferredPackageManager()

    const binCli = path.join(
      fileURLToPath(
        import.meta.resolve('@faststore/cli/runner', import.meta.url)
      )
    )
    let scriptResult = spawnSync('node', [binCli, 'generate', basePath], {
      stdio: 'inherit',
    })

    if (scriptResult.error || scriptResult.status !== 0) {
      throw 'Error: Cant run generate' + (scriptResult.error?.message ?? '')
    }

    scriptResult = spawnSync('node', [binCli, 'cache-graphql', basePath], {
      stdio: 'inherit',
    })

    if (scriptResult.error || scriptResult.status !== 0) {
      throw (
        'Error: Unable to run cache-graphql' +
        (scriptResult.error?.message ?? '')
      )
    }

    // generate-i18n will validate localization config and check if it's enabled
    scriptResult = spawnSync('node', [binCli, 'generate-i18n', basePath], {
      stdio: 'inherit',
    })

    if (scriptResult.error || scriptResult.status !== 0) {
      throw (
        'Error: Unable to run generate-i18n' +
        (scriptResult.error?.message ?? '')
      )
    }

    scriptResult = spawnSync(`${packageManager} run build`, {
      shell: true,
      cwd: tmpDir,
      stdio: 'inherit',
      env: withNodeModulesBins(tmpDir),
    })

    if (scriptResult.status && scriptResult.status !== 0) {
      process.exit(scriptResult.status)
    }

    await normalizeStandaloneBuildDir(basePath)
    await copyResources(basePath)
  }
}

async function copyResource(from: string, to: string) {
  try {
    if (existsSync(to)) {
      removeSync(to)
    }

    copySync(from, to)
    console.log(
      `${chalk.green('success')} - ${chalk.dim(from)} copied to ${chalk.dim(
        to
      )}`
    )
  } catch (err) {
    console.error(`${chalk.red('error')} - ${err}`)
  }
}

async function normalizeStandaloneBuildDir(basePath: string) {
  const { tmpDir } = withBasePath(basePath)
  const isRunningFromMonorepo = process.cwd() !== basePath
  const prefix = isRunningFromMonorepo
    ? `${path.relative(process.cwd(), basePath).replace(/\\/g, '/')}/`
    : ''

  // Fix Next.js v13+ standalone build output directory
  if (existsSync(`${tmpDir}/.next/standalone/${prefix}.faststore`)) {
    const standaloneBuildFiles = readdirSync(
      `${tmpDir}/.next/standalone/${prefix}.faststore`
    )

    await Promise.all(
      standaloneBuildFiles.map((file) =>
        moveSync(
          `${tmpDir}/.next/standalone/${prefix}.faststore/${file}`,
          `${tmpDir}/.next/standalone/${file}`,
          { overwrite: true }
        )
      )
    )
    removeSync(`${tmpDir}/.next/standalone/${prefix}.faststore`)
  }
}

async function copyResources(basePath: string) {
  const { tmpDir, userDir } = withBasePath(basePath)

  if (process.env.BUILD_CONTEXT === 'vercel') {
    const toDir = process.cwd()

    // Because of how copyResource works (delete the target directory if it exists),
    // if we're moving something to the same place it is it will break.
    const nextOutputDirectory = `${tmpDir}/.next`
    const expectedOutputDirectory = `${toDir}/.faststore/.next`
    if (nextOutputDirectory !== expectedOutputDirectory) {
      await copyResource(nextOutputDirectory, expectedOutputDirectory)
    }
    await copyResource(`${tmpDir}/public`, `${toDir}/public`)
  } else {
    await copyResource(`${tmpDir}/.next`, `${userDir}/.next`)
    await copyResource(
      `${tmpDir}/lighthouserc.js`,
      `${userDir}/lighthouserc.js`
    )
    await copyResource(`${tmpDir}/public`, `${userDir}/public`)
  }
}

async function checkDeps(basePath: string): Promise<Array<string>> {
  const packageJsonPath = `${basePath}/package.json`
  if (!existsSync(packageJsonPath)) {
    console.log(
      `${chalk.yellow(
        'warning'
      )} - package.json not found at ${packageJsonPath}`
    )
  }

  try {
    const mod = await import(pathToFileURL(packageJsonPath).href, {
      with: { type: 'json' },
    })
    const pkg = (mod.default ?? mod) as {
      devDependencies?: Record<string, string>
      dependencies?: Record<string, string>
      peerDependencies?: Record<string, string>
    }
    const {
      devDependencies = {},
      dependencies = {},
      peerDependencies = {},
    } = pkg

    const allDeps: Record<string, string> = Object.assign(
      {},
      peerDependencies,
      devDependencies,
      dependencies
    )

    const invalidPackages: Array<string> = []

    Object.entries(allDeps).forEach(([pkg, version]) => {
      if (/^@faststore\/.+/i.test(pkg) === false) return

      if (version && /^(http|https|git):.+/.test(version) === true) {
        invalidPackages.push(pkg)
      }
    })

    return invalidPackages
  } catch (err) {
    console.log(
      `${chalk.yellow('warning')} - unable to check @faststore dependencies: ${err}`
    )

    return []
  }
}
