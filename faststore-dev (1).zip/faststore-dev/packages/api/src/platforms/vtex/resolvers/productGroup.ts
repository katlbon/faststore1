import type { GraphqlResolver } from '..'
import type { PromiseType } from '../../../typings/globals'
import { enhanceSku } from '../utils/enhanceSku'
import { VALUE_REFERENCES } from '../utils/propertyValue'
import type { StoreProduct } from './product'

export type Root = PromiseType<ReturnType<typeof StoreProduct.isVariantOf>>

const BLOCKED_SPECIFICATIONS = new Set(['allSpecifications'])

export const StoreProductGroup: Record<string, GraphqlResolver<Root>> = {
  hasVariant: (root) =>
    root.isVariantOf.items.map((item) => enhanceSku(item, root.isVariantOf)),
  productGroupID: ({ isVariantOf }) => isVariantOf.productId,
  productClusters: ({ isVariantOf }) => isVariantOf.productClusters ?? [],
  name: (root) => root.isVariantOf.productName,
  skuVariants: (root) => root,
  additionalProperty: ({ isVariantOf: { specificationGroups } }) =>
    specificationGroups
      // Filter sku specifications so we don't mix them with product specs.
      .filter(
        (specificationGroup) =>
          !BLOCKED_SPECIFICATIONS.has(specificationGroup.name)
      )
      // Transform specs back into product specs.
      .flatMap(({ specifications }) =>
        specifications.flatMap(({ name, values }) =>
          values.map((value) => ({
            name,
            value,
            valueReference: VALUE_REFERENCES.specification,
          }))
        )
      ),
}
