# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [4.10.1-dev.2](https://github.com/vtex/faststore/compare/v4.10.1-dev.1...v4.10.1-dev.2) (2026-10-27)

**Note:** Version bump only for package @faststore/components

## [4.10.1-dev.1](https://github.com/vtex/faststore/compare/v4.10.1-dev.0...v4.10.1-dev.1) (2026-10-21)

**Note:** Version bump only for package @faststore/components

## [4.10.1-dev.0](https://github.com/vtex/faststore/compare/v4.10.0...v4.10.1-dev.0) (2026-10-15)

**Note:** Version bump only for package @faststore/components

# [4.10.0](https://github.com/vtex/faststore/compare/v4.10.0-dev.1...v4.10.0) (2026-10-15)

**Note:** Version bump only for package @faststore/components

# [4.10.0-dev.1](https://github.com/vtex/faststore/compare/v4.10.0-dev.0...v4.10.0-dev.1) (2026-10-15)

**Note:** Version bump only for package @faststore/components

# [4.10.0-dev.0](https://github.com/vtex/faststore/compare/v4.9.3-dev.2...v4.10.0-dev.0) (2026-10-08)

**Note:** Version bump only for package @faststore/components

## [4.9.3-dev.2](https://github.com/vtex/faststore/compare/v4.9.3-dev.1...v4.9.3-dev.2) (2026-10-07)

**Note:** Version bump only for package @faststore/components

## [4.9.3-dev.1](https://github.com/vtex/faststore/compare/v4.9.3-dev.0...v4.9.3-dev.1) (2026-10-06)

**Note:** Version bump only for package @faststore/components

## [4.9.3-dev.0](https://github.com/vtex/faststore/compare/v4.9.1-dev.0...v4.9.3-dev.0) (2026-10-05)

**Note:** Version bump only for package @faststore/components

## [4.9.2](https://github.com/vtex/faststore/compare/v4.9.1...v4.9.2) (2026-10-02)

**Note:** Version bump only for package @faststore/components

## [4.9.1](https://github.com/vtex/faststore/compare/v4.9.0...v4.9.1) (2026-10-02)

**Note:** Version bump only for package @faststore/components

# [4.9.0](https://github.com/vtex/faststore/compare/v4.9.0-dev.8...v4.9.0) (2026-09-30)

**Note:** Version bump only for package @faststore/components

# [4.9.0-dev.8](https://github.com/vtex/faststore/compare/v4.9.0-dev.7...v4.9.0-dev.8) (2026-09-30)

**Note:** Version bump only for package @faststore/components

# [4.9.0-dev.7](https://github.com/vtex/faststore/compare/v4.9.0-dev.6...v4.9.0-dev.7) (2026-09-29)

**Note:** Version bump only for package @faststore/components

# [4.9.0-dev.6](https://github.com/vtex/faststore/compare/v4.9.0-dev.5...v4.9.0-dev.6) (2026-09-29)

**Note:** Version bump only for package @faststore/components

# [4.9.0-dev.5](https://github.com/vtex/faststore/compare/v4.9.0-dev.4...v4.9.0-dev.5) (2026-09-29)

**Note:** Version bump only for package @faststore/components

# [4.9.0-dev.4](https://github.com/vtex/faststore/compare/v4.9.0-dev.3...v4.9.0-dev.4) (2026-09-28)

**Note:** Version bump only for package @faststore/components

# [4.9.0-dev.3](https://github.com/vtex/faststore/compare/v4.9.0-dev.2...v4.9.0-dev.3) (2026-09-28)

**Note:** Version bump only for package @faststore/components

# [4.9.0-dev.2](https://github.com/vtex/faststore/compare/v4.9.0-dev.1...v4.9.0-dev.2) (2026-09-28)

**Note:** Version bump only for package @faststore/components

# [4.9.0-dev.1](https://github.com/vtex/faststore/compare/v4.9.0-dev.0...v4.9.0-dev.1) (2026-09-28)

**Note:** Version bump only for package @faststore/components

# [4.9.0-dev.0](https://github.com/vtex/faststore/compare/v4.8.1-dev.3...v4.9.0-dev.0) (2026-09-24)

**Note:** Version bump only for package @faststore/components

## [4.8.1-dev.3](https://github.com/vtex/faststore/compare/v4.8.1-dev.2...v4.8.1-dev.3) (2026-09-22)

**Note:** Version bump only for package @faststore/components

## [4.8.1-dev.2](https://github.com/vtex/faststore/compare/v4.8.1-dev.1...v4.8.1-dev.2) (2026-09-21)

**Note:** Version bump only for package @faststore/components

## [4.8.1-dev.1](https://github.com/vtex/faststore/compare/v4.8.1-dev.0...v4.8.1-dev.1) (2026-09-18)

**Note:** Version bump only for package @faststore/components

## [4.8.1-dev.0](https://github.com/vtex/faststore/compare/v4.8.0...v4.8.1-dev.0) (2026-09-15)

**Note:** Version bump only for package @faststore/components

# [4.8.0](https://github.com/vtex/faststore/compare/v4.7.0...v4.8.0) (2026-09-15)

### Features

- release 4.8.0 (graduate dev → main) ([#3488](https://github.com/vtex/faststore/issues/3488)) ([09ff84a](https://github.com/vtex/faststore/commit/09ff84aabe1f5a5a74fe52c191f37e5521dd8e9b)), closes [#3466](https://github.com/vtex/faststore/issues/3466) [#3481](https://github.com/vtex/faststore/issues/3481) [#3487](https://github.com/vtex/faststore/issues/3487) [#3453](https://github.com/vtex/faststore/issues/3453) [#3484](https://github.com/vtex/faststore/issues/3484) [#3482](https://github.com/vtex/faststore/issues/3482) [#3476](https://github.com/vtex/faststore/issues/3476) [#3477](https://github.com/vtex/faststore/issues/3477) [#3474](https://github.com/vtex/faststore/issues/3474) [#3422](https://github.com/vtex/faststore/issues/3422) [#3470](https://github.com/vtex/faststore/issues/3470)

# [4.8.0-dev.8](https://github.com/vtex/faststore/compare/v4.8.0-dev.7...v4.8.0-dev.8) (2026-09-14)

**Note:** Version bump only for package @faststore/components

# [4.8.0-dev.7](https://github.com/vtex/faststore/compare/v4.8.0-dev.6...v4.8.0-dev.7) (2026-09-14)

**Note:** Version bump only for package @faststore/components

# [4.8.0-dev.6](https://github.com/vtex/faststore/compare/v4.8.0-dev.5...v4.8.0-dev.6) (2026-09-11)

**Note:** Version bump only for package @faststore/components

# [4.8.0-dev.5](https://github.com/vtex/faststore/compare/v4.8.0-dev.4...v4.8.0-dev.5) (2026-09-09)

**Note:** Version bump only for package @faststore/components

# [4.8.0-dev.4](https://github.com/vtex/faststore/compare/v4.8.0-dev.3...v4.8.0-dev.4) (2026-09-08)

**Note:** Version bump only for package @faststore/components

# [4.8.0-dev.3](https://github.com/vtex/faststore/compare/v4.8.0-dev.2...v4.8.0-dev.3) (2026-09-08)

**Note:** Version bump only for package @faststore/components

# [4.8.0-dev.2](https://github.com/vtex/faststore/compare/v4.8.0-dev.1...v4.8.0-dev.2) (2026-09-07)

**Note:** Version bump only for package @faststore/components

# [4.8.0-dev.1](https://github.com/vtex/faststore/compare/v4.8.0-dev.0...v4.8.0-dev.1) (2026-09-03)

**Note:** Version bump only for package @faststore/components

# [4.8.0-dev.0](https://github.com/vtex/faststore/compare/v4.7.1-dev.2...v4.8.0-dev.0) (2026-09-03)

### Features

- **cart:** add recommendations shelf to cart drawer ([879bda5](https://github.com/vtex/faststore/commit/879bda58bcae0094b868d5d8ce5a1b594ae7007f))

## [4.7.1-dev.2](https://github.com/vtex/faststore/compare/v4.7.1-dev.1...v4.7.1-dev.2) (2026-09-02)

**Note:** Version bump only for package @faststore/components

## [4.7.1-dev.1](https://github.com/vtex/faststore/compare/v4.7.1-dev.0...v4.7.1-dev.1) (2026-09-01)

**Note:** Version bump only for package @faststore/components

## [4.7.1-dev.0](https://github.com/vtex/faststore/compare/v4.7.0...v4.7.1-dev.0) (2026-08-31)

**Note:** Version bump only for package @faststore/components

# [4.7.0](https://github.com/vtex/faststore/compare/v4.7.0-dev.9...v4.7.0) (2026-08-31)

**Note:** Version bump only for package @faststore/components

# [4.7.0-dev.9](https://github.com/vtex/faststore/compare/v4.7.0-dev.8...v4.7.0-dev.9) (2026-08-31)

**Note:** Version bump only for package @faststore/components

# [4.7.0-dev.8](https://github.com/vtex/faststore/compare/v4.7.0-dev.7...v4.7.0-dev.8) (2026-08-28)

**Note:** Version bump only for package @faststore/components

# [4.7.0-dev.7](https://github.com/vtex/faststore/compare/v4.7.0-dev.6...v4.7.0-dev.7) (2026-08-28)

**Note:** Version bump only for package @faststore/components

# [4.7.0-dev.6](https://github.com/vtex/faststore/compare/v4.7.0-dev.5...v4.7.0-dev.6) (2026-08-26)

**Note:** Version bump only for package @faststore/components

# [4.7.0-dev.5](https://github.com/vtex/faststore/compare/v4.7.0-dev.4...v4.7.0-dev.5) (2026-08-25)

**Note:** Version bump only for package @faststore/components

# [4.7.0-dev.4](https://github.com/vtex/faststore/compare/v4.7.0-dev.3...v4.7.0-dev.4) (2026-08-25)

**Note:** Version bump only for package @faststore/components

# [4.7.0-dev.3](https://github.com/vtex/faststore/compare/v4.7.0-dev.2...v4.7.0-dev.3) (2026-08-25)

**Note:** Version bump only for package @faststore/components

# [4.7.0-dev.2](https://github.com/vtex/faststore/compare/v4.7.0-dev.1...v4.7.0-dev.2) (2026-08-24)

**Note:** Version bump only for package @faststore/components

# [4.7.0-dev.1](https://github.com/vtex/faststore/compare/v4.7.0-dev.0...v4.7.0-dev.1) (2026-08-24)

**Note:** Version bump only for package @faststore/components

# [4.7.0-dev.0](https://github.com/vtex/faststore/compare/v4.6.1-dev.0...v4.7.0-dev.0) (2026-08-24)

**Note:** Version bump only for package @faststore/components

## [4.6.1-dev.0](https://github.com/vtex/faststore/compare/v4.6.0...v4.6.1-dev.0) (2026-08-18)

**Note:** Version bump only for package @faststore/components

# [4.6.0](https://github.com/vtex/faststore/compare/v4.6.0-dev.6...v4.6.0) (2026-08-18)

**Note:** Version bump only for package @faststore/components

# [4.6.0-dev.6](https://github.com/vtex/faststore/compare/v4.6.0-dev.5...v4.6.0-dev.6) (2026-08-14)

**Note:** Version bump only for package @faststore/components

# [4.6.0-dev.5](https://github.com/vtex/faststore/compare/v4.6.0-dev.4...v4.6.0-dev.5) (2026-08-13)

**Note:** Version bump only for package @faststore/components

# [4.6.0-dev.4](https://github.com/vtex/faststore/compare/v4.6.0-dev.3...v4.6.0-dev.4) (2026-08-12)

**Note:** Version bump only for package @faststore/components

# [4.6.0-dev.3](https://github.com/vtex/faststore/compare/v4.6.0-dev.2...v4.6.0-dev.3) (2026-08-12)

**Note:** Version bump only for package @faststore/components

# [4.6.0-dev.2](https://github.com/vtex/faststore/compare/v4.6.0-dev.1...v4.6.0-dev.2) (2026-08-12)

**Note:** Version bump only for package @faststore/components

# [4.6.0-dev.1](https://github.com/vtex/faststore/compare/v4.6.0-dev.0...v4.6.0-dev.1) (2026-08-11)

## [4.5.1](https://github.com/vtex/faststore/compare/v4.5.1-dev.4...v4.5.1) (2026-08-11)

**Note:** Version bump only for package @faststore/components

# [4.6.0-dev.0](https://github.com/vtex/faststore/compare/v4.5.1-dev.4...v4.6.0-dev.0) (2026-08-11)

**Note:** Version bump only for package @faststore/components

## [4.5.1-dev.4](https://github.com/vtex/faststore/compare/v4.5.1-dev.3...v4.5.1-dev.4) (2026-08-10)

**Note:** Version bump only for package @faststore/components

## [4.5.1-dev.3](https://github.com/vtex/faststore/compare/v4.5.1-dev.2...v4.5.1-dev.3) (2026-08-10)

## [4.5.1](https://github.com/vtex/faststore/compare/v4.5.1-dev.2...v4.5.1) (2026-08-11)

**Note:** Version bump only for package @faststore/components

## [4.5.1-dev.2](https://github.com/vtex/faststore/compare/v4.5.1-dev.1...v4.5.1-dev.2) (2026-08-04)

**Note:** Version bump only for package @faststore/components

## [4.5.1-dev.1](https://github.com/vtex/faststore/compare/v4.5.1-dev.0...v4.5.1-dev.1) (2026-08-04)

**Note:** Version bump only for package @faststore/components

## [4.5.1-dev.0](https://github.com/vtex/faststore/compare/v4.5.0...v4.5.1-dev.0) (2026-08-03)

**Note:** Version bump only for package @faststore/components

# [4.5.0](https://github.com/vtex/faststore/compare/v4.5.0-dev.7...v4.5.0) (2026-08-03)

**Note:** Version bump only for package @faststore/components

# [4.5.0-dev.7](https://github.com/vtex/faststore/compare/v4.5.0-dev.6...v4.5.0-dev.7) (2026-08-03)

**Note:** Version bump only for package @faststore/components

# [4.5.0-dev.6](https://github.com/vtex/faststore/compare/v4.5.0-dev.5...v4.5.0-dev.6) (2026-07-28)

**Note:** Version bump only for package @faststore/components

# [4.5.0-dev.5](https://github.com/vtex/faststore/compare/v4.5.0-dev.4...v4.5.0-dev.5) (2026-07-27)

### Features

- forward Pricing Fallback price token to Checkout ([#3415](https://github.com/vtex/faststore/issues/3415)) ([bc6cda2](https://github.com/vtex/faststore/commit/bc6cda2cdaed0540896ca7202246ad2d3dcd5766))

# [4.5.0-dev.4](https://github.com/vtex/faststore/compare/v4.5.0-dev.3...v4.5.0-dev.4) (2026-07-24)

**Note:** Version bump only for package @faststore/components

# [4.5.0-dev.3](https://github.com/vtex/faststore/compare/v4.5.0-dev.2...v4.5.0-dev.3) (2026-07-22)

**Note:** Version bump only for package @faststore/components

# [4.5.0-dev.2](https://github.com/vtex/faststore/compare/v4.5.0-dev.1...v4.5.0-dev.2) (2026-07-20)

**Note:** Version bump only for package @faststore/components

# [4.5.0-dev.1](https://github.com/vtex/faststore/compare/v4.5.0-dev.0...v4.5.0-dev.1) (2026-07-14)

**Note:** Version bump only for package @faststore/components

# [4.5.0-dev.0](https://github.com/vtex/faststore/compare/v4.4.1-dev.0...v4.5.0-dev.0) (2026-07-03)

**Note:** Version bump only for package @faststore/components

## [4.4.1-dev.0](https://github.com/vtex/faststore/compare/v4.4.0...v4.4.1-dev.0) (2026-07-02)

**Note:** Version bump only for package @faststore/components

# [4.4.0](https://github.com/vtex/faststore/compare/v4.4.0-dev.6...v4.4.0) (2026-07-02)

**Note:** Version bump only for package @faststore/components

# [4.4.0-dev.6](https://github.com/vtex/faststore/compare/v4.4.0-dev.5...v4.4.0-dev.6) (2026-07-02)

**Note:** Version bump only for package @faststore/components

# [4.4.0-dev.5](https://github.com/vtex/faststore/compare/v4.4.0-dev.4...v4.4.0-dev.5) (2026-07-01)

**Note:** Version bump only for package @faststore/components

# [4.4.0-dev.4](https://github.com/vtex/faststore/compare/v4.4.0-dev.3...v4.4.0-dev.4) (2026-06-30)

**Note:** Version bump only for package @faststore/components

# [4.4.0-dev.3](https://github.com/vtex/faststore/compare/v4.4.0-dev.2...v4.4.0-dev.3) (2026-06-29)

**Note:** Version bump only for package @faststore/components

# [4.4.0-dev.2](https://github.com/vtex/faststore/compare/v4.4.0-dev.1...v4.4.0-dev.2) (2026-06-25)

**Note:** Version bump only for package @faststore/components

# [4.4.0-dev.1](https://github.com/vtex/faststore/compare/v4.4.0-dev.0...v4.4.0-dev.1) (2026-06-24)

**Note:** Version bump only for package @faststore/components

# [4.4.0-dev.0](https://github.com/vtex/faststore/compare/v4.3.1-dev.0...v4.4.0-dev.0) (2026-06-19)

**Note:** Version bump only for package @faststore/components

## [4.3.1-dev.0](https://github.com/vtex/faststore/compare/v4.3.0-dev.8...v4.3.1-dev.0) (2026-06-17)

**Note:** Version bump only for package @faststore/components

# [4.3.0](https://github.com/vtex/faststore/compare/v4.2.0...v4.3.0) (2026-06-17)

### Features

- graduate v4.3.0 ([#3396](https://github.com/vtex/faststore/issues/3396)) ([b489766](https://github.com/vtex/faststore/commit/b4897664c7826dcd59bfde7c3599c93259d4d11f)), closes [#3276](https://github.com/vtex/faststore/issues/3276) [#3334](https://github.com/vtex/faststore/issues/3334) [#3386](https://github.com/vtex/faststore/issues/3386) [#3380](https://github.com/vtex/faststore/issues/3380) [#3394](https://github.com/vtex/faststore/issues/3394) [#3395](https://github.com/vtex/faststore/issues/3395) [#3381](https://github.com/vtex/faststore/issues/3381) [#3379](https://github.com/vtex/faststore/issues/3379) [#3375](https://github.com/vtex/faststore/issues/3375)

# [4.3.0-dev.8](https://github.com/vtex/faststore/compare/v4.3.0-dev.7...v4.3.0-dev.8) (2026-06-17)

### Features

- Password Protection (v4) ([#3276](https://github.com/vtex/faststore/issues/3276)) ([575f162](https://github.com/vtex/faststore/commit/575f162f6ec6fda9d3134ab61f673a897dcc2f56))

# [4.3.0-dev.7](https://github.com/vtex/faststore/compare/v4.3.0-dev.6...v4.3.0-dev.7) (2026-06-17)

**Note:** Version bump only for package @faststore/components

# [4.3.0-dev.6](https://github.com/vtex/faststore/compare/v4.3.0-dev.5...v4.3.0-dev.6) (2026-06-17)

**Note:** Version bump only for package @faststore/components

# [4.3.0-dev.5](https://github.com/vtex/faststore/compare/v4.3.0-dev.4...v4.3.0-dev.5) (2026-06-16)

**Note:** Version bump only for package @faststore/components

# [4.3.0-dev.4](https://github.com/vtex/faststore/compare/v4.3.0-dev.3...v4.3.0-dev.4) (2026-06-15)

**Note:** Version bump only for package @faststore/components

# [4.3.0-dev.3](https://github.com/vtex/faststore/compare/v4.3.0-dev.2...v4.3.0-dev.3) (2026-06-15)

**Note:** Version bump only for package @faststore/components

# [4.3.0-dev.2](https://github.com/vtex/faststore/compare/v4.3.0-dev.1...v4.3.0-dev.2) (2026-06-10)

### Features

- file upload via Order Entry Service (OES) ([#3334](https://github.com/vtex/faststore/issues/3334)) ([03edc11](https://github.com/vtex/faststore/commit/03edc11952ea61fda4127aae4812b204845ecdb1))

## [Unreleased]

### Breaking Changes

- Removed `useCSVParser`, `CSVData`, `CSVParserError`, and `CSVParserOptions` from `@faststore/components`. CSV parsing is now handled internally by the Order Entry Service flow in `@faststore/core`. If you need custom CSV parsing in your storefront, implement the logic directly or use a third-party library such as `papaparse`.

# [4.3.0-dev.1](https://github.com/vtex/faststore/compare/v4.3.0-dev.0...v4.3.0-dev.1) (2026-06-08)

**Note:** Version bump only for package @faststore/components

# [4.3.0-dev.0](https://github.com/vtex/faststore/compare/v4.2.0...v4.3.0-dev.0) (2026-06-01)

# [4.2.0-dev.5](https://github.com/vtex/faststore/compare/v4.2.0-dev.4...v4.2.0-dev.5) (2026-06-01)

# [4.2.0-dev.4](https://github.com/vtex/faststore/compare/v4.2.0-dev.3...v4.2.0-dev.4) (2026-06-01)

# [4.2.0-dev.3](https://github.com/vtex/faststore/compare/v4.2.0-dev.2...v4.2.0-dev.3) (2026-06-01)

# [4.2.0-dev.2](https://github.com/vtex/faststore/compare/v4.2.0-dev.1...v4.2.0-dev.2) (2026-06-01)

# [4.2.0-dev.1](https://github.com/vtex/faststore/compare/v4.2.0-dev.0...v4.2.0-dev.1) (2026-06-01)

# [4.2.0-dev.0](https://github.com/vtex/faststore/compare/v4.1.2...v4.2.0-dev.0) (2026-06-01)

## [4.1.2-dev.8](https://github.com/vtex/faststore/compare/v4.1.2-dev.7...v4.1.2-dev.8) (2026-05-28)

## [4.1.2-dev.7](https://github.com/vtex/faststore/compare/v4.1.2-dev.6...v4.1.2-dev.7) (2026-05-28)

## [4.1.2-dev.6](https://github.com/vtex/faststore/compare/v4.1.2-dev.5...v4.1.2-dev.6) (2026-05-27)

## [4.1.2-dev.5](https://github.com/vtex/faststore/compare/v4.1.2-dev.4...v4.1.2-dev.5) (2026-05-21)

## [4.1.2-dev.4](https://github.com/vtex/faststore/compare/v4.1.2-dev.3...v4.1.2-dev.4) (2026-05-20)

## [4.1.2-dev.3](https://github.com/vtex/faststore/compare/v4.1.2-dev.2...v4.1.2-dev.3) (2026-05-20)

## [4.1.2-dev.2](https://github.com/vtex/faststore/compare/v4.1.2-dev.1...v4.1.2-dev.2) (2026-05-19)

## [4.1.2-dev.1](https://github.com/vtex/faststore/compare/v4.1.1...v4.1.2-dev.1) (2026-05-19)

## [4.1.1-dev.1](https://github.com/vtex/faststore/compare/v4.1.0-dev.11...v4.1.1-dev.1) (2026-05-15)

# [4.1.0-dev.11](https://github.com/vtex/faststore/compare/v4.1.0-dev.10...v4.1.0-dev.11) (2026-05-15)

# [4.1.0-dev.10](https://github.com/vtex/faststore/compare/v4.1.0-dev.8...v4.1.0-dev.10) (2026-05-15)

# [4.1.0-dev.8](https://github.com/vtex/faststore/compare/v4.1.0-dev.7...v4.1.0-dev.8) (2026-05-15)

# [4.1.0-dev.7](https://github.com/vtex/faststore/compare/v4.1.0-dev.6...v4.1.0-dev.7) (2026-05-15)

# [4.1.0-dev.6](https://github.com/vtex/faststore/compare/v4.1.0-dev.5...v4.1.0-dev.6) (2026-05-14)

# [4.1.0-dev.5](https://github.com/vtex/faststore/compare/v4.1.0-dev.4...v4.1.0-dev.5) (2026-05-14)

# [4.1.0-dev.4](https://github.com/vtex/faststore/compare/v4.1.0-dev.3...v4.1.0-dev.4) (2026-05-13)

# [4.1.0-dev.3](https://github.com/vtex/faststore/compare/v4.1.0-dev.2...v4.1.0-dev.3) (2026-05-13)

# [4.1.0-dev.2](https://github.com/vtex/faststore/compare/v4.1.0...v4.1.0-dev.2) (2026-05-12)

# [4.1.0-dev.1](https://github.com/vtex/faststore/compare/v4.1.0-dev.0...v4.1.0-dev.1) (2026-05-11)

# [4.1.0-dev.0](https://github.com/vtex/faststore/compare/v4.0.1-dev.2...v4.1.0-dev.0) (2026-05-11)

## [4.0.1-dev.2](https://github.com/vtex/faststore/compare/v4.0.1-dev.1...v4.0.1-dev.2) (2026-05-11)

## [4.0.1-dev.1](https://github.com/vtex/faststore/compare/v4.0.1-dev.0...v4.0.1-dev.1) (2026-05-07)

## [4.0.1-dev.0](https://github.com/vtex/faststore/compare/v4.0.0...v4.0.1-dev.0) (2026-05-07)

# [4.0.0-dev.4](https://github.com/vtex/faststore/compare/v4.0.0-dev.3...v4.0.0-dev.4) (2026-05-07)

# [4.0.0-dev.3](https://github.com/vtex/faststore/compare/v4.0.0-dev.2...v4.0.0-dev.3) (2026-05-07)

# [4.0.0-dev.2](https://github.com/vtex/faststore/compare/v4.0.0-dev.1...v4.0.0-dev.2) (2026-05-07)

# [4.0.0-dev.0](https://github.com/vtex/faststore/compare/v3.99.0...v4.0.0-dev.0) (2026-05-07)

# [3.99.0-dev.8](https://github.com/vtex/faststore/compare/v3.99.0-dev.7...v3.99.0-dev.8) (2026-05-04)

# [3.99.0-dev.6](https://github.com/vtex/faststore/compare/v3.99.0-dev.4...v3.99.0-dev.6) (2026-05-04)

# [3.99.0-dev.4](https://github.com/vtex/faststore/compare/v3.99.0-dev.3...v3.99.0-dev.4) (2026-04-28)

# [3.99.0-dev.3](https://github.com/vtex/faststore/compare/v3.99.0-dev.2...v3.99.0-dev.3) (2026-04-23)

# [3.99.0-dev.1](https://github.com/vtex/faststore/compare/v3.98.4...v3.99.0-dev.1) (2026-04-15)

## [3.98.1-dev.0](https://github.com/vtex/faststore/compare/v3.98.0...v3.98.1-dev.0) (2026-03-27)

# [3.98.0-dev.8](https://github.com/vtex/faststore/compare/v3.98.0-dev.7...v3.98.0-dev.8) (2026-03-27)

### Features

- Add Quick Order Full Feature ([#3197](https://github.com/vtex/faststore/issues/3197)) ([f5518d7](https://github.com/vtex/faststore/commit/f5518d7f205dccad99b6ea0a127fd09cf77d1edb))

# [3.98.0-dev.3](https://github.com/vtex/faststore/compare/v3.98.0-dev.2...v3.98.0-dev.3) (2026-03-12)

### Features

- Add ActivityFlow data parameters with search-related information ([#3105](https://github.com/vtex/faststore/issues/3105)) ([8f69ff8](https://github.com/vtex/faststore/commit/8f69ff855c31abedba66071132240c53a93ab56d))

# [3.98.0-dev.1](https://github.com/vtex/faststore/compare/v3.98.0-dev.0...v3.98.0-dev.1) (2026-02-24)

# [3.98.0-dev.0](https://github.com/vtex/faststore/compare/v3.97.1...v3.98.0-dev.0) (2026-02-24)

# [3.97.0-dev.2](https://github.com/vtex/faststore/compare/v3.97.0...v3.97.0-dev.2) (2026-02-06)

## [3.96.4-dev.0](https://github.com/vtex/faststore/compare/v3.96.3...v3.96.4-dev.0) (2026-01-21)

# [3.96.0-dev.22](https://github.com/vtex/faststore/compare/v3.96.2...v3.96.0-dev.22) (2026-01-21)

# [3.96.0-dev.18](https://github.com/vtex/faststore/compare/v3.96.0-dev.17...v3.96.0-dev.18) (2025-12-24)

# [3.96.0-dev.17](https://github.com/vtex/faststore/compare/v3.96.0-dev.16...v3.96.0-dev.17) (2025-12-23)

# [3.96.0-dev.16](https://github.com/vtex/faststore/compare/v3.96.0-dev.15...v3.96.0-dev.16) (2025-12-23)

# [3.96.0-dev.11](https://github.com/vtex/faststore/compare/v3.96.0-dev.10...v3.96.0-dev.11) (2025-12-23)

# [3.96.0-dev.10](https://github.com/vtex/faststore/compare/v3.96.0-dev.9...v3.96.0-dev.10) (2025-12-23)

# [3.96.0-dev.9](https://github.com/vtex/faststore/compare/v3.96.0-dev.8...v3.96.0-dev.9) (2025-12-23)

# [3.96.0-dev.8](https://github.com/vtex/faststore/compare/v3.96.0-dev.7...v3.96.0-dev.8) (2025-12-23)

# [3.96.0-dev.7](https://github.com/vtex/faststore/compare/v3.96.0-dev.6...v3.96.0-dev.7) (2025-12-23)

# [3.96.0-dev.6](https://github.com/vtex/faststore/compare/v3.96.0-dev.5...v3.96.0-dev.6) (2025-12-23)

# [3.96.0-dev.5](https://github.com/vtex/faststore/compare/v3.96.0-dev.4...v3.96.0-dev.5) (2025-12-23)

# [3.96.0-dev.4](https://github.com/vtex/faststore/compare/v3.96.0-dev.3...v3.96.0-dev.4) (2025-12-23)

## [3.95.1-dev.0](https://github.com/vtex/faststore/compare/v3.95.0...v3.95.1-dev.0) (2025-12-02)

# [3.95.0-dev.3](https://github.com/vtex/faststore/compare/v3.95.0-dev.2...v3.95.0-dev.3) (2025-12-02)

# [3.95.0-dev.1](https://github.com/vtex/faststore/compare/v3.95.0-dev.0...v3.95.0-dev.1) (2025-12-01)

## [3.94.1-dev.0](https://github.com/vtex/faststore/compare/v3.94.0...v3.94.1-dev.0) (2025-11-19)

# [3.93.0-dev.3](https://github.com/vtex/faststore/compare/v3.93.0-dev.2...v3.93.0-dev.3) (2025-11-17)

# [3.93.0-dev.1](https://github.com/vtex/faststore/compare/v3.93.0...v3.93.0-dev.1) (2025-11-06)

# [3.93.0-dev.0](https://github.com/vtex/faststore/compare/v3.92.1-dev.0...v3.93.0-dev.0) (2025-11-03)

### Features

- Add RTL Support ([#3097](https://github.com/vtex/faststore/issues/3097)) ([e293857](https://github.com/vtex/faststore/commit/e293857070b265419aee793ba09fd0795e7d7b44))

## [3.92.1-dev.0](https://github.com/vtex/faststore/compare/v3.92.0...v3.92.1-dev.0) (2025-11-03)

## [3.91.3-dev.0](https://github.com/vtex/faststore/compare/v3.91.2...v3.91.3-dev.0) (2025-10-30)

# [4.2.0-dev.5](https://github.com/vtex/faststore/compare/v4.2.0-dev.4...v4.2.0-dev.5) (2026-06-01)

**Note:** Version bump only for package @faststore/components

# 4.2.0-dev.4 (2026-06-01)

### Bug Fixes

- preview pnpm pack ([#3367](https://github.com/vtex/faststore/issues/3367)) ([186579c](https://github.com/vtex/faststore/commit/186579c4cca44e4d21c25068f075c0fbb6a56d96))

# [4.2.0-dev.3](https://github.com/vtex/faststore/compare/v4.2.0-dev.2...v4.2.0-dev.3) (2026-06-01)

**Note:** Version bump only for package @faststore/components

# [4.2.0-dev.2](https://github.com/vtex/faststore/compare/v4.2.0-dev.1...v4.2.0-dev.2) (2026-06-01)

**Note:** Version bump only for package @faststore/components

# 4.2.0-dev.1 (2026-06-01)

### Bug Fixes

- createNextJSPages throwing preventing copy of store discovery-co… ([#3356](https://github.com/vtex/faststore/issues/3356)) ([cf318ab](https://github.com/vtex/faststore/commit/cf318abfecf4c6497d40bfe58203acc90b199696))

# [4.2.0-dev.0](https://github.com/vtex/faststore/compare/v4.1.2-dev.8...v4.2.0-dev.0) (2026-06-01)

**Note:** Version bump only for package @faststore/components

## [4.1.2-dev.8](https://github.com/vtex/faststore/compare/v4.1.2-dev.7...v4.1.2-dev.8) (2026-05-28)

**Note:** Version bump only for package @faststore/components

## [4.1.2-dev.7](https://github.com/vtex/faststore/compare/v4.1.2-dev.6...v4.1.2-dev.7) (2026-05-28)

**Note:** Version bump only for package @faststore/components

## [4.1.2-dev.6](https://github.com/vtex/faststore/compare/v4.1.2-dev.5...v4.1.2-dev.6) (2026-05-27)

**Note:** Version bump only for package @faststore/components

## [4.1.2-dev.5](https://github.com/vtex/faststore/compare/v4.1.2-dev.4...v4.1.2-dev.5) (2026-05-21)

**Note:** Version bump only for package @faststore/components

## [4.1.2-dev.4](https://github.com/vtex/faststore/compare/v4.1.2-dev.3...v4.1.2-dev.4) (2026-05-20)

**Note:** Version bump only for package @faststore/components

## [4.1.2-dev.3](https://github.com/vtex/faststore/compare/v4.1.2-dev.2...v4.1.2-dev.3) (2026-05-20)

**Note:** Version bump only for package @faststore/components

## [4.1.2-dev.2](https://github.com/vtex/faststore/compare/v4.1.2-dev.1...v4.1.2-dev.2) (2026-05-19)

**Note:** Version bump only for package @faststore/components

## 4.1.2-dev.1 (2026-05-19)

**Note:** Version bump only for package @faststore/components

## 4.1.2-dev.0 (2026-05-15)

**Note:** Version bump only for package @faststore/components

## 4.1.1 (2026-05-15)

### Bug Fixes

- graduate version 4.1.1 ([#3331](https://github.com/vtex/faststore/issues/3331)) ([c26d990](https://github.com/vtex/faststore/commit/c26d990010d8643ceb2ed95ab1737f4eca80e240))
- version bump 4.1.1 ([#3329](https://github.com/vtex/faststore/issues/3329)) ([59345b3](https://github.com/vtex/faststore/commit/59345b3584c3ec5fc6f532e1b5c1bcce9c5c5b97)), closes [#3318](https://github.com/vtex/faststore/issues/3318) [#3312](https://github.com/vtex/faststore/issues/3312) [#3319](https://github.com/vtex/faststore/issues/3319) [#3327](https://github.com/vtex/faststore/issues/3327) [#3320](https://github.com/vtex/faststore/issues/3320) [#3314](https://github.com/vtex/faststore/issues/3314) [#3317](https://github.com/vtex/faststore/issues/3317)

## [4.1.1-dev.1](https://github.com/vtex/faststore/compare/v4.1.0-dev.11...v4.1.1-dev.1) (2026-05-15)

**Note:** Version bump only for package @faststore/components

# 4.1.0-dev.11 (2026-05-15)

**Note:** Version bump only for package @faststore/components

# [4.1.0-dev.10](https://github.com/vtex/faststore/compare/v4.1.0...v4.1.0-dev.10) (2026-05-15)

**Note:** Version bump only for package @faststore/components

# [4.1.0-dev.9](https://github.com/vtex/faststore/compare/v4.1.0-dev.8...v4.1.0-dev.9) (2026-05-15)

**Note:** Version bump only for package @faststore/components

# [4.1.0-dev.8](https://github.com/vtex/faststore/compare/v4.1.0-dev.7...v4.1.0-dev.8) (2026-05-15)

**Note:** Version bump only for package @faststore/components

# [4.1.0-dev.7](https://github.com/vtex/faststore/compare/v4.1.0-dev.6...v4.1.0-dev.7) (2026-05-15)

**Note:** Version bump only for package @faststore/components

# [4.1.0-dev.6](https://github.com/vtex/faststore/compare/v4.1.0-dev.5...v4.1.0-dev.6) (2026-05-14)

**Note:** Version bump only for package @faststore/components

# [4.1.0-dev.5](https://github.com/vtex/faststore/compare/v4.1.0-dev.4...v4.1.0-dev.5) (2026-05-14)

**Note:** Version bump only for package @faststore/components

# [4.1.0-dev.4](https://github.com/vtex/faststore/compare/v4.1.0-dev.3...v4.1.0-dev.4) (2026-05-13)

**Note:** Version bump only for package @faststore/components

# [4.1.0-dev.3](https://github.com/vtex/faststore/compare/v4.1.0-dev.2...v4.1.0-dev.3) (2026-05-13)

**Note:** Version bump only for package @faststore/components

# [4.1.0-dev.2](https://github.com/vtex/faststore/compare/v4.1.0-dev.1...v4.1.0-dev.2) (2026-05-12)

**Note:** Version bump only for package @faststore/components

# 4.1.0 (2026-05-11)

### Features

- version bump 4.1.0 ([#3310](https://github.com/vtex/faststore/issues/3310)) ([1ea7bac](https://github.com/vtex/faststore/commit/1ea7bac649d783e50a9e79f8fe412009ae4a87f7)), closes [#3309](https://github.com/vtex/faststore/issues/3309) [#3308](https://github.com/vtex/faststore/issues/3308) [#3306](https://github.com/vtex/faststore/issues/3306) [#3304](https://github.com/vtex/faststore/issues/3304) [#3301](https://github.com/vtex/faststore/issues/3301)

# [4.1.0-dev.1](https://github.com/vtex/faststore/compare/v4.1.0-dev.0...v4.1.0-dev.1) (2026-05-11)

**Note:** Version bump only for package @faststore/components

# [4.1.0-dev.0](https://github.com/vtex/faststore/compare/v4.0.1-dev.2...v4.1.0-dev.0) (2026-05-11)

**Note:** Version bump only for package @faststore/components

## [4.0.1-dev.2](https://github.com/vtex/faststore/compare/v4.0.1-dev.1...v4.0.1-dev.2) (2026-05-11)

**Note:** Version bump only for package @faststore/components

## [4.0.1-dev.1](https://github.com/vtex/faststore/compare/v4.0.1-dev.0...v4.0.1-dev.1) (2026-05-07)

**Note:** Version bump only for package @faststore/components

## [4.0.1-dev.0](https://github.com/vtex/faststore/compare/v4.0.0...v4.0.1-dev.0) (2026-05-07)

**Note:** Version bump only for package @faststore/components

# [4.0.0](https://github.com/vtex/faststore/compare/v3.99.0...v4.0.0) (2026-05-07)

### Features

- FastStore v4 ([#3302](https://github.com/vtex/faststore/issues/3302)) ([c7ca1a2](https://github.com/vtex/faststore/commit/c7ca1a2a9a6161bdf30e33a965ecf2fda9ef3fbf))

# [4.0.0-dev.4](https://github.com/vtex/faststore/compare/v4.0.0-dev.3...v4.0.0-dev.4) (2026-05-07)

**Note:** Version bump only for package @faststore/components

# [4.0.0-dev.3](https://github.com/vtex/faststore/compare/v4.0.0-dev.2...v4.0.0-dev.3) (2026-05-07)

**Note:** Version bump only for package @faststore/components

# [4.0.0-dev.2](https://github.com/vtex/faststore/compare/v4.0.0-dev.1...v4.0.0-dev.2) (2026-05-07)

**Note:** Version bump only for package @faststore/components

# 3.99.0-dev.9 (2026-05-07)

### Bug Fixes

- release command ([e912b5e](https://github.com/vtex/faststore/commit/e912b5e10cf61e65f24502fb077c06799009da61))

# 3.99.0-dev.8 (2026-05-04)

**Note:** Version bump only for package @faststore/components

## [Unreleased]

### Features

- Added `useCSVParser` hook for parsing CSV files in a web worker, with error handling and CSV template generation.
- Added `useFileUpload` hook to manage file upload errors, validation, and rejection reasons.
- Added `FileUploadCard` component for file selection, drag-and-drop, and template download, with error state and file validation.

# 3.99.0-dev.6 (2026-05-04)

**Note:** Version bump only for package @faststore/components

# 3.99.0-dev.5 (2026-05-04)

### Bug Fixes

- Enhance session validation logic to skip token refresh in local … ([#3285](https://github.com/vtex/faststore/issues/3285)) ([41a330a](https://github.com/vtex/faststore/commit/41a330a9704a29369141e6e78b1f6d01e5a2e1a5))

# 3.99.0-dev.4 (2026-04-28)

**Note:** Version bump only for package @faststore/components

# 3.99.0-dev.3 (2026-04-23)

### Features

- add isGift field to StoreOffer type and resolvers - SFS-3040 ([#3220](https://github.com/vtex/faststore/issues/3220)) ([e10fc92](https://github.com/vtex/faststore/commit/e10fc92633a5296a5b03286028d31d9c280561c6))

# [3.99.0-dev.1](https://github.com/vtex/faststore/compare/v3.99.0-dev.0...v3.99.0-dev.1) (2026-04-15)

**Note:** Version bump only for package @faststore/components

## [3.98.1](https://github.com/vtex/faststore/compare/v3.98.0...v3.98.1) (2026-04-07)

### Bug Fixes

- simplify city and postal code display logic in `RegionBar` and `RegionButton` ([#3259](https://github.com/vtex/faststore/issues/3259)) ([8944bee](https://github.com/vtex/faststore/commit/8944bee9cb92ccea2b6ca24309cfa5478b6f4d0d))

## [3.98.1-dev.0](https://github.com/vtex/faststore/compare/v3.98.0-dev.10...v3.98.1-dev.0) (2026-03-27)

**Note:** Version bump only for package @faststore/components

# 3.98.0 (2026-03-27)

# 3.98.0 (2026-03-27)

### Bug Fixes

- Set `after` attribute as string instead of integer ([#3245](https://github.com/vtex/faststore/issues/3245)) ([c40d3fc](https://github.com/vtex/faststore/commit/c40d3fcf0018099cc067bb7082757535ca9839b0))

### Features

- version 2026 03 27 ([#3251](https://github.com/vtex/faststore/issues/3251)) ([f330a43](https://github.com/vtex/faststore/commit/f330a43661567ad8edb468acd3416bb7ffacd8b6))

# [3.98.0-dev.8](https://github.com/vtex/faststore/compare/v3.98.0-dev.7...v3.98.0-dev.8) (2026-03-27)

### Features

- Add Quick Order Full Feature ([#3197](https://github.com/vtex/faststore/issues/3197)) ([f5518d7](https://github.com/vtex/faststore/commit/f5518d7f205dccad99b6ea0a127fd09cf77d1edb))

# [3.98.0-dev.3](https://github.com/vtex/faststore/compare/v3.98.0-dev.2...v3.98.0-dev.3) (2026-03-12)

### Features

- Add ActivityFlow data parameters with search-related information ([#3105](https://github.com/vtex/faststore/issues/3105)) ([8f69ff8](https://github.com/vtex/faststore/commit/8f69ff855c31abedba66071132240c53a93ab56d))

# 3.98.0-dev.1 (2026-02-24)

**Note:** Version bump only for package @faststore/components

# [3.98.0-dev.0](https://github.com/vtex/faststore/compare/v3.97.0-dev.6...v3.98.0-dev.0) (2026-02-24)

### Features

- release version 20260224 ([#3225](https://github.com/vtex/faststore/issues/3225)) ([7a52516](https://github.com/vtex/faststore/commit/7a5251677a8f67066a2e060191b896ae6d0b0d9a))

# [3.97.0](https://github.com/vtex/faststore/compare/v3.96.5...v3.97.0) (2026-02-03)

**Note:** Version bump only for package @faststore/components

# 3.97.0-dev.2 (2026-02-06)

## [3.96.4-dev.0](https://github.com/vtex/faststore/compare/v3.96.3...v3.96.4-dev.0) (2026-01-21)

# [3.96.0](https://github.com/vtex/faststore/compare/v3.95.0...v3.96.0) (2025-12-24)

### Features

- version 20251223 ([#3161](https://github.com/vtex/faststore/issues/3161)) ([ad5e8d1](https://github.com/vtex/faststore/commit/ad5e8d12fe45f1fb8e1134165172bf1c6b2a91e2))

# 3.96.0-dev.22 (2026-01-21)

**Note:** Version bump only for package @faststore/components

# 3.96.0-dev.18 (2025-12-24)

**Note:** Version bump only for package @faststore/components

# 3.96.0-dev.17 (2025-12-23)

**Note:** Version bump only for package @faststore/components

# [3.96.0-dev.16](https://github.com/vtex/faststore/compare/v3.96.0-dev.15...v3.96.0-dev.16) (2025-12-23)

**Note:** Version bump only for package @faststore/components

# 3.96.0-dev.11 (2025-12-23)

**Note:** Version bump only for package @faststore/components

# 3.96.0-dev.10 (2025-12-23)

**Note:** Version bump only for package @faststore/components

# [3.96.0-dev.9](https://github.com/vtex/faststore/compare/v3.96.0-dev.8...v3.96.0-dev.9) (2025-12-23)

**Note:** Version bump only for package @faststore/components

# [3.96.0-dev.8](https://github.com/vtex/faststore/compare/v3.96.0-dev.7...v3.96.0-dev.8) (2025-12-23)

**Note:** Version bump only for package @faststore/components

# 3.96.0-dev.7 (2025-12-23)

**Note:** Version bump only for package @faststore/components

# 3.96.0-dev.6 (2025-12-23)

**Note:** Version bump only for package @faststore/components

# 3.96.0-dev.5 (2025-12-23)

### Features

- Trigger build ([28b6ec0](https://github.com/vtex/faststore/commit/28b6ec0489080be0a3431ec2ead7bfce0da75a34))

# 3.96.0-dev.4 (2025-12-23)

**Note:** Version bump only for package @faststore/components

## [3.95.1-dev.0](https://github.com/vtex/faststore/compare/v3.95.0...v3.95.1-dev.0) (2025-12-02)

**Note:** Version bump only for package @faststore/components

# 3.95.0 (2025-12-02)

### Features

- release version 20250212 ([#3138](https://github.com/vtex/faststore/issues/3138)) ([5e51548](https://github.com/vtex/faststore/commit/5e5154898e3756aa8d95efd54d76db0c90248d8d))

# [3.95.0-dev.2](https://github.com/vtex/faststore/compare/v3.94.0...v3.95.0-dev.2) (2025-12-02)

### Features

- release version 20250112 ([#3135](https://github.com/vtex/faststore/issues/3135)) ([65440cd](https://github.com/vtex/faststore/commit/65440cd5607e6946b4023882eacf711c215aa138))

# 3.95.0-dev.1 (2025-12-01)

### Bug Fixes

- Update `validateCart` mutation tests ([#3132](https://github.com/vtex/faststore/issues/3132)) ([c8cbb52](https://github.com/vtex/faststore/commit/c8cbb5204562ddee126c63a576ba1f4d264092f7))

## [3.94.1-dev.0](https://github.com/vtex/faststore/compare/v3.94.0...v3.94.1-dev.0) (2025-11-19)

**Note:** Version bump only for package @faststore/components

# 3.94.0 (2025-11-19)

### Features

- release version 20251119 17 05 ([#3126](https://github.com/vtex/faststore/issues/3126)) ([9753c3f](https://github.com/vtex/faststore/commit/9753c3ff5ea760767978c41ec138b661a87ad731))
- update version to 3.93.0-dev.4 and clean up changelogs ([#3127](https://github.com/vtex/faststore/issues/3127)) ([0c29d74](https://github.com/vtex/faststore/commit/0c29d749dc2222d01d848ffda9c2ae95dfba22af))

# 3.93.0-dev.3 (2025-11-17)

**Note:** Version bump only for package @faststore/components

# 3.93.0-dev.1 (2025-11-06)

**Note:** Version bump only for package @faststore/components

# [3.93.0-dev.0](https://github.com/vtex/faststore/compare/v3.92.1-dev.0...v3.93.0-dev.0) (2025-11-03)

### Features

- Add RTL Support ([#3097](https://github.com/vtex/faststore/issues/3097)) ([e293857](https://github.com/vtex/faststore/commit/e293857070b265419aee793ba09fd0795e7d7b44))

## [3.92.1-dev.0](https://github.com/vtex/faststore/compare/v3.91.3-dev.1...v3.92.1-dev.0) (2025-11-03)

**Note:** Version bump only for package @faststore/components

# [3.92.0](https://github.com/vtex/faststore/compare/v3.91.2...v3.92.0) (2025-11-03)

### Features

- release ([#3092](https://github.com/vtex/faststore/issues/3092)) ([6dfe2ba](https://github.com/vtex/faststore/commit/6dfe2ba42dd03137ea53c85ad5aa3ee5a13c2fbf))

## 3.91.3-dev.0 (2025-10-30)

### Bug Fixes

- add background color to TextareaField label ([#3079](https://github.com/vtex/faststore/issues/3079)) ([9e5a64d](https://github.com/vtex/faststore/commit/9e5a64d51d9983f028ec5cf0004cfed633b1ee8d)), closes [#2705](https://github.com/vtex/faststore/issues/2705) [/github.com/vtex/faststore/pull/2705#pullrequestreview-2710467780](https://github.com//github.com/vtex/faststore/pull/2705/issues/pullrequestreview-2710467780) [#2705](https://github.com/vtex/faststore/issues/2705) [/github.com/vtex/faststore/pull/2705#pullrequestreview-2710467780](https://github.com//github.com/vtex/faststore/pull/2705/issues/pullrequestreview-2710467780)

## 3.91.2 (2025-10-27)

### Bug Fixes

- update buying policy alert message to include dynamic description SFS-2861 ([#3076](https://github.com/vtex/faststore/issues/3076)) ([f8f470e](https://github.com/vtex/faststore/commit/f8f470e7d70a0a2556e6136d84f57540b734b528))

## 3.89.2 (2025-10-02)

### Bug Fixes

- Filter quantity badge and labels references SFS-2896 ([#3061](https://github.com/vtex/faststore/issues/3061)) ([cfcf650](https://github.com/vtex/faststore/commit/cfcf650b5d1462c3988bc83fe2cb83981a2afa04))
- refactor `ProductShelf` component to import directly - SFS-2895 ([#3059](https://github.com/vtex/faststore/issues/3059)) ([24ee8fb](https://github.com/vtex/faststore/commit/24ee8fb8020cf037f4fe83b7ace1a747c383cbcf))

# [3.88.0](https://github.com/vtex/faststore/compare/v3.87.0...v3.88.0) (2025-09-18)

### Features

- [CP-768] adding support for lexical rich text objects ([#3004](https://github.com/vtex/faststore/issues/3004)) ([3e8fdaa](https://github.com/vtex/faststore/commit/3e8fdaa4bb728d2bde038ac96a2045f5d8670744)), closes [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R189](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R189) [/github.com/vtex/faststore/pull/3004/files#diff-fe1a4c11824f3dfcc33af60e6612a2054705df8f7273932db1b5f9c0ed023172R20](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-fe1a4c11824f3dfcc33af60e6612a2054705df8f7273932db1b5f9c0ed023172R20) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R205](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R205) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R98](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R98) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R153](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R153) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R106](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R106) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R119](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R119) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R145](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R145) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R148](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R148) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R149](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R149) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R150](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R150) [/github.com/vtex/faststore/pull/3004/files#diff-946e28ce25fa403debb36f7f2bb8bad070f7ddd8586e4dd834649afcf4b529eeR32](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-946e28ce25fa403debb36f7f2bb8bad070f7ddd8586e4dd834649afcf4b529eeR32) [/github.com/vtex/faststore/pull/3004/files#diff-3a4a8bba967d6107c9b71ef5c1a0835620593286a58dc65031f8a29e8584c071R27](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-3a4a8bba967d6107c9b71ef5c1a0835620593286a58dc65031f8a29e8584c071R27)

# [3.87.0](https://github.com/vtex/faststore/compare/v3.86.4...v3.87.0) (2025-09-18)

### Features

- Delivery Promise 2.2 - in stock filter ([#2972](https://github.com/vtex/faststore/issues/2972)) ([7bfb830](https://github.com/vtex/faststore/commit/7bfb8308c76b0914d59875fbe95d3cab6e98eba3))

## [3.86.4](https://github.com/vtex/faststore/compare/v3.86.3...v3.86.4) (2025-09-17)

### Bug Fixes

- `ShippingSimulation` table SFS-2622 ([#3030](https://github.com/vtex/faststore/issues/3030)) ([dfcb924](https://github.com/vtex/faststore/commit/dfcb9245527dd8bf90cd183fed7f556bf8b35a4d))

# [3.84.0](https://github.com/vtex/faststore/compare/v3.83.1...v3.84.0) (2025-09-09)

### Features

- Adds delivery promise badges to product card ([#2994](https://github.com/vtex/faststore/issues/2994)) ([87279c8](https://github.com/vtex/faststore/commit/87279c82a0ba83c9dffc5872b94cead98189dd23))

# 3.81.0 (2025-09-05)

### Features

- Allow users to select which CMS builder to use ([#2997](https://github.com/vtex/faststore/issues/2997)) ([3862832](https://github.com/vtex/faststore/commit/3862832aaf366453b8a26844e2c452647a534b4d))

# 3.80.0 (2025-09-04)

### Features

- add shopper phone and email in ordered by card ([#3014](https://github.com/vtex/faststore/issues/3014)) ([31bf49b](https://github.com/vtex/faststore/commit/31bf49bb717f740ad6ff741ce2ae77322ec3f5a6))

# [3.78.0](https://github.com/vtex/faststore/compare/v3.77.3...v3.78.0) (2025-09-02)

### Features

- Product Comparison ([#3000](https://github.com/vtex/faststore/issues/3000)) ([2150bee](https://github.com/vtex/faststore/commit/2150bee82e570205421859e14de8416d5e34c545))

## [3.70.2](https://github.com/vtex/faststore/compare/v3.70.1...v3.70.2) (2025-08-05)

### Bug Fixes

- Quick Order typings ([#2974](https://github.com/vtex/faststore/issues/2974)) ([e28c523](https://github.com/vtex/faststore/commit/e28c523bdc83273ad7cbb7d08cfdeb99ad676ede))

# [3.68.0](https://github.com/vtex/faststore/compare/v3.67.0...v3.68.0) (2025-07-28)

### Features

- Delivery Promise 1.2 - filters by shipping method ([#2784](https://github.com/vtex/faststore/issues/2784)) ([dacf843](https://github.com/vtex/faststore/commit/dacf843c81f19984a01f7a97ff25e3801e41ed07)), closes [#2803](https://github.com/vtex/faststore/issues/2803) [#2826](https://github.com/vtex/faststore/issues/2826) [#2845](https://github.com/vtex/faststore/issues/2845) [#2847](https://github.com/vtex/faststore/issues/2847) [#2851](https://github.com/vtex/faststore/issues/2851) [#2852](https://github.com/vtex/faststore/issues/2852) [#2847](https://github.com/vtex/faststore/issues/2847) [#2872](https://github.com/vtex/faststore/issues/2872) [#2886](https://github.com/vtex/faststore/issues/2886) [#2909](https://github.com/vtex/faststore/issues/2909) [#2916](https://github.com/vtex/faststore/issues/2916) [#2918](https://github.com/vtex/faststore/issues/2918) [#2922](https://github.com/vtex/faststore/issues/2922) [#2887](https://github.com/vtex/faststore/issues/2887) [#2944](https://github.com/vtex/faststore/issues/2944) [#2953](https://github.com/vtex/faststore/issues/2953) [#2956](https://github.com/vtex/faststore/issues/2956) [#2955](https://github.com/vtex/faststore/issues/2955) [#2961](https://github.com/vtex/faststore/issues/2961) [#2962](https://github.com/vtex/faststore/issues/2962)

# [3.65.0](https://github.com/vtex/faststore/compare/v3.64.1...v3.65.0) (2025-07-16)

### Features

- my account release 3 ([#2883](https://github.com/vtex/faststore/issues/2883)) ([be2c32a](https://github.com/vtex/faststore/commit/be2c32ae5cb0d892e34a96c2d73b06d31f8af137))

## 3.56.1 (2025-06-19)

### Bug Fixes

- redirect order details ([#2910](https://github.com/vtex/faststore/issues/2910)) ([a9b1f59](https://github.com/vtex/faststore/commit/a9b1f59952aff8084f47f6d85fc6d4c3356f5017))

## 3.50.3 (2025-06-02)

**Note:** Version bump only for package @faststore/components

## 3.49.1 (2025-05-27)

**Note:** Version bump only for package @faststore/components

# 3.45.0 (2025-05-20)

### Features

- my account release 2 ([#2786](https://github.com/vtex/faststore/issues/2786)) ([2a6339c](https://github.com/vtex/faststore/commit/2a6339ce060ff2707a6734f5c4fdae8b4f4c4480))

# [3.44.0](https://github.com/vtex/faststore/compare/v3.43.0...v3.44.0) (2025-05-13)

### Features

- Delivery Promise - navigation based on shopper location ([#2716](https://github.com/vtex/faststore/issues/2716)) ([d683080](https://github.com/vtex/faststore/commit/d683080b9806bf7587be5ef84d403e30d3969e51)), closes [#2708](https://github.com/vtex/faststore/issues/2708) [#2728](https://github.com/vtex/faststore/issues/2728) [#2739](https://github.com/vtex/faststore/issues/2739) [#2745](https://github.com/vtex/faststore/issues/2745) [#2749](https://github.com/vtex/faststore/issues/2749) [#2750](https://github.com/vtex/faststore/issues/2750) [#2768](https://github.com/vtex/faststore/issues/2768) [#2772](https://github.com/vtex/faststore/issues/2772) [#2775](https://github.com/vtex/faststore/issues/2775) [#2809](https://github.com/vtex/faststore/issues/2809) [#2817](https://github.com/vtex/faststore/issues/2817) [#2824](https://github.com/vtex/faststore/issues/2824) [#2835](https://github.com/vtex/faststore/issues/2835)

# [3.42.0](https://github.com/vtex/faststore/compare/v3.41.9...v3.42.0) (2025-05-08)

### Features

- Quick Order feature ([#2831](https://github.com/vtex/faststore/issues/2831)) ([875c6f4](https://github.com/vtex/faststore/commit/875c6f4ad4eb780cfa6f8a7aad445db5b3da2ee6))

## [3.41.3](https://github.com/vtex/faststore/compare/v3.41.2...v3.41.3) (2025-04-16)

### Bug Fixes

- Allow control to `Checkbox`'s `checked` attribute ([#2614](https://github.com/vtex/faststore/issues/2614)) ([f0b8f2b](https://github.com/vtex/faststore/commit/f0b8f2bdcda879854c84e99bc3f59844b16fb564))

## 3.38.3 (2025-04-11)

### Bug Fixes

- properly end response for unsupported HTTP methods in GraphQL API ([#2781](https://github.com/vtex/faststore/issues/2781)) ([58f6caf](https://github.com/vtex/faststore/commit/58f6cafa7946ddd3970994dece423f7fff8e55c8))

# 3.28.0 (2025-03-20)

### Bug Fixes

- add pnpm-lock.yaml to ignored files in biome.json ([#2737](https://github.com/vtex/faststore/issues/2737)) ([e308698](https://github.com/vtex/faststore/commit/e308698a406e27f0112ff1dc2e83564c42c83d85))

# 3.26.0 (2025-03-19)

**Note:** Version bump only for package @faststore/components

## [3.25.11](https://github.com/vtex/faststore/compare/v3.25.10...v3.25.11) (2025-03-17)

**Note:** Version bump only for package @faststore/components

## 3.22.2 (2025-02-20)

### Bug Fixes

- Removes CI invalid input ([#2689](https://github.com/vtex/faststore/issues/2689)) ([30ea4b5](https://github.com/vtex/faststore/commit/30ea4b5d38fee5f9aacda60c0bd3b3296875864c))

# [3.22.0](https://github.com/vtex/faststore/compare/v3.21.0...v3.22.0) (2025-02-18)

### Features

- add textareafield component ([#2641](https://github.com/vtex/faststore/issues/2641)) ([5e8dbf3](https://github.com/vtex/faststore/commit/5e8dbf392ee32feede0cdc6174c526a10ce19a22)), closes [PR#2640](https://github.com/PR/issues/2640)

# [3.20.0](https://github.com/vtex/faststore/compare/v3.19.0...v3.20.0) (2025-02-18)

### Features

- add tooltip component ([#2644](https://github.com/vtex/faststore/issues/2644)) ([ed1826d](https://github.com/vtex/faststore/commit/ed1826d86751b3304f8297432facbe795ae6e91f))

# [3.18.0](https://github.com/vtex/faststore/compare/v3.17.0...v3.18.0) (2025-02-17)

### Features

- create modal footer compound component ([#2672](https://github.com/vtex/faststore/issues/2672)) ([1a55c95](https://github.com/vtex/faststore/commit/1a55c95f6a2a6cf356647999befab9ba3897c8e7))

# [3.17.0](https://github.com/vtex/faststore/compare/v3.16.0...v3.17.0) (2025-02-17)

### Features

- create textarea component ([#2640](https://github.com/vtex/faststore/issues/2640)) ([15271ca](https://github.com/vtex/faststore/commit/15271cadb0d526ac5a1322a33b57d78635a9976d))

# [3.16.0](https://github.com/vtex/faststore/compare/v3.15.3...v3.16.0) (2025-02-13)

### Features

- add rating field ([#2636](https://github.com/vtex/faststore/issues/2636)) ([f6ab024](https://github.com/vtex/faststore/commit/f6ab024ca606a5f3c59732df02c933063187124a)), closes [PR#2635](https://github.com/PR/issues/2635)

## 3.15.3 (2025-02-13)

### Bug Fixes

- attempts to run publish directly in ci ([#2683](https://github.com/vtex/faststore/issues/2683)) ([44bb50d](https://github.com/vtex/faststore/commit/44bb50d0f03285cb3e48284004675a81385ade9b))

# 3.15.0 (2025-02-04)

### Features

- Offer SDK ([#2575](https://github.com/vtex/faststore/issues/2575)) ([f4e11ac](https://github.com/vtex/faststore/commit/f4e11ac68ae4afd79a1a89c122155e18bc452ad5))

## 3.14.2 (2025-02-03)

**Note:** Version bump only for package @faststore/components

## 3.13.1 (2025-01-31)

**Note:** Version bump only for package @faststore/components

## [3.11.4](https://github.com/vtex/faststore/compare/v3.11.3...v3.11.4) (2025-01-29)

**Note:** Version bump only for package @faststore/components

## [3.11.3](https://github.com/vtex/faststore/compare/v3.11.2...v3.11.3) (2025-01-29)

**Note:** Version bump only for package @faststore/components

## [3.11.2](https://github.com/vtex/faststore/compare/v3.11.1...v3.11.2) (2025-01-29)

**Note:** Version bump only for package @faststore/components

## [3.9.2](https://github.com/vtex/faststore/compare/v3.9.1...v3.9.2) (2025-01-27)

**Note:** Version bump only for package @faststore/components

# 3.9.0 (2025-01-22)

**Note:** Version bump only for package @faststore/components

# [3.7.0](https://github.com/vtex/faststore/compare/v3.6.0...v3.7.0) (2025-01-15)

### Features

- adds SKUMatrix component ([#2588](https://github.com/vtex/faststore/issues/2588)) ([0d7db56](https://github.com/vtex/faststore/commit/0d7db567be1e7b9b9375580b0a8cf665ee69d1c0))

# 3.5.0 (2025-01-09)

### Bug Fixes

- revert the commit ccfbac80a8694b8e674c4657d51e3478ff2605bd ([#2609](https://github.com/vtex/faststore/issues/2609)) ([49679ae](https://github.com/vtex/faststore/commit/49679ae3a735f7fa29d716b6e9f6d4941d73a647))

### Features

- Dynamically import `BreadcrumbBase` internal components ([#2611](https://github.com/vtex/faststore/issues/2611)) ([0992d10](https://github.com/vtex/faststore/commit/0992d10f0a12b54cd79403720abc0198a4d8f3e2))

## 3.4.4 (2024-12-20)

**Note:** Version bump only for package @faststore/components

## 3.4.3 (2024-12-20)

**Note:** Version bump only for package @faststore/components

## 3.4.2 (2024-12-20)

**Note:** Version bump only for package @faststore/components

## 3.4.1 (2024-12-20)

**Note:** Version bump only for package @faststore/components

## 3.1.3 (2024-12-13)

**Note:** Version bump only for package @faststore/components

# [3.1.0](https://github.com/vtex/faststore/compare/v3.0.160...v3.1.0) (2024-12-09)

### Features

- add ads label product card ([#2582](https://github.com/vtex/faststore/issues/2582)) ([ae6f655](https://github.com/vtex/faststore/commit/ae6f6558dd76fb2061fa5992e5cea5bcd2142ac5))

## 3.0.160 (2024-12-09)

**Note:** Version bump only for package @faststore/components
