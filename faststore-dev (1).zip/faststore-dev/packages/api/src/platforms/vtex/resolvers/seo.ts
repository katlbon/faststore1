import type { GraphqlResolver } from '..'
import type { PromiseType } from '../../../typings/globals'
import type { StoreProduct } from './product'

export type Root = PromiseType<ReturnType<typeof StoreProduct.seo>> & {
  titleTemplate?: string
}

export const StoreSeo: Record<string, GraphqlResolver<Root>> = {
  title: ({ title }) => title ?? '',
  description: ({ description }) => description ?? '',
  canonical: ({ canonical }) => canonical ?? '',
  titleTemplate: () => '',
}
