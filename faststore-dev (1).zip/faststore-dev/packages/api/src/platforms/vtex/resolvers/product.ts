import type { GraphqlContext, GraphqlResolver } from '..'
import type { PromiseType } from '../../../typings/globals'
import type { StoreImage, StoreProductImageArgs } from '../../..'
import type { LocalizedProductEntry } from '../clients/catalog'
import type {
  Attachment,
  OrderFormBundleItem,
} from '../clients/commerce/types/OrderForm'
import { canonicalFromProduct } from '../utils/canonical'
import type { EnhancedCommercialOffer } from '../utils/enhanceCommercialOffer'
import { enhanceCommercialOffer } from '../utils/enhanceCommercialOffer'
import {
  getConfiguredLocales,
  getDefaultLocale,
  isLocalizationEnabled,
} from '../utils/localization'
import { bestOfferFirst } from '../utils/productStock'
import {
  attachmentToPropertyValue,
  attributeToPropertyValue,
  serviceToPropertyValue,
  VALUE_REFERENCES,
} from '../utils/propertyValue'
import { slugify } from '../utils/slugify'
import type { Query } from './query'

type QueryProduct = PromiseType<ReturnType<typeof Query.product>>

export type Root = QueryProduct & {
  attachmentsValues?: Attachment[]
  /** Services (Checkout `bundleItems`) applied to the cart line; cart context only. */
  servicesValues?: OrderFormBundleItem[]
  unitMultiplier: number
}

const DEFAULT_IMAGE = {
  imageText: 'image',
  imageUrl:
    'https://storecomponents.vtexassets.com/assets/faststore/images/image___117a6d3e229a96ad0e0d0876352566e2.svg',
  imageLabel: 'label',
}

const getSlug = (link: string, id: string) => `${link}-${id}`
const getPath = (link: string, id: string) => `/${getSlug(link, id)}/p`
const nonEmptyArray = <T>(array: T[] | null | undefined) =>
  Array.isArray(array) && array.length > 0 ? array : null

function removeTrailingSlashes(path: string) {
  return path.replace(/^\/+|\/+$/g, '')
}

/**
 * Returns a cached-or-fetched localized product entry from the Catalog Dataplane.
 * The promise is stored in `ctx.storage.productTranslationsCache` so it is shared
 * across the `breadcrumbList`, `otherLocales`, and slug-validation resolvers within
 * the same request.
 *
 * The in-flight promise (not just the resolved value) is cached so concurrent
 * sibling resolvers dedupe to a single Catalog Dataplane request instead of each
 * missing the cache and issuing a duplicate fetch.
 */
export async function getLocalizedProductEntry(
  ctx: GraphqlContext,
  productId: string,
  locale: string
): Promise<LocalizedProductEntry | null> {
  const cacheKey = `${productId}:${locale}`
  ctx.storage.productTranslationsCache ??= new Map()
  const cache = ctx.storage.productTranslationsCache

  const cached = cache.get(cacheKey)
  if (cached) return cached

  const entry = (async (): Promise<LocalizedProductEntry | null> => {
    try {
      const result = await ctx.clients.catalog.getLocalizedProduct(
        productId,
        locale
      )

      return {
        linkId: result.linkId,
        categories: result.categories ?? [],
        availableLinkIds: result.availableLinkIds ?? {},
      }
    } catch (err) {
      // Without this the fallback is silent: the breadcrumb renders the IS
      // category names, always in the default language, and the page can be
      // frozen in that state by `revalidate: false`.
      console.warn(
        `[getLocalizedProductEntry] failed to load product ${productId} for locale ${locale}:`,
        err
      )

      return null
    }
  })()

  cache.set(cacheKey, entry)

  return entry
}

/**
 * Finds the index of the main category tree that matches the given category ID.
 * This avoids including similar categories in the breadcrumb list.
 * If Intelligent Search starts providing the list without similar categories, we'll have direct access to the main tree
 * and we won't need this logic. Hopefully in the future we can remove this.
 *
 * @param categoriesIds - An array of category IDs representing different category trees.
 * @param categoryId - The category ID to find within the category trees.
 * @returns The index of the main category tree that contains the given category ID.
 *          If the category ID is not found, returns 0 - it should always be found, but the fallback was added for safety.
 */
const findMainTreeIndex = (categoriesIds: string[], categoryId: string) => {
  const mainTreeIndex = categoriesIds.findIndex((idsTree) => {
    const lastId = removeTrailingSlashes(idsTree).split('/').at(-1)
    return lastId === categoryId
  })
  return mainTreeIndex < 0 ? 0 : mainTreeIndex
}

export const StoreProduct: Record<string, GraphqlResolver<Root>> & {
  offers: GraphqlResolver<
    Root,
    any,
    Array<EnhancedCommercialOffer<Root['sellers'][number], Root>>
  >

  isVariantOf: GraphqlResolver<Root, any, Root>

  image: GraphqlResolver<Root, any, StoreImage[]>
} = {
  productID: ({ itemId }) => itemId,
  name: ({ isVariantOf, name }) => name ?? isVariantOf.productName,
  slug: ({ isVariantOf: { linkText }, itemId }) => getSlug(linkText, itemId),
  description: ({ isVariantOf: { description } }) => description,
  seo: ({ isVariantOf }) => ({
    title: isVariantOf.productTitle || isVariantOf.productName,
    description: isVariantOf.metaTagDescription || isVariantOf.description,
    canonical: canonicalFromProduct(isVariantOf),
  }),
  brand: ({ isVariantOf: { brand } }) => ({ name: brand }),
  unitMultiplier: ({ unitMultiplier }) => unitMultiplier,
  breadcrumbList: async (root, _args, ctx) => {
    const {
      isVariantOf: {
        categories,
        productName,
        linkText,
        categoryId,
        categoriesIds,
        productId,
      },
      itemId,
    } = root

    const mainTreeIndex = findMainTreeIndex(categoriesIds, categoryId)
    const mainTree = categories[mainTreeIndex]
    const splittedCategories = removeTrailingSlashes(mainTree).split('/')

    const locale = ctx.storage.locale

    if (isLocalizationEnabled(ctx) && locale) {
      const entry = await getLocalizedProductEntry(ctx, productId, locale)

      if (entry) {
        // Extract the category IDs that belong to the main tree (same tree chosen from IS above).
        // A product can be registered in multiple trees; Catalog Dataplane returns all of them
        // in categories[], so we filter to only the ones matching this tree's IDs.
        const mainTreeIds = new Set(
          removeTrailingSlashes(categoriesIds[mainTreeIndex])
            .split('/')
            .filter(Boolean)
        )

        const localizedCategories = entry.categories
          .filter((category) => mainTreeIds.has(category.id.toString()))
          .sort(
            (a, b) =>
              a.fullPath.split('/').length - b.fullPath.split('/').length
          )

        // Length guard: if Catalog Dataplane returns fewer categories than IS expects
        // (e.g. data inconsistency or empty categories), fall through to the IS fallback.
        const hasAllBreadcrumbLevels =
          localizedCategories.length === splittedCategories.length
        if (hasAllBreadcrumbLevels) {
          return {
            itemListElement: [
              // Category items: both name and slug come from Catalog Dataplane, ensuring
              // they are always consistent with each other for the requested locale.
              ...localizedCategories.map((category, index) => ({
                name: category.name,
                item: `/${category.fullPathUriName}/`,
                position: index + 1,
              })),
              {
                name: productName,
                item: getPath(entry.linkId, itemId),
                position: splittedCategories.length + 1,
              },
            ],
            numberOfItems: splittedCategories.length,
          }
        }
      }
    }

    // Fallback: localization disabled, Catalog Dataplane unavailable, or category count mismatch.
    // Builds paths by applying slugify() to the IS category names, which mirrors the behaviour
    // of the VTEX Rewriter for default-locale slugs.
    return {
      itemListElement: [
        ...splittedCategories.map((name, index) => {
          const item = `/${splittedCategories
            .slice(0, index + 1)
            .map(slugify)
            .join('/')}/`
          return {
            name,
            item,
            position: index + 1,
          }
        }),
        {
          name: productName,
          item: getPath(linkText, itemId),
          position: splittedCategories.length + 1,
        },
      ],
      numberOfItems: splittedCategories.length,
    }
  },
  image: ({ images }, args) => {
    const resolvedImages = (nonEmptyArray(images) ?? [DEFAULT_IMAGE]).map(
      ({ imageUrl, imageText, imageLabel }) => ({
        alternateName: imageText ?? '',
        url: imageUrl.replace('vteximg.com.br', 'vtexassets.com'),
        keywords: imageLabel,
      })
    )

    if (typeof args !== 'object') {
      return resolvedImages
    }

    let { context, limit } = args as StoreProductImageArgs

    const shouldFilter = context !== 'generic'

    // Normalize count to undefined as we want any negative value to always return the full list of images
    limit = limit || -1
    limit = limit <= -1 ? undefined : limit

    let filteredImages = shouldFilter
      ? resolvedImages.filter(
          ({ keywords: imageKeywords }) => imageKeywords === context
        )
      : resolvedImages

    filteredImages =
      filteredImages.length === 0 ? resolvedImages : filteredImages

    return filteredImages.slice(0, limit)
  },
  sku: ({ itemId }) => itemId,
  gtin: ({ ean, referenceId }) => (ean ? ean : (referenceId[0]?.Value ?? '')),
  mpn: ({ isVariantOf: { manufacturerCode } }) => manufacturerCode ?? '',
  review: () => [],
  aggregateRating: () => ({}),
  offers: (root) =>
    root.sellers
      .map((seller) =>
        enhanceCommercialOffer({
          offer: seller.commertialOffer,
          seller,
          product: root,
        })
      )
      .sort(bestOfferFirst),
  isVariantOf: (root) => root,
  additionalProperty: ({
    // Search uses the name variations for specifications
    variations: specifications = [],
    attachmentsValues = [],
    attributes = [],
    servicesValues = [],
  }) => {
    const propertyValueSpecifications = specifications.flatMap(
      ({ name, values }) =>
        values.map((value) => ({
          name,
          value,
          valueReference: VALUE_REFERENCES.specification,
        }))
    )

    const propertyValueAttachments = attachmentsValues.map(
      attachmentToPropertyValue
    )

    const propertyValueAttributes = attributes.map(attributeToPropertyValue)

    const propertyValueServices = servicesValues.map(serviceToPropertyValue)

    return [
      ...propertyValueSpecifications,
      ...propertyValueAttachments,
      ...propertyValueAttributes,
      ...propertyValueServices,
    ]
  },
  hasSpecifications: ({ isVariantOf }) =>
    Boolean(isVariantOf.skuSpecifications?.length),
  skuSpecifications: ({ isVariantOf: { skuSpecifications } }) =>
    skuSpecifications ?? [],
  specificationGroups: ({ isVariantOf: { specificationGroups } }) =>
    specificationGroups,
  // Passed through as Intelligent Search delivers it (epoch milliseconds for
  // most accounts). Stores read this raw value; the PDP JSON-LD normalizes it
  // on its own in `@faststore/core`.
  releaseDate: ({ isVariantOf: { releaseDate } }) => releaseDate ?? '',
  advertisement: ({ isVariantOf: { advertisement } }) => advertisement,
  deliveryPromiseBadges: ({ isVariantOf: { deliveryPromisesBadges } }) =>
    deliveryPromisesBadges,
  otherLocales: async (root, _args, ctx) => {
    if (!isLocalizationEnabled(ctx)) return null

    const configuredLocales = getConfiguredLocales(ctx)

    if (configuredLocales.length === 0) return null

    const productId = root.isVariantOf.productId
    const itemId = root.itemId
    const locale = ctx.storage.locale

    // availableLinkIds returns localized slug for every locale,
    // we fetch for the current locale (reusing the request-scoped cache shared with the slug and
    // breadcrumb resolvers) and read the full map from the response.
    const entry = await getLocalizedProductEntry(ctx, productId, locale)

    if (!entry?.availableLinkIds) return null

    const { availableLinkIds } = entry

    return configuredLocales
      .map((configuredLocale) => {
        // availableLinkIds is identical whichever locale the Dataplane is queried
        // with, so deriving every slug from it keeps the hreflang cluster
        // reciprocal. The Intelligent Search linkText cannot stand in for a
        // missing entry: it is localized to the locale being browsed, which would
        // both point other locales at a 404 and make the advertised set depend on
        // which locale served the request.
        const linkId = availableLinkIds[configuredLocale]

        // Locales with no registered localized slug are omitted rather than
        // guessed, so an alternate is only ever advertised for a slug the catalog
        // actually resolves. A product with no translations advertises no
        // alternates at all, from any locale. Navigating to an omitted locale is
        // served by `defaultLocaleSlug`, which is free to guess precisely because
        // it never reaches an hreflang annotation.
        return linkId
          ? { locale: configuredLocale, slug: getSlug(linkId, itemId) }
          : null
      })
      .filter((e): e is { locale: string; slug: string } => e !== null)
  },
  defaultLocaleSlug: async (root, _args, ctx) => {
    if (!isLocalizationEnabled(ctx)) return null

    const defaultLocale = getDefaultLocale(ctx)

    if (!defaultLocale) return null

    const { productId, linkText } = root.isVariantOf
    const itemId = root.itemId

    // Reuses the request-scoped entry `otherLocales` already loads, so serving
    // both fields costs a single Dataplane call.
    const entry = await getLocalizedProductEntry(
      ctx,
      productId,
      ctx.storage.locale
    )

    // linkText is localized to the locale being browsed, which is what makes it
    // unusable for hreflang. It is acceptable here because an untranslated
    // product carries the same slug in every locale, so linkText *is* the
    // default-locale slug in the exact case where availableLinkIds is empty.
    // A product translated for the browsed locale but not for the default one
    // still yields a wrong guess; that URL 404s, which is the pre-existing
    // behavior and still better than dropping the shopper on the locale root.
    const linkId = entry?.availableLinkIds?.[defaultLocale] ?? linkText

    return getSlug(linkId, itemId)
  },
}
