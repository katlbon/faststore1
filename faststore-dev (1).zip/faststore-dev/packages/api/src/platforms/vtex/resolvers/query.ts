import type {
  ProcessOrderAuthorizationRule,
  QueryAllCollectionsArgs,
  QueryAllProductsArgs,
  QueryAvailableContractsArgs,
  QueryCollectionArgs,
  QueryListUserOrdersArgs,
  QueryPickupPointsArgs,
  QueryProductArgs,
  QueryProductCountArgs,
  QueryProductsArgs,
  QueryProfileArgs,
  QueryRedirectArgs,
  QuerySearchArgs,
  QuerySellersArgs,
  QueryShippingArgs,
  QueryUserOrderArgs,
  SavedCard,
  StoreContract,
  UserOrderFromList,
} from '../../../__generated__/schema'
import { recommendations } from './recommendations'
import {
  BadRequestError,
  ForbiddenError,
  NotFoundError,
  isForbiddenError,
  isNotFoundError,
} from '../../errors'
import type { CategoryTree } from '../clients/commerce/types/CategoryTree'
import type { ProfileAddress } from '../clients/commerce/types/Profile'
import type { SearchArgs } from '../clients/search'
import type { ProductSearchResult } from '../clients/search/types/ProductSearchResult'
import type { GraphqlContext } from '../index'
import type {
  ByLinkIdBrandRoot,
  ByLinkIdCategoryRoot,
} from '../loaders/collection'
import { extractRuleForAuthorization } from '../utils/commercialAuth'
import {
  mapSessionContractsToStoreContracts,
  parseSessionAvailableContracts,
  resolveActiveContractDisplayName,
  resolveActiveContractIdFromSession,
  resolveDefaultContractId,
} from '../utils/contract'
import { mutateChannelContext, mutateLocaleContext } from '../utils/contex'
import { getAuthCookie, parseJwt } from '../utils/cookies'
import { enhanceSku, type EnhancedSku } from '../utils/enhanceSku'
import {
  findChannel,
  findCrossSelling,
  findLocale,
  findSkuId,
  findSlug,
  transformSelectedFacet,
} from '../utils/facets'
import { getCatalogLocale, isLocalizationEnabled } from '../utils/localization'
import { isValidSkuId, pickBestSku } from '../utils/sku'
import { slugify } from '../utils/slugify'
import { resolveSort } from '../utils/sort'
import { FACET_CROSS_SELLING_MAP } from './../utils/facets'
import { StoreCollection } from './collection'
import { getOrderEntryOperation } from './getOrderEntryOperation'
import { getOrderFormItems } from './getOrderFormItems'
import { getLocalizedProductEntry } from './product'

/**
 * Validates that a slug mismatch between IS linkText and the requested slug is
 * actually a localized slug match. Fetches the localized product entry from
 * Catalog Dataplane (with request-scoped caching) and checks whether the slug
 * prefix matches the localized linkId for the current locale.
 *
 * Returns true if the slug is a valid localized match, false otherwise
 * (including when the Dataplane API is unavailable).
 */
async function isLocalizedSlugMatch(
  ctx: GraphqlContext,
  slug: string,
  productGroupID: string,
  locale: string
): Promise<boolean> {
  const slugPrefix = slug.slice(0, slug.lastIndexOf('-'))
  const entry = await getLocalizedProductEntry(ctx, productGroupID, locale)

  return entry?.linkId === slugPrefix
}

const INVALID_SKU_ID_ERROR = 'Invalid SkuId'
const SLUG_MISMATCH_ERROR =
  'Slug was set but the fetched sku does not satisfy the slug condition.'

/**
 * License Manager resource key gating personal card management. Spelled as the
 * platform registers it — the PRD's prose lowercases the leading `u`, but the
 * key the API answers for is `UseAdHocCard`.
 */
const AD_HOC_CARD_RESOURCE_KEY = 'UseAdHocCard'

const shouldFallbackToProductRoute = (error: unknown) =>
  isNotFoundError(error) ||
  (error instanceof Error &&
    (error.message === INVALID_SKU_ID_ERROR ||
      error.message.startsWith(SLUG_MISMATCH_ERROR)))

/**
 * Here be dragons 🦄🦄🦄
 *
 * In some cases, the slug has a valid skuId for a different product. This
 * guards that the fetched sku is the one we actually asked for, throwing
 * SLUG_MISMATCH_ERROR (caught by the caller) when it isn't.
 *
 * When localization is enabled, the slug prefix may be a localized LinkId that
 * differs from the IS linkText. linkText follows the locale being browsed
 * rather than the default one, so a mismatch is not by itself evidence of a
 * wrong sku. We validate against the Catalog Dataplane API before rejecting
 * the slug.
 */
async function assertSkuMatchesSlug(
  ctx: GraphqlContext,
  sku: EnhancedSku,
  slug: string | null | undefined,
  locale: string | null | undefined
): Promise<void> {
  const { linkText, productId } = sku.isVariantOf

  if (!slug || !linkText || slug.startsWith(linkText)) {
    return
  }

  const isValidLocalizedMatch =
    isLocalizationEnabled(ctx) &&
    locale &&
    isValidSkuId(slug.split('-').pop() ?? '') &&
    (await isLocalizedSlugMatch(ctx, slug, productId, locale))

  if (isValidLocalizedMatch) {
    return
  }

  throw new Error(`${SLUG_MISMATCH_ERROR} slug: ${slug}, linkText: ${linkText}`)
}

/**
 * Fallback used when the sku/slug lookup above fails (invalid skuId, not
 * found, or slug mismatch): resolves the slug through the legacy pagetype
 * route and fetches the product from Intelligent Search by id instead.
 */
async function fetchProductBySlugFallback(
  ctx: GraphqlContext,
  slug: string | null | undefined
): Promise<EnhancedSku> {
  if (slug == null) {
    throw new BadRequestError('Missing slug or id')
  }

  const {
    clients: { commerce, search },
  } = ctx

  const route = await commerce.catalog.portal.pagetype(`${slug}/p`)

  if (route.pageType !== 'Product' || !route.id) {
    throw new NotFoundError(`No product found for slug ${slug}`)
  }

  const product = await search
    .fetchProduct({
      field: 'id',
      value: String(route.id),
    })
    .catch(() => null)

  if (!product) {
    throw new NotFoundError(`No product found for id ${route.id}`)
  }

  return enhanceSku(pickBestSku(product.items), product)
}

export const Query = {
  product: async (
    _: unknown,
    { locator }: QueryProductArgs,
    ctx: GraphqlContext
  ) => {
    // Insert channel in context for later usage
    const channel = findChannel(locator)
    const locale = findLocale(locator)
    const id = findSkuId(locator)
    const slug = findSlug(locator)

    if (channel) {
      mutateChannelContext(ctx, channel)
    }

    if (locale) {
      mutateLocaleContext(ctx, locale)
    }

    const {
      loaders: { skuLoader },
    } = ctx

    try {
      const skuId = id ?? slug?.split('-').pop() ?? ''

      if (!isValidSkuId(skuId)) {
        throw new Error(INVALID_SKU_ID_ERROR)
      }

      const sku = await skuLoader.load(skuId)

      await assertSkuMatchesSlug(ctx, sku, slug, locale)

      return sku
    } catch (err) {
      if (!shouldFallbackToProductRoute(err)) {
        throw err
      }

      return fetchProductBySlugFallback(ctx, slug)
    }
  },
  collection: (
    _: unknown,
    { slug }: QueryCollectionArgs,
    ctx: GraphqlContext
  ) => {
    const {
      loaders: { collectionLoader },
    } = ctx

    // The request locale is set on ctx.storage.locale by the core `execute`
    // wrapper (from Next.js i18n) rather than a GraphQL argument, so overridable
    // fragments (API extensions) that also select `collection` keep merging
    // without argument conflicts.
    return collectionLoader.load({
      slug,
      locale: getCatalogLocale(ctx),
    })
  },
  search: async (
    _: unknown,
    {
      first,
      after: maybeAfter,
      sort,
      term,
      selectedFacets,
      sponsoredCount,
    }: QuerySearchArgs,
    ctx: GraphqlContext
  ) => {
    // Insert channel in context for later usage
    const channel = findChannel(selectedFacets)
    const locale = findLocale(selectedFacets)
    const crossSelling = findCrossSelling(selectedFacets)

    if (channel) {
      mutateChannelContext(ctx, channel)
    }

    if (locale) {
      mutateLocaleContext(ctx, locale)
    }

    const after = maybeAfter ? Number(maybeAfter) : 0
    const searchArgs: Omit<SearchArgs, 'type'> = {
      page: Math.ceil(after / first) || 0,
      count: first,
      query: term ?? undefined,
      sort: resolveSort(sort ?? 'score_desc', ctx.storage.customSortMap),
      selectedFacets: selectedFacets?.flatMap(transformSelectedFacet) ?? [],
      sponsoredCount: sponsoredCount ?? undefined,
    }

    /**
     * In case we are using crossSelling, we fetch product IDs from the
     * cross selling API and then hydrate them using the PDP endpoint
     * via productsByIdentifier.
     */
    if (crossSelling) {
      const crossSellingProducts =
        await ctx.clients.commerce.catalog.products.crossselling({
          type: FACET_CROSS_SELLING_MAP[crossSelling.key],
          productId: crossSelling.value,
        })

      const productIds = crossSellingProducts
        .map((x) => x.productId)
        .slice(0, first)

      const productSearchPromise: Promise<ProductSearchResult> =
        ctx.clients.search
          .productsByIdentifier({ field: 'id', values: productIds })
          .then((products) => ({
            products,
            recordsFiltered: products.length,
            pagination: {
              count: products.length,
              current: { index: 0, proxyURL: '' },
              before: [],
              after: [],
              perPage: first,
              next: { index: 0, proxyURL: '' },
              previous: { index: 0, proxyURL: '' },
              first: { index: 0, proxyURL: '' },
              last: { index: 0, proxyURL: '' },
            },
            sampling: false,
            options: { sorts: [], counts: [] },
            translated: false,
            locale: '',
            query: '',
            operator: 'and',
            fuzzy: '0',
            searchId: '',
          }))

      return { searchArgs, productSearchPromise }
    }

    const productSearchPromise = ctx.clients.search.products(searchArgs)

    return { searchArgs, productSearchPromise }
  },
  allProducts: async (
    _: unknown,
    { first, after: maybeAfter }: QueryAllProductsArgs,
    ctx: GraphqlContext
  ) => {
    const {
      clients: { search },
    } = ctx

    const after = maybeAfter ? Number(maybeAfter) : 0
    const products = await search.products({
      page: Math.ceil(after / first),
      count: first,
    })

    const skus = products.products
      .flatMap((product) =>
        product.items.map((sku) => enhanceSku(sku, product))
      )
      .filter((sku) => sku.sellers.length > 0)

    return {
      pageInfo: {
        hasNextPage: products.pagination.after.length > 0,
        hasPreviousPage: products.pagination.before.length > 0,
        startCursor: '0',
        endCursor: products.recordsFiltered.toString(),
        totalCount: products.recordsFiltered,
      },
      // after + index is bigger than after+first itself because of the array flat() above
      edges: skus.map((sku, index) => ({
        node: sku,
        cursor: (after + index).toString(),
      })),
    }
  },
  products: async (
    _: unknown,
    { productIds }: QueryProductsArgs,
    ctx: GraphqlContext
  ) => {
    const {
      clients: { search },
    } = ctx

    if (!productIds.length) {
      return []
    }

    const products = await search.productsByIdentifier({
      field: 'id',
      values: productIds,
    })

    return products
      .flatMap((product) =>
        product.items.map((sku) => enhanceSku(sku, product))
      )
      .filter(
        (sku) => productIds.includes(sku.itemId) && sku.sellers.length > 0
      )
  },
  allCollections: async (
    _: unknown,
    { first, after: maybeAfter }: QueryAllCollectionsArgs,
    ctx: GraphqlContext
  ) => {
    const {
      clients: { commerce },
    } = ctx

    const after = maybeAfter ? Number(maybeAfter) : 0

    const [brands, tree] = await Promise.all([
      commerce.catalog.brand.list(),
      commerce.catalog.category.tree(),
    ])

    // Flatten the category tree. parentId is tracked per node so
    // the type resolver can correctly classify Departments (fatherCategoryId: null)
    // vs Categories (fatherCategoryId: number).
    const categoryRoots: ByLinkIdCategoryRoot[] = []
    const dfs = (node: CategoryTree, parentId: number | null) => {
      categoryRoots.push({
        id: node.id,
        name: node.name,
        fatherCategoryId: parentId,
        linkId: slugify(node.name),
        title: node.Title,
        description: null,
        metaTagDescription: node.MetaTagDescription,
        availableLinkIds: null,
        entityType: 'category' as const,
        slug: new URL(node.url).pathname.slice(1).toLowerCase(),
      })

      for (const child of node.children) {
        dfs(child, node.id)
      }
    }

    for (const node of tree) {
      dfs(node, null)
    }

    const brandRoots: ByLinkIdBrandRoot[] = brands
      .filter((brand) => brand.isActive)
      .map((brand) => ({
        id: brand.id,
        name: brand.name,
        linkId: slugify(brand.name),
        title: brand.title,
        description: null,
        metaTagDescription: brand.metaTagDescription,
        availableLinkIds: null,
        entityType: 'brand' as const,
      }))

    const collections = [...brandRoots, ...categoryRoots]

    const validCollections = collections
      // Nullable slugs may cause one route to override the other
      .filter((node) => Boolean(StoreCollection.slug(node, null, ctx, null)))

    return {
      pageInfo: {
        hasNextPage: validCollections.length - after > first,
        hasPreviousPage: after > 0,
        startCursor: '0',
        endCursor: (
          Math.min(first, validCollections.length - after) - 1
        ).toString(),
        totalCount: validCollections.length,
      },
      edges: validCollections
        .slice(after, after + first)
        .map((node, index) => ({
          node,
          cursor: (after + index).toString(),
        })),
    }
  },
  shipping: async (
    _: unknown,
    { country, items, postalCode }: QueryShippingArgs,
    ctx: GraphqlContext
  ) => {
    const {
      loaders: { simulationLoader },
      clients: { commerce },
    } = ctx

    const [simulation, address] = await Promise.all([
      simulationLoader.load({ country, items, postalCode }),
      commerce.checkout.address({ postalCode, country }),
    ])

    return {
      ...simulation,
      address,
    }
  },
  redirect: async (
    _: unknown,
    { term, selectedFacets }: QueryRedirectArgs,
    ctx: GraphqlContext
  ) => {
    // Currently the search redirection can be done through a search term or filter (facet) so we limit the redirect query to always have one of these values otherwise we do not execute it.
    // https://help.vtex.com/en/tracks/vtex-intelligent-search--19wrbB7nEQcmwzDPl1l4Cb/4Gd2wLQFbCwTsh8RUDwSoL?&utm_source=autocomplete
    if (!term && (!selectedFacets || !selectedFacets.length)) {
      return null
    }

    const { redirect } = await ctx.clients.search.products({
      page: 1,
      count: 1,
      query: term ?? undefined,
      selectedFacets: selectedFacets?.flatMap(transformSelectedFacet) ?? [],
      allowRedirect: true,
    })

    return {
      url: redirect,
    }
  },
  sellers: async (
    _: unknown,
    { postalCode, geoCoordinates, country, salesChannel }: QuerySellersArgs,
    ctx: GraphqlContext
  ) => {
    const {
      clients: { commerce },
    } = ctx

    const regionData = await commerce.checkout.region({
      postalCode,
      geoCoordinates,
      country,
      salesChannel,
    })
    const region = regionData?.[0]
    const { id, sellers } = region

    return {
      id,
      sellers,
    }
  },
  profile: async (
    _: unknown,
    { id }: QueryProfileArgs,
    ctx: GraphqlContext
  ) => {
    const {
      clients: { commerce },
    } = ctx

    const addresses = await commerce.profile.addresses(id)

    function mapAddressesToList(
      addressesObj: Record<string, string>
    ): ProfileAddress[] {
      if (!addressesObj || Object.keys(addressesObj).length === 0) {
        return []
      }

      return Object.values(addressesObj).map(
        (stringifiedObj) => JSON.parse(stringifiedObj) as ProfileAddress
      )
    }

    const parsedAddresses = mapAddressesToList(addresses)

    return { addresses: parsedAddresses }
  },
  productCount: async (
    _: unknown,
    { term }: QueryProductCountArgs,
    ctx: GraphqlContext
  ) => {
    const {
      clients: { search },
    } = ctx

    const result = await search.productCount({
      query: term ?? undefined,
    })

    return result
  },
  userOrder: async (
    _: unknown,
    { orderId }: QueryUserOrderArgs,
    ctx: GraphqlContext
  ) => {
    try {
      if (!orderId) {
        throw new BadRequestError('Missing orderId')
      }

      const {
        clients: { commerce },
      } = ctx

      const order = await commerce.oms.userOrder({ orderId })

      if (!order) {
        throw new NotFoundError(`No order found for id ${orderId}`)
      }

      let ruleForAuthorization: ProcessOrderAuthorizationRule | null = null

      try {
        /**
         * This endpoint could return a 404 error if has not an authorization
         * for the order, so we catch the error and return null
         * instead of throwing an error.
         */
        const commercialAuth =
          await commerce.oms.getCommercialAuthorizationsByOrderId({ orderId })

        ruleForAuthorization = extractRuleForAuthorization(commercialAuth)
      } catch (err: any) {}

      const shopperSearch =
        (await commerce.masterData.getShopperById({
          userId: order.purchaseAgentData?.purchaseAgents?.[0]?.userId ?? '',
        })) ?? []
      const shopper = shopperSearch[0] ?? {}

      return {
        orderId: order.orderId,
        creationDate: order.creationDate,
        totals: order.totals,
        items: order.items,
        shippingData: order.shippingData,
        paymentData: order.paymentData,
        customData: order.customData,
        status: order.status,
        statusDescription: order.statusDescription,
        allowCancellation: order.allowCancellation,
        storePreferencesData: order.storePreferencesData,
        clientProfileData: order.clientProfileData,
        canProcessOrderAuthorization:
          (order.status === 'waiting-for-confirmation' ||
            order.status === 'waiting-for-authorization') &&
          !!ruleForAuthorization,
        ruleForAuthorization,
        shopper: {
          firstName: shopper?.firstName || '',
          lastName: shopper?.lastName || '',
          email: shopper?.email || '',
          phone: shopper?.phone || '',
        },
        budgetData: order.budgetData ?? { budgets: [] },
      }
    } catch (error) {
      const errorMessage = (error as Error).message

      let result: {
        code?: string
        message?: string
        exception?: any
      } = {}

      /** The errorMessage can be in:
       * JSON format: {"error":{"code":"OMS007","message":"Order Not Found","exception":null}}
       * Plain text format: "No authorized"
       * Unknown format
       */
      try {
        const parsed = JSON.parse(errorMessage)
        result = parsed.error || parsed
      } catch {
        result = { message: errorMessage }
      }

      const message = result?.message || errorMessage

      if (isNotFoundError(error)) {
        throw new NotFoundError(`No order found for id ${orderId}. ${message}.`)
      }

      if (isForbiddenError(error)) {
        throw new ForbiddenError(
          `You are forbidden to interact with order with id ${orderId}. ${message}.`
        )
      }

      // Fallback for other Errors
      throw error
    }
  },
  listUserOrders: async (
    _: unknown,
    filters: QueryListUserOrdersArgs,
    ctx: GraphqlContext
  ) => {
    const {
      clients: { commerce },
    } = ctx

    const orders = await commerce.oms.listUserOrders(filters)

    return {
      list: orders.list?.map((order: UserOrderFromList) => ({
        orderId: order.orderId,
        creationDate: order.creationDate,
        clientName: order.clientName,
        items: order.items,
        totalValue: order.totalValue,
        status: order.status,
        statusDescription: order.statusDescription,
        ShippingEstimatedDate: order.ShippingEstimatedDate,
        customFields: order.customFields,
        currencyCode: order.currencyCode,
      })),
      paging: orders.paging,
    }
  },
  listCreditCards: async (_: unknown, __: unknown, ctx: GraphqlContext) => {
    const {
      clients: { commerce },
    } = ctx

    const cards = await commerce.savedCards.listCreditCards()

    return {
      list: cards?.map((card: SavedCard) => ({
        accountId: card.accountId,
        bin: card.bin,
        cardNumber: card.cardNumber,
        cardLabel: card.cardLabel,
        paymentSystem: card.paymentSystem,
        paymentSystemName: card.paymentSystemName,
        isDefault: card.isDefault,
        isActive: card.isActive,
        origin: card.origin,
      })),
    }
  },
  hasAdHocCardAccess: async (_: unknown, __: unknown, ctx: GraphqlContext) => {
    const {
      account,
      headers,
      clients: { commerce },
    } = ctx

    const jwt = parseJwt(getAuthCookie(headers?.cookie ?? '', account))
    const userId = jwt?.userId ?? ''

    // No resolvable user means no organizational policy to enforce — the
    // caller (page/menu) still applies its own `unitId` check.
    if (!userId) {
      return true
    }

    // The permission is a License Manager resource key resolved from the
    // user's roles, not a token claim. Fail open on any failure, matching how
    // the checkout BFF treats an unavailable/disabled permission service.
    const granted = await commerce.licenseManager
      .isResourceGranted({ userId, resourceKey: AD_HOC_CARD_RESOURCE_KEY })
      .catch(() => null)

    return typeof granted === 'boolean' ? granted : true
  },
  listUserQuotes: async (
    _: unknown,
    filters: {
      page?: number
      perPage?: number
      status?: string[]
      createdAtFrom?: string
      createdAtTo?: string
      expiresAtFrom?: string
      expiresAtTo?: string
      label?: string
    },
    ctx: GraphqlContext
  ) => {
    const {
      clients: { commerce },
    } = ctx

    const result = await commerce.quotes.listUserQuotes(filters)

    const uniqueCreatedByIds = [
      ...new Set(result.items.map((quote) => quote.createdBy).filter(Boolean)),
    ] as string[]

    const createdByNameById = new Map<string, string>()
    await Promise.all(
      uniqueCreatedByIds.map(async (userId) => {
        try {
          const [shopper] = await commerce.masterData.getShopperById({
            userId,
          })
          if (shopper) {
            const fullName = [shopper.firstName, shopper.lastName]
              .filter(Boolean)
              .join(' ')
            if (fullName) createdByNameById.set(userId, fullName)
          }
        } catch {
          // Fall back to the raw id below if the lookup fails
        }
      })
    )

    const list = result.items.map((quote) => ({
      id: quote.id,
      status: quote.status,
      label: quote.label ?? null,
      createdAt: quote.createdAt,
      expiresAt: quote.expiresAt,
      amount: quote.amount,
      createdBy: quote.createdBy
        ? (createdByNameById.get(quote.createdBy) ?? quote.createdBy)
        : null,
    }))

    return {
      list,
      paging: {
        total: result.totalItems,
        currentPage: result.pageNumber,
        perPage: result.pageSize,
      },
    }
  },
  validateUser: async (_: unknown, __: unknown, _ctx: GraphqlContext) => {
    // Authentication is now handled by @auth directive
    // If we reach here, validation was successful, otherwise an error would have been thrown
    return {
      isValid: true,
    }
  },
  isOrganizationMember: async (
    _: unknown,
    __: unknown,
    ctx: GraphqlContext
  ) => {
    const {
      clients: { commerce },
    } = ctx

    const sessionData = await commerce.session('').catch(() => null)

    return Boolean(sessionData?.namespaces.authentication?.unitId?.value)
  },
  // only b2b users
  userDetails: async (_: unknown, __: unknown, ctx: GraphqlContext) => {
    const {
      account,
      headers,
      clients: { commerce },
    } = ctx

    const jwt = parseJwt(getAuthCookie(headers?.cookie ?? '', account))
    const userId = jwt?.userId ?? ''

    const [sessionData, shopperResult, lmRoles] = await Promise.all([
      commerce.session('').catch(() => null),
      userId
        ? commerce.masterData.getShopperById({ userId }).catch(() => null)
        : Promise.resolve(null),
      userId
        ? commerce.licenseManager.getUserRoles({ userId }).catch(() => null)
        : Promise.resolve(null),
    ])

    const shopper = shopperResult?.[0]
    const authentication = sessionData?.namespaces.authentication ?? null

    const fullName =
      `${(shopper?.firstName ?? '').trim()} ${(shopper?.lastName ?? '').trim()}`.trim()

    return {
      username: authentication?.storeUserEmail?.value ?? '',
      name: fullName,
      email: authentication?.storeUserEmail?.value ?? '',
      phone: shopper?.phone ?? '',
      role: lmRoles?.Roles?.map((r) => r.Name) ?? [],
      orgUnit: authentication?.unitName?.value ?? '',
    }
  },
  // If isRepresentative, return b2b information.
  // If not, return b2c user information
  accountProfile: async (_: unknown, __: unknown, ctx: GraphqlContext) => {
    const {
      account,
      headers,
      clients: { commerce },
    } = ctx

    const jwt = parseJwt(getAuthCookie(headers?.cookie ?? '', account))

    if (!jwt?.userId) {
      return null
    }

    if (jwt?.isRepresentative) {
      const sessionData = await commerce.session('').catch(() => null)

      if (!sessionData) {
        return null
      }

      const profile = sessionData.namespaces.profile ?? null
      const shopper = sessionData.namespaces.shopper ?? null
      const authentication = sessionData.namespaces.authentication ?? null

      const contractId =
        resolveActiveContractIdFromSession(sessionData) ||
        jwt?.customerId?.trim() ||
        ''

      let contract = null
      if (contractId) {
        try {
          contract = await commerce.masterData.getContractById({ contractId })
        } catch (err) {
          console.error(
            `Error while getting contract data for contract ID (${contractId}).`,
            err
          )
        }
      }

      const shopperName =
        `${(shopper?.firstName?.value ?? '').trim()} ${(shopper?.lastName?.value ?? '').trim()}`.trim()
      const name =
        resolveActiveContractDisplayName(contract, profile) || shopperName

      return {
        name: name || '',
        email:
          profile?.email?.value || authentication?.storeUserEmail?.value || '',
        id:
          profile?.id?.value ||
          authentication?.customerId?.value ||
          jwt?.customerId?.trim() ||
          '',
        // createdAt: '',
      }
    }

    const user = await commerce.licenseManager
      .getUserById({
        userId: jwt?.userId,
      })
      .catch(() => null)

    return {
      name: user?.name || '',
      email: user?.email || '',
      id: user?.id || '',
      // createdAt: '',
    }
  },
  // only b2b users
  // Contract list from VTEX session `shopper.availableContracts`.
  availableContracts: async (
    _: unknown,
    { orgUnitId }: QueryAvailableContractsArgs,
    ctx: GraphqlContext
  ): Promise<StoreContract[]> => {
    if (!orgUnitId) {
      throw new BadRequestError('Missing orgUnitId')
    }

    const {
      account,
      headers,
      clients: { commerce },
    } = ctx

    const sessionData = await commerce.session('').catch(() => null)
    const authToken = getAuthCookie(headers?.cookie ?? '', account)
    let jwt: ReturnType<typeof parseJwt> = null

    try {
      jwt = authToken ? parseJwt(authToken) : null
    } catch {
      jwt = null
    }

    const sessionUnitId =
      sessionData?.namespaces.authentication?.unitId?.value?.trim() ??
      jwt?.unitId?.trim() ??
      ''

    if (!sessionUnitId || sessionUnitId !== orgUnitId) {
      throw new ForbiddenError(
        'You are not allowed to list contracts for this organization unit'
      )
    }

    const contracts = parseSessionAvailableContracts(
      sessionData?.namespaces.shopper
    )

    const activeContractId =
      resolveActiveContractIdFromSession(sessionData) ||
      jwt?.customerId?.trim() ||
      ''

    // Default flag lives only in the store-front BFF; never block the list on it.
    const attached = await commerce.storeFront
      .attachedContracts(orgUnitId)
      .catch((error) => {
        console.warn(
          'availableContracts: default contract lookup failed',
          error
        )
        return null
      })
    const defaultContractId = resolveDefaultContractId(attached?.contracts)

    return mapSessionContractsToStoreContracts(
      contracts,
      activeContractId,
      defaultContractId
    )
  },
  pickupPoints: async (
    _: unknown,
    { geoCoordinates, postalCode, country, channel }: QueryPickupPointsArgs,
    ctx: GraphqlContext
  ) => {
    const {
      clients: { search },
    } = ctx

    if (channel) {
      mutateChannelContext(ctx, channel)
    }

    const coordinates =
      geoCoordinates?.longitude != null && geoCoordinates?.latitude != null
        ? `${geoCoordinates.longitude},${geoCoordinates.latitude}`
        : undefined

    const result = await search.pickupPointAvailability({
      postalCode: postalCode ?? undefined,
      country: country ?? undefined,
      coordinates,
    })

    return {
      pickupPointDistances: result?.pickupPointDistances ?? [],
      pickupPointsHash: null,
    }
  },
  orderEntryOperation: getOrderEntryOperation,
  orderFormItems: getOrderFormItems,
  recommendations,
}
