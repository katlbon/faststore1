/*
  TODO: Code in a template string is not a good practice because it becomes very difficult to maintain.
  There will be a component called Layout that will wrap the entire My Account layout, including the global sections, menu, etc.
  This will reduce the amount of code inside the template string.
*/

export const myAccountPageTemplate = (pagePath: string) => `
  import type { ComponentType } from 'react'
  import RenderSections from 'src/components/cms/RenderSections'
  import { default as GLOBAL_COMPONENTS } from 'src/components/cms/global/Components'
  import CUSTOM_COMPONENTS from 'src/customizations/src/components'
  import { Layout } from 'src/components/account'
  import {
    getServerSideProps,
    type MyAccountProps,
  } from 'src/experimental/myAccountServerSideProps'
  import DynamicPage from '${pagePath}';
  import PageProvider from 'src/sdk/overrides/PageProvider'
  /* A list of components that can be used in the CMS. */
  const COMPONENTS: Record<string, ComponentType<any>> = {
    ...GLOBAL_COMPONENTS,
    ...CUSTOM_COMPONENTS,
  }

  function Page({ globalSections: globalSectionsProp, accountName, isRepresentative }: MyAccountProps) {
    const { sections: globalSections, settings: globalSettings } = globalSectionsProp ?? {}

    return (
     <PageProvider context={{ globalSettings }}>
        <RenderSections
          globalSections={globalSections}
          components={COMPONENTS}
        >
          <Layout accountName={accountName} isRepresentative={isRepresentative}>
            <DynamicPage />
          </Layout>
        </RenderSections>
      </PageProvider>
    )
  }

  export { getServerSideProps }

  export default Page
`
