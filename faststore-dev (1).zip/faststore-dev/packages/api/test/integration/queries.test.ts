import { execute, parse } from 'graphql'
import { beforeEach, expect, test, vi } from 'vitest'

import { GraphqlVtexContextFactory, GraphqlVtexSchema } from '../../src'
import type { Options } from '../../src/typings/globals'
import {
  AllCollectionsQueryFirst5,
  catalogBrandListFetch,
  catalogCategory3Fetch,
} from '../mocks/AllCollectionsQuery'
import {
  AllProductsQueryFirst5,
  productSearchPage1Count5Fetch,
} from '../mocks/AllProductsQuery'
import {
  CollectionDesksQuery,
  byLinkIdCategoryDesksFetch,
} from '../mocks/CollectionQuery'
import { ProductByIdQuery, pdpFetch } from '../mocks/ProductQuery'
import {
  RedirectQueryTermTech,
  redirectTermTechFetch,
} from '../mocks/RedirectQuery'
import {
  SearchQueryFirst5Products,
  attributeSearchCategory1Fetch,
  productSearchCategory1Fetch,
} from '../mocks/SearchQuery'
import { SellersQueryResult, regionFetch } from '../mocks/SellersQuery'
import {
  ShippingSimulationQueryResult,
  addressFetch,
  shippingSimulationFetch,
} from '../mocks/ShippingQuery'
import { salesChannelStaleFetch } from '../mocks/salesChannel'

vi.useFakeTimers({ shouldAdvanceTime: true })
const mockedFetch = vi.fn()

const apiOptions = {
  platform: 'vtex',
  account: 'storeframework',
  environment: 'vtexcommercestable',
  channel: '{"salesChannel":"1"}',
  locale: 'en-US',
  subDomainPrefix: ['www'],
  hideUnavailableItems: false,
  simulationBehavior: 'skip',
  showSponsored: false,
  incrementAddress: false,
  flags: {
    enableOrderFormSync: true,
    enableUnavailableItemsOnCart: false,
  },
} as Options

const createRunner = async () => {
  const schemaPromise = GraphqlVtexSchema()
  const contextFactory = await GraphqlVtexContextFactory(apiOptions)

  return async (query: string, variables?: any) => {
    const schema = await schemaPromise
    const context = contextFactory({})

    return execute({
      schema,
      document: parse(query),
      rootValue: null,
      contextValue: {
        ...context,
        headers: { 'content-type': 'application/json', cookie: '' },
      },
      variableValues: variables,
    })
  }
}

function pickFetchAPICallResult(
  info: RequestInfo,
  _: RequestInit | undefined,
  expectedFetchAPICalls: Array<Record<'info' | 'init' | 'result', unknown>>
) {
  for (const call of expectedFetchAPICalls) {
    if (info === call.info) {
      return call.result
    }
  }

  throw new Error(
    `fetchAPI was called with an unexpected 'info' argument.\ninfo: ${info}`
  )
}

vi.mock('../../src/platforms/vtex/clients/fetch.ts', () => ({
  fetchAPI: (
    info: RequestInfo,
    init?: RequestInit,
    options?: { storeCookies?: (headers: Headers) => void }
  ) => mockedFetch(info, init, options),
}))

// Always clear the mocked fetch before each test so we can count and validate
// the calls performed by each query independently.
beforeEach(() => {
  mockedFetch.mockClear()
})

test('`collection` query', async () => {
  const run = await createRunner()
  const fetchAPICalls = [byLinkIdCategoryDesksFetch]

  mockedFetch.mockImplementation((info, init) =>
    pickFetchAPICallResult(info, init, fetchAPICalls)
  )

  const response = await run(CollectionDesksQuery)

  expect(mockedFetch).toHaveBeenCalledTimes(1)

  fetchAPICalls.forEach((fetchAPICall) => {
    expect(mockedFetch).toHaveBeenCalledWith(
      fetchAPICall.info,
      fetchAPICall.init,
      fetchAPICall.options
    )
  })

  expect(response).toMatchSnapshot()
})

test('`product` query', async () => {
  const run = await createRunner()
  const fetchAPICalls = [pdpFetch, salesChannelStaleFetch]

  mockedFetch.mockImplementation((info, init) =>
    pickFetchAPICallResult(info, init, fetchAPICalls)
  )

  const response = await run(ProductByIdQuery)

  expect(mockedFetch).toHaveBeenCalledTimes(2)

  fetchAPICalls.forEach((fetchAPICall) => {
    expect(mockedFetch).toHaveBeenCalledWith(
      fetchAPICall.info,
      fetchAPICall.init,
      fetchAPICall.options
    )
  })

  expect(response).toMatchSnapshot()
})

test('`allCollections` query', async () => {
  const run = await createRunner()
  const fetchAPICalls = [catalogBrandListFetch, catalogCategory3Fetch]

  mockedFetch.mockImplementation((info, init) =>
    pickFetchAPICallResult(info, init, fetchAPICalls)
  )

  const response = await run(AllCollectionsQueryFirst5)

  expect(mockedFetch).toHaveBeenCalledTimes(2)

  fetchAPICalls.forEach((fetchAPICall) => {
    expect(mockedFetch).toHaveBeenCalledWith(
      fetchAPICall.info,
      fetchAPICall.init,
      fetchAPICall.options
    )
  })

  expect(response).toMatchSnapshot()
})

test('`allProducts` query', async () => {
  const run = await createRunner()
  const fetchAPICalls = [productSearchPage1Count5Fetch, salesChannelStaleFetch]

  mockedFetch.mockImplementation((info, init) =>
    pickFetchAPICallResult(info, init, fetchAPICalls)
  )

  const response = await run(AllProductsQueryFirst5)

  expect(mockedFetch).toHaveBeenCalledTimes(2)

  fetchAPICalls.forEach((fetchAPICall) => {
    expect(mockedFetch).toHaveBeenCalledWith(
      fetchAPICall.info,
      fetchAPICall.init,
      fetchAPICall.options
    )
  })

  expect(response).toMatchSnapshot()
})

test('`search` query', async () => {
  const run = await createRunner()
  const fetchAPICalls = [
    productSearchCategory1Fetch,
    attributeSearchCategory1Fetch,
    salesChannelStaleFetch,
  ]

  mockedFetch.mockImplementation((info, init) =>
    pickFetchAPICallResult(info, init, fetchAPICalls)
  )

  const response = await run(SearchQueryFirst5Products)

  expect(mockedFetch).toHaveBeenCalledTimes(3)

  fetchAPICalls.forEach((fetchAPICall) => {
    expect(mockedFetch).toHaveBeenCalledWith(
      fetchAPICall.info,
      fetchAPICall.init,
      fetchAPICall.options
    )
  })

  expect(response).toMatchSnapshot()
})

test('`shipping` query', async () => {
  const run = await createRunner()
  const fetchAPICalls = [addressFetch, shippingSimulationFetch]

  mockedFetch.mockImplementation((info, init) =>
    pickFetchAPICallResult(info, init, fetchAPICalls)
  )

  const response = await run(ShippingSimulationQueryResult)

  expect(mockedFetch).toHaveBeenCalledTimes(2)

  fetchAPICalls.forEach((fetchAPICall) => {
    expect(mockedFetch).toHaveBeenCalledWith(
      fetchAPICall.info,
      fetchAPICall.init,
      fetchAPICall.options
    )
  })

  expect(response).toMatchSnapshot()
})

test('`redirect` query', async () => {
  const run = await createRunner()
  const fetchAPICalls = [redirectTermTechFetch]

  mockedFetch.mockImplementation((info, init) =>
    pickFetchAPICallResult(info, init, fetchAPICalls)
  )

  const response = await run(RedirectQueryTermTech)

  expect(mockedFetch).toHaveBeenCalledTimes(1)

  fetchAPICalls.forEach((fetchAPICall) => {
    expect(mockedFetch).toHaveBeenCalledWith(
      fetchAPICall.info,
      fetchAPICall.init,
      fetchAPICall.options
    )
  })
  expect(response).toMatchSnapshot()
})

test('`sellers` query', async () => {
  const run = await createRunner()
  const fetchAPICalls = [regionFetch]

  mockedFetch.mockImplementation((info, init) =>
    pickFetchAPICallResult(info, init, fetchAPICalls)
  )

  const response = await run(SellersQueryResult)

  expect(mockedFetch).toHaveBeenCalledTimes(1)

  fetchAPICalls.forEach((fetchAPICall) => {
    expect(mockedFetch).toHaveBeenCalledWith(
      fetchAPICall.info,
      fetchAPICall.init,
      fetchAPICall.options
    )
  })
  expect(response).toMatchSnapshot()
})
