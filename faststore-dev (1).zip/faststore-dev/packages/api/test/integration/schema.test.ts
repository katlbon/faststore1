import { beforeAll, describe, expect, it } from 'vitest'

import type { GraphQLSchema } from 'graphql'
import { assertValidSchema, isObjectType } from 'graphql'

import { GraphqlVtexSchema } from '../../src'

const TYPES = [
  'StoreAggregateOffer',
  'StoreAggregateRating',
  'StoreAuthor',
  'StoreBrand',
  'StoreListItem',
  'StoreBreadcrumbList',
  'StoreCartMessage',
  'StoreCart',
  'IStoreCart',
  'StoreCollectionType',
  'StoreCollectionFacet',
  'StoreCollectionMeta',
  'StoreCollection',
  'StoreFacet',
  'StoreFacetRange',
  'StoreFacetBoolean',
  'StoreFacetValueRange',
  'StoreFacetValueBoolean',
  'StoreImage',
  'IStoreImage',
  'StoreOffer',
  'IStoreOffer',
  'StoreOrder',
  'IStoreOrder',
  'StoreOrganization',
  'IStoreOrganization',
  'StorePageInfo',
  'StoreProduct',
  'IStoreProduct',
  'StoreProductGroup',
  'StoreProductCluster',
  'StorePropertyValue',
  'StoreProductEdge',
  'StoreProductConnection',
  'StoreCollectionEdge',
  'StoreCollectionConnection',
  'StoreSort',
  'IStoreSelectedFacet',
  'StoreSearchResult',
  'StoreReviewRating',
  'StoreReview',
  'StoreSeo',
  'StoreStatus',
  'IShippingItem',
  'ShippingData',
  'LogisticsItem',
  'LogisticsInfo',
  'ShippingSLA',
  'DeliveryIds',
  'PickupStoreInfo',
  'PickupAddress',
  'MessageInfo',
  'MessageFields',
]

const QUERIES = [
  'product',
  'collection',
  'search',
  'allProducts',
  'products',
  'allCollections',
  'shipping',
  'redirect',
  'sellers',
  'profile',
  'productCount',
  'userOrder',
  'listCreditCards',
  'hasAdHocCardAccess',
  'listUserOrders',
  'listUserQuotes',
  'userDetails',
  'accountProfile',
  'validateUser',
  'availableContracts',
  'isOrganizationMember',
  'pickupPoints',
  'orderEntryOperation',
  'orderFormItems',
  'recommendations',
]

const MUTATIONS = [
  'validateCart',
  'validateSession',
  'subscribeToNewsletter',
  'cancelOrder',
  'processOrderAuthorization',
  'uploadFileToOrderEntry',
  'startOrderEntryOperation',
  'startRecommendationSession',
]

let schema: GraphQLSchema

beforeAll(async () => {
  schema = await GraphqlVtexSchema()
})

describe('Schema', () => {
  it('should return a valid GraphQL schema for VTEX platform', async () => {
    // `assertValidSchema()` will throw an error if the schema is invalid, and
    // return nothing if it is valid. That's why we're checking for `undefined`.
    expect(assertValidSchema(schema)).toBeUndefined()
  })

  it('should contain all expected types', async () => {
    TYPES.forEach((typeName) => {
      expect(schema.getType(typeName)).toBeDefined()
    })
  })

  it('should expose Intelligent Search product clusters on product groups', () => {
    const productGroup = schema.getType('StoreProductGroup')

    expect(isObjectType(productGroup)).toBe(true)

    if (!isObjectType(productGroup)) {
      return
    }

    // `toString()` prints the field the way it appears in the SDL.
    // This fails if the field becomes nullable, a single object, or a different type.
    expect(productGroup.getFields().productClusters.type.toString()).toBe(
      '[StoreProductCluster!]!'
    )

    const cluster = schema.getType('StoreProductCluster')

    expect(isObjectType(cluster)).toBe(true)

    if (!isObjectType(cluster)) {
      return
    }

    const clusterFields = cluster.getFields()

    expect(clusterFields.id.type.toString()).toBe('String!')
    expect(clusterFields.name.type.toString()).toBe('String!')
  })

  it('should contain all default queries', async () => {
    const queryFields = schema.getQueryType()?.getFields() ?? {}

    expect(Object.keys(queryFields)).toEqual(QUERIES)
  })

  it('should contain all default mutations', async () => {
    const mutationFields = schema.getMutationType()?.getFields() ?? {}

    expect(Object.keys(mutationFields)).toEqual(MUTATIONS)
  })
})
