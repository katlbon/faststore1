import type { GraphqlResolver } from '..'
import type { PromiseType } from '../../../typings/globals'
import { enhanceSku } from '../utils/enhanceSku'
import {
  createSlugsMap,
  getActiveSkuVariations,
  getFormattedVariations,
  getVariantsByName,
} from '../utils/skuVariants'
import type { StoreProduct } from './product'

export type Root = PromiseType<ReturnType<typeof StoreProduct.isVariantOf>>

type SlugsMapArgs = {
  dominantVariantName: string
}

export const SkuVariants: Record<string, GraphqlResolver<Root>> = {
  activeVariations: (root) => getActiveSkuVariations(root.variations),
  allVariantsByName: (root) =>
    getVariantsByName(root.isVariantOf.skuSpecifications),

  slugsMap: (root, args) =>
    createSlugsMap(
      root.isVariantOf.items,
      (args as SlugsMapArgs).dominantVariantName ?? root.variations[0]?.name,
      root.isVariantOf.linkText
    ),

  availableVariations: (root, args) => {
    const dominantVariantName =
      (args as SlugsMapArgs).dominantVariantName ?? root.variations[0]?.name
    const activeVariations = getActiveSkuVariations(root.variations)

    const activeDominantVariationValue = activeVariations[dominantVariantName]

    const filteredFormattedVariations = getFormattedVariations(
      root.isVariantOf.items,
      dominantVariantName,
      activeDominantVariationValue
    )

    return filteredFormattedVariations
  },
  allVariantProducts: (root) =>
    root.isVariantOf.items.map((item) => enhanceSku(item, root.isVariantOf)),
}
