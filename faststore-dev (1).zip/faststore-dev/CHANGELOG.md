# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [4.10.1-dev.2](https://github.com/vtex/faststore/compare/v4.10.1-dev.1...v4.10.1-dev.2) (2026-10-27)

### Bug Fixes

- **core:** keep CMS author emails off public page props ([a63c6b1](https://github.com/vtex/faststore/commit/a63c6b1b880055a9ceb6395ad3bba04ad2ce4a95))

## [4.10.1-dev.1](https://github.com/vtex/faststore/compare/v4.10.1-dev.0...v4.10.1-dev.1) (2026-10-21)

### Bug Fixes

- **core:** cache Content Platform template list across page generations ([#3526](https://github.com/vtex/faststore/issues/3526)) ([b03ed33](https://github.com/vtex/faststore/commit/b03ed332bd8c4ea5ef4bb834b8590728946852e5)), closes [#3384](https://github.com/vtex/faststore/issues/3384) [#3384](https://github.com/vtex/faststore/issues/3384)

## [4.10.1-dev.0](https://github.com/vtex/faststore/compare/v4.10.0...v4.10.1-dev.0) (2026-10-15)

**Note:** Version bump only for package faststore

# [4.10.0](https://github.com/vtex/faststore/compare/v4.10.0-dev.1...v4.10.0) (2026-10-15)

**Note:** Version bump only for package faststore

# [4.10.0-dev.1](https://github.com/vtex/faststore/compare/v4.10.0-dev.0...v4.10.0-dev.1) (2026-10-15)

### Bug Fixes

- accept coordinates as a pickup point location ([ed0a403](https://github.com/vtex/faststore/commit/ed0a4032fabeaec76b8eae8e23d4afaa1ae69430))
- **core:** drop a late pickup response and clear a failed simulation ([fa86e1c](https://github.com/vtex/faststore/commit/fa86e1c0a5026d73e5d869131b5647b39b2913f1))
- honor a postal code override without a country ([4a3f83c](https://github.com/vtex/faststore/commit/4a3f83cb56a9aef1a1802a493ea167be3bf3e618))
- ignore stale pickup point responses ([0936343](https://github.com/vtex/faststore/commit/0936343f334133e067aef9eded4821114191f08e))
- refresh pickup points when the shopper channel changes ([0a0e370](https://github.com/vtex/faststore/commit/0a0e370a270f8c6ab5de89a1889c2f808711077a))
- refresh stored pickup points for the current channel ([fac72e3](https://github.com/vtex/faststore/commit/fac72e3b02ee3997f413f98fdd92240f0db365a7))
- retry pickup points after a failed request ([6ead323](https://github.com/vtex/faststore/commit/6ead323d5d7170c1649d3d707dfe32d64807c04f))
- use the shopper sales channel for pickup points ([5034eb6](https://github.com/vtex/faststore/commit/5034eb6f564c154cf7a20bcf287d9365b10da022))

### Features

- list pickup points from Intelligent Search ([6dfb717](https://github.com/vtex/faststore/commit/6dfb71779c107276620a671e8739d2cd286103fe))

# [4.10.0-dev.0](https://github.com/vtex/faststore/compare/v4.9.3-dev.2...v4.10.0-dev.0) (2026-10-08)

### Features

- render images in RichText via a custom Lexical image node ([#3448](https://github.com/vtex/faststore/issues/3448)) ([a7c85b8](https://github.com/vtex/faststore/commit/a7c85b8478a64994b123f81ee08add594daa7b2f))

## [4.9.3-dev.2](https://github.com/vtex/faststore/compare/v4.9.3-dev.1...v4.9.3-dev.2) (2026-10-07)

### Bug Fixes

- address security & functional concerns from dk review ([d0b6106](https://github.com/vtex/faststore/commit/d0b610688ec551d8105c74750927be4ab1af7224))
- **core:** harden x-forwarded-host handling and drop orderNumber fallback ([c1faa35](https://github.com/vtex/faststore/commit/c1faa35fe070ff8b51d4f07a5f1f33da4b17d836)), closes [#3178](https://github.com/vtex/faststore/issues/3178)
- **core:** ignore multi-value x-forwarded-host and cover port and case ([b81d5d9](https://github.com/vtex/faststore/commit/b81d5d91721f9f8205251ad39e607b094386083c))
- **core:** log ignored x-forwarded-host and cover CR/LF hostnames ([adaa816](https://github.com/vtex/faststore/commit/adaa81608b7e72759272e1d6d23ca6257b9a4d59))
- **core:** make preview cookies host-only instead of rewriting their domain ([8e4901e](https://github.com/vtex/faststore/commit/8e4901ec7d127336bc27c0ae8e52c9cadea1a5a3))
- **core:** reject hostnames that would inject Set-Cookie attributes ([059a437](https://github.com/vtex/faststore/commit/059a4377c3b1b8f66aeed2b73ce130e1ab827f77))
- resolve ValidateCartMutation infinite loop in preview environments (SFS-3034) ([1cc9a5e](https://github.com/vtex/faststore/commit/1cc9a5efb1617f3d032623c4ee5f687ad5e2ccd9)), closes [#3178](https://github.com/vtex/faststore/issues/3178) [#3178](https://github.com/vtex/faststore/issues/3178) [#3190](https://github.com/vtex/faststore/issues/3190) [#3188](https://github.com/vtex/faststore/issues/3188) [#1467584](https://github.com/vtex/faststore/issues/1467584)

## [4.9.3-dev.1](https://github.com/vtex/faststore/compare/v4.9.3-dev.0...v4.9.3-dev.1) (2026-10-06)

### Bug Fixes

- keep empty carts from moving the session sales channel ([#3509](https://github.com/vtex/faststore/issues/3509)) ([600fb7d](https://github.com/vtex/faststore/commit/600fb7d9403553c12bd01d6b3955f18c48f91054)), closes [#3435](https://github.com/vtex/faststore/issues/3435) [#3435](https://github.com/vtex/faststore/issues/3435)

## [4.9.3-dev.0](https://github.com/vtex/faststore/compare/v4.9.1-dev.0...v4.9.3-dev.0) (2026-10-05)

**Note:** Version bump only for package faststore

## [4.9.2](https://github.com/vtex/faststore/compare/v4.9.1...v4.9.2) (2026-10-02)

### Bug Fixes

- **core:** keep UI session state out of session and cart mutations ([#3511](https://github.com/vtex/faststore/issues/3511)) ([3c58a21](https://github.com/vtex/faststore/commit/3c58a213d237f8d5f7919ab12f63015fbfe3ef73)), closes [#3479](https://github.com/vtex/faststore/issues/3479) [#3479](https://github.com/vtex/faststore/issues/3479) [#3509](https://github.com/vtex/faststore/issues/3509)

## [4.9.1](https://github.com/vtex/faststore/compare/v4.9.0...v4.9.1) (2026-10-02)

### Bug Fixes

- restore raw StoreProduct.releaseDate, normalize only in PDP JSON-LD ([#3508](https://github.com/vtex/faststore/issues/3508)) ([fb0112d](https://github.com/vtex/faststore/commit/fb0112df966dc59b8971c335bcb5fd405b715763)), closes [#3465](https://github.com/vtex/faststore/issues/3465) [#3465](https://github.com/vtex/faststore/issues/3465) [#1438](https://github.com/vtex/faststore/issues/1438) [#3437](https://github.com/vtex/faststore/issues/3437)

# [4.9.0](https://github.com/vtex/faststore/compare/v4.9.0-dev.8...v4.9.0) (2026-09-30)

**Note:** Version bump only for package faststore

# [4.9.0-dev.8](https://github.com/vtex/faststore/compare/v4.9.0-dev.7...v4.9.0-dev.8) (2026-09-30)

### Bug Fixes

- **api:** keep VTEX services out of validateCart line merging ([#3504](https://github.com/vtex/faststore/issues/3504)) ([2885fc6](https://github.com/vtex/faststore/commit/2885fc670860b671b587a63904c1a0393baf03db)), closes [#3460](https://github.com/vtex/faststore/issues/3460)

# [4.9.0-dev.7](https://github.com/vtex/faststore/compare/v4.9.0-dev.6...v4.9.0-dev.7) (2026-09-29)

### Features

- **api:** expose product clusters on product groups ([#3499](https://github.com/vtex/faststore/issues/3499)) ([d82c21b](https://github.com/vtex/faststore/commit/d82c21b66884ae61479179fd72d211decf9bd283)), closes [20v1.json#L1926-L1942](https://github.com/20v1.json/issues/L1926-L1942) [/github.com/vtex/faststore/blob/dev/packages/api/src/platforms/vtex/clients/search/types/ProductSearchResult.ts#L71-L83](https://github.com//github.com/vtex/faststore/blob/dev/packages/api/src/platforms/vtex/clients/search/types/ProductSearchResult.ts/issues/L71-L83)

# [4.9.0-dev.6](https://github.com/vtex/faststore/compare/v4.9.0-dev.5...v4.9.0-dev.6) (2026-09-29)

### Bug Fixes

- **cli:** include .faststore in Windows diagnostics artifact ([630bf4f](https://github.com/vtex/faststore/commit/630bf4f29eca50ee727dae060aa2a1f91adf4611))
- normalize next bin path to forward slashes on Windows ([a1231d0](https://github.com/vtex/faststore/commit/a1231d0e9687ddf1324ad46f158412f0af7231bb))
- run the CLI test suite on Windows ([2182bdf](https://github.com/vtex/faststore/commit/2182bdf9690fd81713d268faeb17349ba2480a37))

# [4.9.0-dev.5](https://github.com/vtex/faststore/compare/v4.9.0-dev.4...v4.9.0-dev.5) (2026-09-29)

### Bug Fixes

- **cli:** satisfy biome formatting in generate.test.ts ([5fbfb69](https://github.com/vtex/faststore/commit/5fbfb6931d449734901c0240faa28452a73012ef)), closes [#3486](https://github.com/vtex/faststore/issues/3486)
- **core:** avoid Yarn Classic Windows tar-extraction bug dropping src/pages/s.tsx ([1d9cec9](https://github.com/vtex/faststore/commit/1d9cec97a7b1eee249ed4521fe8c103eee81921a))

# [4.9.0-dev.4](https://github.com/vtex/faststore/compare/v4.9.0-dev.3...v4.9.0-dev.4) (2026-09-28)

### Bug Fixes

- **core:** localize My Account Quotes and Contract Switcher ([#3492](https://github.com/vtex/faststore/issues/3492)) ([d389c78](https://github.com/vtex/faststore/commit/d389c785ee831befadc937c4332261b1c6cab64e))

# [4.9.0-dev.3](https://github.com/vtex/faststore/compare/v4.9.0-dev.2...v4.9.0-dev.3) (2026-09-28)

### Bug Fixes

- refuse an unquotable next path inside the package.json builder ([#3503](https://github.com/vtex/faststore/issues/3503)) ([da85b46](https://github.com/vtex/faststore/commit/da85b4626e127c268a87c2e6533e012d4787670a)), closes [#3494](https://github.com/vtex/faststore/issues/3494)

# [4.9.0-dev.2](https://github.com/vtex/faststore/compare/v4.9.0-dev.1...v4.9.0-dev.2) (2026-09-28)

### Bug Fixes

- always quote the resolved next bin path ([#3494](https://github.com/vtex/faststore/issues/3494)) ([407a05a](https://github.com/vtex/faststore/commit/407a05aa7c1fe946c701d7c70097a13ed9bf5f68))

# [4.9.0-dev.1](https://github.com/vtex/faststore/compare/v4.9.0-dev.0...v4.9.0-dev.1) (2026-09-28)

### Bug Fixes

- resolve the store root by folder name when merging custom typeDefs ([#3502](https://github.com/vtex/faststore/issues/3502)) ([756baef](https://github.com/vtex/faststore/commit/756baefb20eccc97d35f9c40635dc757d7c73961))

# [4.9.0-dev.0](https://github.com/vtex/faststore/compare/v4.8.1-dev.3...v4.9.0-dev.0) (2026-09-24)

### Features

- **api,sdk:** support custom StoreSort values via customSortMap ([#3496](https://github.com/vtex/faststore/issues/3496)) ([8613faa](https://github.com/vtex/faststore/commit/8613faa046449801d17a2f0076e3a9b9d5a8c00f)), closes [/github.com/vtex/faststore/pull/3496#discussion_r4063084635](https://github.com//github.com/vtex/faststore/pull/3496/issues/discussion_r4063084635) [vtex-sites/playground.store#238](https://github.com/vtex-sites/playground.store/issues/238) [#3495](https://github.com/vtex/faststore/issues/3495)

## [4.8.1-dev.3](https://github.com/vtex/faststore/compare/v4.8.1-dev.2...v4.8.1-dev.3) (2026-09-22)

### Bug Fixes

- **core:** also normalize search-path concatenations in index/s pages ([519fb88](https://github.com/vtex/faststore/commit/519fb8885e483a8b00b292d342cce34cb4dd2cd6)), closes [#3498](https://github.com/vtex/faststore/issues/3498)
- **core:** normalize trailing slash on locale-aware store URLs (SFS-3390) ([07ff320](https://github.com/vtex/faststore/commit/07ff320232df8ba75e48902e4fb93f22fc33505c))
- **core:** pass rendered locale to getStoreURL in search canonical URL ([4ead8b8](https://github.com/vtex/faststore/commit/4ead8b86c1c53645db3afcd6cef41b085ffd5130))

## [4.8.1-dev.2](https://github.com/vtex/faststore/compare/v4.8.1-dev.1...v4.8.1-dev.2) (2026-09-21)

### Bug Fixes

- **core:** SUMA review fixes — reset cart/orderForm on contract switch, default contract in switcher, no Sign-in flash (B2BTEAM-3827) ([#3479](https://github.com/vtex/faststore/issues/3479)) ([d015186](https://github.com/vtex/faststore/commit/d015186f66bc5cdfce55d3da1c21b2d4dbb3d39e))

## [4.8.1-dev.1](https://github.com/vtex/faststore/compare/v4.8.1-dev.0...v4.8.1-dev.1) (2026-09-18)

### Bug Fixes

- **core:** avoid negated ternary condition flagged by Sonar ([c3fa734](https://github.com/vtex/faststore/commit/c3fa73440d9b98286b4ea1f7dfa737a44b06446b))
- **core:** guard the catch-path no-store header with headersSent ([48c21b8](https://github.com/vtex/faststore/commit/48c21b89d345e1a376c578f3171a0d10461f1689)), closes [#3485](https://github.com/vtex/faststore/issues/3485)
- **core:** localize My Account order copy ([#3490](https://github.com/vtex/faststore/issues/3490)) ([f77d3cf](https://github.com/vtex/faststore/commit/f77d3cfd1ca5b160ff003d090cb7c4413e2b0c56))
- **core:** set cache-control: no-store on GraphQL error responses ([dbb7d26](https://github.com/vtex/faststore/commit/dbb7d26078a04ebf9eee5a16e8cc3b6774acee73))
- **core:** set cache-control: no-store on the catch-path error responses ([5eec369](https://github.com/vtex/faststore/commit/5eec369bebc3b930e45078914e3e1d57bd22208d)), closes [#3485](https://github.com/vtex/faststore/issues/3485)

## [4.8.1-dev.0](https://github.com/vtex/faststore/compare/v4.8.0...v4.8.1-dev.0) (2026-09-15)

# [4.8.0-dev.8](https://github.com/vtex/faststore/compare/v4.8.0-dev.7...v4.8.0-dev.8) (2026-09-14)

### Bug Fixes

- **core:** align the saved-cards list with the design reference ([#3487](https://github.com/vtex/faststore/issues/3487)) ([0e0d3ea](https://github.com/vtex/faststore/commit/0e0d3eacc23f5d2027ef5f933b03cd8a0338885c))

# [4.8.0-dev.7](https://github.com/vtex/faststore/compare/v4.8.0-dev.6...v4.8.0-dev.7) (2026-09-14)

### Bug Fixes

- stop retrying upstream 429 responses ([#3453](https://github.com/vtex/faststore/issues/3453)) ([a142258](https://github.com/vtex/faststore/commit/a14225863578965609aa5012cc1ca9f0132959b2)), closes [#3379](https://github.com/vtex/faststore/issues/3379) [#3420](https://github.com/vtex/faststore/issues/3420) [#1629](https://github.com/vtex/faststore/issues/1629) [/github.com/vtex/faststore/pull/3453#issuecomment-5433632179](https://github.com//github.com/vtex/faststore/pull/3453/issues/issuecomment-5433632179)

# [4.8.0-dev.6](https://github.com/vtex/faststore/compare/v4.8.0-dev.5...v4.8.0-dev.6) (2026-09-11)

### Bug Fixes

- normalize outputFileTracingRoot to forward slashes on Windows ([#3484](https://github.com/vtex/faststore/issues/3484)) ([5c24f4a](https://github.com/vtex/faststore/commit/5c24f4a551853b1e93c898f4fa7d9729ceca44cc)), closes [#3483](https://github.com/vtex/faststore/issues/3483) [#3450](https://github.com/vtex/faststore/issues/3450) [#3483](https://github.com/vtex/faststore/issues/3483) [#3450](https://github.com/vtex/faststore/issues/3450) [#3450](https://github.com/vtex/faststore/issues/3450)

# [4.8.0-dev.5](https://github.com/vtex/faststore/compare/v4.8.0-dev.4...v4.8.0-dev.5) (2026-09-09)

### Bug Fixes

- forward contentSource.project as --storeId in cms-sync CP flow ([#3482](https://github.com/vtex/faststore/issues/3482)) ([c52365e](https://github.com/vtex/faststore/commit/c52365e74e00120961702ff3301f0f0d8fbe5449))

# [4.8.0-dev.4](https://github.com/vtex/faststore/compare/v4.8.0-dev.3...v4.8.0-dev.4) (2026-09-08)

### Bug Fixes

- generate GraphQL types when the project path contains spaces ([#3476](https://github.com/vtex/faststore/issues/3476)) ([b20c134](https://github.com/vtex/faststore/commit/b20c134eb5618f15e7e8328d6fa8ecc588d8e149)), closes [#3454](https://github.com/vtex/faststore/issues/3454) [#3454](https://github.com/vtex/faststore/issues/3454) [#3454](https://github.com/vtex/faststore/issues/3454) [#3454](https://github.com/vtex/faststore/issues/3454) [#3474](https://github.com/vtex/faststore/issues/3474) [#3475](https://github.com/vtex/faststore/issues/3475) [#3477](https://github.com/vtex/faststore/issues/3477)

# [4.8.0-dev.3](https://github.com/vtex/faststore/compare/v4.8.0-dev.2...v4.8.0-dev.3) (2026-09-08)

# [4.8.0-dev.2](https://github.com/vtex/faststore/compare/v4.8.0-dev.1...v4.8.0-dev.2) (2026-09-07)

### Features

- **api:** export `validateUserAuthentication` and `getAuthCookie` ([#3481](https://github.com/vtex/faststore/issues/3481)) ([3ead365](https://github.com/vtex/faststore/commit/3ead365e185dddf6af228ab04040c462f2a97679)), closes [#3480](https://github.com/vtex/faststore/issues/3480) [#3474](https://github.com/vtex/faststore/issues/3474) [#3480](https://github.com/vtex/faststore/issues/3480) [#3474](https://github.com/vtex/faststore/issues/3474)

# [4.8.0-dev.1](https://github.com/vtex/faststore/compare/v4.8.0-dev.0...v4.8.0-dev.1) (2026-09-03)

# [4.8.0-dev.0](https://github.com/vtex/faststore/compare/v4.7.1-dev.2...v4.8.0-dev.0) (2026-09-03)

### Bug Fixes

- **api:** export Resolver, GraphqlContext and helper types from the public entry ([0683c25](https://github.com/vtex/faststore/commit/0683c259c85ae603bf6dd23d7e0b8c64cc7b6ccf))
- **api:** keep the public Resolver type compatible with v3 ([e580a72](https://github.com/vtex/faststore/commit/e580a720d0b2d840b386f8809b8aed1d2acf00db))
- **cli:** keep store stories and Jest mocks out of the .faststore type-check ([2caafc1](https://github.com/vtex/faststore/commit/2caafc1112d5870c69a6673d7fd4d6b601404e3f)), closes [#3459](https://github.com/vtex/faststore/issues/3459)

## [4.7.1-dev.2](https://github.com/vtex/faststore/compare/v4.7.1-dev.1...v4.7.1-dev.2) (2026-09-02)

### Bug Fixes

- **core:** align mini cart shelf contract with review feedback ([cc8f4a4](https://github.com/vtex/faststore/commit/cc8f4a483fffc6ecdceb5f7c8d97f9568156eeba))
- **core:** narrow cart shelf props before accessing campaignVrn ([84edae7](https://github.com/vtex/faststore/commit/84edae7a2978bfd6c7a6f5223d4eaf31602dd54a))
- keep package manager spawn off a shell and out of generate.ts ([4807b0a](https://github.com/vtex/faststore/commit/4807b0af08c214b58160a90246234e5242280224))

## [4.7.1-dev.1](https://github.com/vtex/faststore/compare/v4.7.1-dev.0...v4.7.1-dev.1) (2026-09-01)

### Bug Fixes

- point localized canonical and hreflang at the rendered locale ([#3470](https://github.com/vtex/faststore/issues/3470)) ([d9038cf](https://github.com/vtex/faststore/commit/d9038cf631cf40eae5b9d9e3eb2c33290eba7b73))

## [4.7.1-dev.0](https://github.com/vtex/faststore/compare/v4.7.0...v4.7.1-dev.0) (2026-08-31)

### Bug Fixes

- **core:** format CartRecommendationShelf Omit union for Biome ([318741d](https://github.com/vtex/faststore/commit/318741d46968426a66b45dc348732ff0a37ac231))
- **core:** satisfy Sonar fragment and Stylelint on the cart shelf ([3423300](https://github.com/vtex/faststore/commit/3423300542f1a478fab856efc070faf333d358d3))
- **RecommendationShelf:** update README to clarify rendering behavior on empty cart ([c1b0fa9](https://github.com/vtex/faststore/commit/c1b0fa98a5e322b151efc27307e1f34e5c468038))
- refuse package manager substitution when installing dependencies ([1a06a13](https://github.com/vtex/faststore/commit/1a06a13dd7feafab89f4792831a863c786c7ded8)), closes [#3422](https://github.com/vtex/faststore/issues/3422)
- resolve the package manager against the target directory ([86f1732](https://github.com/vtex/faststore/commit/86f1732025d187d6c24899258642379872b7a8e7)), closes [#3422](https://github.com/vtex/faststore/issues/3422)
- stop forwarding unvalidated ni output to the shell in the CLI ([84eb880](https://github.com/vtex/faststore/commit/84eb88052aec6625d9deb5d535e7d182a08e1cbb))

### Features

- **cart:** add recommendations shelf to cart drawer ([879bda5](https://github.com/vtex/faststore/commit/879bda58bcae0094b868d5d8ce5a1b594ae7007f))
- **cart:** enhance CartRecommendationShelf with new styles and props ([8bb604d](https://github.com/vtex/faststore/commit/8bb604d4cdebdeefb39e9d0a4c0475afc72aed3d))
- **core:** opt the mini cart shelf in via a CMS display condition ([dec10d0](https://github.com/vtex/faststore/commit/dec10d0cc5b04d64eaf02c27192eeffdaf3eedc5))
- **RecommendationShelf:** add data attributes for CSS targeting ([ddd5bec](https://github.com/vtex/faststore/commit/ddd5bec44357d85c43dfee4c2162d6e51ee8a06b))

# [4.8.0](https://github.com/vtex/faststore/compare/v4.7.0...v4.8.0) (2026-09-15)

### Features

- release 4.8.0 (graduate dev → main) ([#3488](https://github.com/vtex/faststore/issues/3488)) ([09ff84a](https://github.com/vtex/faststore/commit/09ff84aabe1f5a5a74fe52c191f37e5521dd8e9b)), closes [#3466](https://github.com/vtex/faststore/issues/3466) [#3481](https://github.com/vtex/faststore/issues/3481) [#3487](https://github.com/vtex/faststore/issues/3487) [#3453](https://github.com/vtex/faststore/issues/3453) [#3484](https://github.com/vtex/faststore/issues/3484) [#3482](https://github.com/vtex/faststore/issues/3482) [#3476](https://github.com/vtex/faststore/issues/3476) [#3477](https://github.com/vtex/faststore/issues/3477) [#3474](https://github.com/vtex/faststore/issues/3474) [#3422](https://github.com/vtex/faststore/issues/3422) [#3470](https://github.com/vtex/faststore/issues/3470)

# [4.8.0-dev.8](https://github.com/vtex/faststore/compare/v4.8.0-dev.7...v4.8.0-dev.8) (2026-09-14)

### Bug Fixes

- **core:** align the saved-cards list with the design reference ([#3487](https://github.com/vtex/faststore/issues/3487)) ([0e0d3ea](https://github.com/vtex/faststore/commit/0e0d3eacc23f5d2027ef5f933b03cd8a0338885c))

# [4.8.0-dev.7](https://github.com/vtex/faststore/compare/v4.8.0-dev.6...v4.8.0-dev.7) (2026-09-14)

### Bug Fixes

- stop retrying upstream 429 responses ([#3453](https://github.com/vtex/faststore/issues/3453)) ([a142258](https://github.com/vtex/faststore/commit/a14225863578965609aa5012cc1ca9f0132959b2)), closes [#3379](https://github.com/vtex/faststore/issues/3379) [#3420](https://github.com/vtex/faststore/issues/3420) [#1629](https://github.com/vtex/faststore/issues/1629) [/github.com/vtex/faststore/pull/3453#issuecomment-5433632179](https://github.com//github.com/vtex/faststore/pull/3453/issues/issuecomment-5433632179)

# [4.8.0-dev.6](https://github.com/vtex/faststore/compare/v4.8.0-dev.5...v4.8.0-dev.6) (2026-09-11)

### Bug Fixes

- normalize outputFileTracingRoot to forward slashes on Windows ([#3484](https://github.com/vtex/faststore/issues/3484)) ([5c24f4a](https://github.com/vtex/faststore/commit/5c24f4a551853b1e93c898f4fa7d9729ceca44cc)), closes [#3483](https://github.com/vtex/faststore/issues/3483) [#3450](https://github.com/vtex/faststore/issues/3450) [#3483](https://github.com/vtex/faststore/issues/3483) [#3450](https://github.com/vtex/faststore/issues/3450) [#3450](https://github.com/vtex/faststore/issues/3450)

# [4.8.0-dev.5](https://github.com/vtex/faststore/compare/v4.8.0-dev.4...v4.8.0-dev.5) (2026-09-09)

### Bug Fixes

- forward contentSource.project as --storeId in cms-sync CP flow ([#3482](https://github.com/vtex/faststore/issues/3482)) ([c52365e](https://github.com/vtex/faststore/commit/c52365e74e00120961702ff3301f0f0d8fbe5449))

# [4.8.0-dev.4](https://github.com/vtex/faststore/compare/v4.8.0-dev.3...v4.8.0-dev.4) (2026-09-08)

### Bug Fixes

- generate GraphQL types when the project path contains spaces ([#3476](https://github.com/vtex/faststore/issues/3476)) ([b20c134](https://github.com/vtex/faststore/commit/b20c134eb5618f15e7e8328d6fa8ecc588d8e149)), closes [#3454](https://github.com/vtex/faststore/issues/3454) [#3454](https://github.com/vtex/faststore/issues/3454) [#3454](https://github.com/vtex/faststore/issues/3454) [#3454](https://github.com/vtex/faststore/issues/3454) [#3474](https://github.com/vtex/faststore/issues/3474) [#3475](https://github.com/vtex/faststore/issues/3475) [#3477](https://github.com/vtex/faststore/issues/3477)

# [4.8.0-dev.3](https://github.com/vtex/faststore/compare/v4.8.0-dev.2...v4.8.0-dev.3) (2026-09-08)

**Note:** Version bump only for package faststore

# [4.8.0-dev.2](https://github.com/vtex/faststore/compare/v4.8.0-dev.1...v4.8.0-dev.2) (2026-09-07)

### Features

- **api:** export `validateUserAuthentication` and `getAuthCookie` ([#3481](https://github.com/vtex/faststore/issues/3481)) ([3ead365](https://github.com/vtex/faststore/commit/3ead365e185dddf6af228ab04040c462f2a97679)), closes [#3480](https://github.com/vtex/faststore/issues/3480) [#3474](https://github.com/vtex/faststore/issues/3474) [#3480](https://github.com/vtex/faststore/issues/3480) [#3474](https://github.com/vtex/faststore/issues/3474)

# [4.8.0-dev.1](https://github.com/vtex/faststore/compare/v4.8.0-dev.0...v4.8.0-dev.1) (2026-09-03)

### Bug Fixes

- **api:** export Resolver, GraphqlContext and helper types from the public entry ([0683c25](https://github.com/vtex/faststore/commit/0683c259c85ae603bf6dd23d7e0b8c64cc7b6ccf))
- **api:** keep the public Resolver type compatible with v3 ([e580a72](https://github.com/vtex/faststore/commit/e580a720d0b2d840b386f8809b8aed1d2acf00db))
- **cli:** keep store stories and Jest mocks out of the .faststore type-check ([2caafc1](https://github.com/vtex/faststore/commit/2caafc1112d5870c69a6673d7fd4d6b601404e3f)), closes [#3459](https://github.com/vtex/faststore/issues/3459)

# [4.8.0-dev.0](https://github.com/vtex/faststore/compare/v4.7.1-dev.2...v4.8.0-dev.0) (2026-09-03)

### Bug Fixes

- **core:** align mini cart shelf contract with review feedback ([cc8f4a4](https://github.com/vtex/faststore/commit/cc8f4a483fffc6ecdceb5f7c8d97f9568156eeba))
- **core:** format CartRecommendationShelf Omit union for Biome ([318741d](https://github.com/vtex/faststore/commit/318741d46968426a66b45dc348732ff0a37ac231))
- **core:** narrow cart shelf props before accessing campaignVrn ([84edae7](https://github.com/vtex/faststore/commit/84edae7a2978bfd6c7a6f5223d4eaf31602dd54a))
- **core:** satisfy Sonar fragment and Stylelint on the cart shelf ([3423300](https://github.com/vtex/faststore/commit/3423300542f1a478fab856efc070faf333d358d3))
- **RecommendationShelf:** update README to clarify rendering behavior on empty cart ([c1b0fa9](https://github.com/vtex/faststore/commit/c1b0fa98a5e322b151efc27307e1f34e5c468038))

### Features

- **cart:** add recommendations shelf to cart drawer ([879bda5](https://github.com/vtex/faststore/commit/879bda58bcae0094b868d5d8ce5a1b594ae7007f))
- **cart:** enhance CartRecommendationShelf with new styles and props ([8bb604d](https://github.com/vtex/faststore/commit/8bb604d4cdebdeefb39e9d0a4c0475afc72aed3d))
- **core:** opt the mini cart shelf in via a CMS display condition ([dec10d0](https://github.com/vtex/faststore/commit/dec10d0cc5b04d64eaf02c27192eeffdaf3eedc5))
- **RecommendationShelf:** add data attributes for CSS targeting ([ddd5bec](https://github.com/vtex/faststore/commit/ddd5bec44357d85c43dfee4c2162d6e51ee8a06b))

## [4.7.1-dev.2](https://github.com/vtex/faststore/compare/v4.7.1-dev.1...v4.7.1-dev.2) (2026-09-02)

### Bug Fixes

- keep package manager spawn off a shell and out of generate.ts ([4807b0a](https://github.com/vtex/faststore/commit/4807b0af08c214b58160a90246234e5242280224))
- refuse package manager substitution when installing dependencies ([1a06a13](https://github.com/vtex/faststore/commit/1a06a13dd7feafab89f4792831a863c786c7ded8)), closes [#3422](https://github.com/vtex/faststore/issues/3422)
- resolve the package manager against the target directory ([86f1732](https://github.com/vtex/faststore/commit/86f1732025d187d6c24899258642379872b7a8e7)), closes [#3422](https://github.com/vtex/faststore/issues/3422)
- stop forwarding unvalidated ni output to the shell in the CLI ([84eb880](https://github.com/vtex/faststore/commit/84eb88052aec6625d9deb5d535e7d182a08e1cbb))

## [4.7.1-dev.1](https://github.com/vtex/faststore/compare/v4.7.1-dev.0...v4.7.1-dev.1) (2026-09-01)

### Bug Fixes

- point localized canonical and hreflang at the rendered locale ([#3470](https://github.com/vtex/faststore/issues/3470)) ([d9038cf](https://github.com/vtex/faststore/commit/d9038cf631cf40eae5b9d9e3eb2c33290eba7b73))

## [4.7.1-dev.0](https://github.com/vtex/faststore/compare/v4.7.0...v4.7.1-dev.0) (2026-08-31)

**Note:** Version bump only for package faststore

# [4.7.0](https://github.com/vtex/faststore/compare/v4.7.0-dev.9...v4.7.0) (2026-08-31)

**Note:** Version bump only for package faststore

# [4.7.0-dev.9](https://github.com/vtex/faststore/compare/v4.7.0-dev.8...v4.7.0-dev.9) (2026-08-31)

### Bug Fixes

- **api:** separate hreflang slugs from locale-switch navigation ([#3462](https://github.com/vtex/faststore/issues/3462)) ([3091a46](https://github.com/vtex/faststore/commit/3091a46031f387d1e11e5747dd0f4ac6bef358e2))

# [4.7.0-dev.8](https://github.com/vtex/faststore/compare/v4.7.0-dev.7...v4.7.0-dev.8) (2026-08-28)

### Bug Fixes

- **deps:** keep Yarn 1 from hoisting an incompatible @inquirer/type into the CLI ([6e5cfca](https://github.com/vtex/faststore/commit/6e5cfca1a8d029390bcc3b463a328d513481d457))
- keep core unit tests out of the storefront .faststore app ([c7fed58](https://github.com/vtex/faststore/commit/c7fed5822d24066efdd44ec86d69f61d0d309bd7))

# [4.7.0-dev.7](https://github.com/vtex/faststore/compare/v4.7.0-dev.6...v4.7.0-dev.7) (2026-08-28)

### Bug Fixes

- **core:** resolve redirect matcher module explicitly ([#3467](https://github.com/vtex/faststore/issues/3467)) ([7acecf0](https://github.com/vtex/faststore/commit/7acecf03604842db166de7c53038065934c91154)), closes [#1450148](https://github.com/vtex/faststore/issues/1450148) [#3468](https://github.com/vtex/faststore/issues/3468)

# [4.7.0-dev.6](https://github.com/vtex/faststore/compare/v4.7.0-dev.5...v4.7.0-dev.6) (2026-08-26)

### Bug Fixes

- make PDP product JSON-LD Schema.org compliant ([#3465](https://github.com/vtex/faststore/issues/3465)) ([0c09f15](https://github.com/vtex/faststore/commit/0c09f15456d3490602970ce0b4dff6b3c76a4f9c)), closes [#1449246](https://github.com/vtex/faststore/issues/1449246)

# [4.7.0-dev.5](https://github.com/vtex/faststore/compare/v4.7.0-dev.4...v4.7.0-dev.5) (2026-08-25)

### Bug Fixes

- **core:** restore Order Details layout and first-paint rendering in My Account ([#3464](https://github.com/vtex/faststore/issues/3464)) ([3464523](https://github.com/vtex/faststore/commit/346452304b265d439184bca3f56c2ae8a9341cce)), closes [#3354](https://github.com/vtex/faststore/issues/3354) [#3354](https://github.com/vtex/faststore/issues/3354) [#3417](https://github.com/vtex/faststore/issues/3417) [/github.com/vtex/faststore/pull/3464#discussion_r3848325785](https://github.com//github.com/vtex/faststore/pull/3464/issues/discussion_r3848325785) [#3411](https://github.com/vtex/faststore/issues/3411) [#3354](https://github.com/vtex/faststore/issues/3354)

# [4.7.0-dev.4](https://github.com/vtex/faststore/compare/v4.7.0-dev.3...v4.7.0-dev.4) (2026-08-25)

### Bug Fixes

- **core:** address Sonar and session fallback timing ([c0ad09f](https://github.com/vtex/faststore/commit/c0ad09f4903627ce39b233013af40ab2505b5871))
- **core:** make session enable flag assignment Sonar-clear ([2fdfe96](https://github.com/vtex/faststore/commit/2fdfe96d6dccb22c33fb9f7f250f5531ef6f6f47))
- **core:** start shelf session fallback in parallel with userId lookup ([6f5afa5](https://github.com/vtex/faststore/commit/6f5afa587a554ab9a4289c01aa6c6eb57e027680))

### Features

- **core:** gate recommendation session by feature flag with shelf fallback ([901b345](https://github.com/vtex/faststore/commit/901b3456943de25f028d6443f5f62b9de1db6ad3))

# [4.7.0-dev.3](https://github.com/vtex/faststore/compare/v4.7.0-dev.2...v4.7.0-dev.3) (2026-08-25)

### Bug Fixes

- **api:** correct item videos field casing ([#3447](https://github.com/vtex/faststore/issues/3447)) ([80c5fd7](https://github.com/vtex/faststore/commit/80c5fd7a33571e3250190066e4dafc6c865e7f07))

# [4.7.0-dev.2](https://github.com/vtex/faststore/compare/v4.7.0-dev.1...v4.7.0-dev.2) (2026-08-24)

### Bug Fixes

- gate the Cards route and sidebar entry on org membership ([#3463](https://github.com/vtex/faststore/issues/3463)) ([fa8c42e](https://github.com/vtex/faststore/commit/fa8c42e4bf242de9122dd79ba2681f9117f71695)), closes [#3443](https://github.com/vtex/faststore/issues/3443) [#3443](https://github.com/vtex/faststore/issues/3443) [#3443](https://github.com/vtex/faststore/issues/3443) [#3443](https://github.com/vtex/faststore/issues/3443) [#3443](https://github.com/vtex/faststore/issues/3443)

# [4.7.0-dev.1](https://github.com/vtex/faststore/compare/v4.7.0-dev.0...v4.7.0-dev.1) (2026-08-24)

### Bug Fixes

- let Sonar recognise test files ([a7b966a](https://github.com/vtex/faststore/commit/a7b966a6e3eafe51fec687169781f2f78137c9e9))
- reference next by a path relative to .faststore ([372b66e](https://github.com/vtex/faststore/commit/372b66e328d73802f7cffcc05bae48e966eabc97))
- resolve the next binary from @faststore/core ([5478a4d](https://github.com/vtex/faststore/commit/5478a4dd24ffa7ab5d12907b945698cd04cb2f79))
- write the resolved next path with forward slashes ([95c07f9](https://github.com/vtex/faststore/commit/95c07f935037f419304eb792bebc6d6f4af983ac))

# [4.7.0-dev.0](https://github.com/vtex/faststore/compare/v4.6.1-dev.0...v4.7.0-dev.0) (2026-08-24)

### Features

- My Account Cards — Personal + Shared listing ([#3443](https://github.com/vtex/faststore/issues/3443)) ([6dded69](https://github.com/vtex/faststore/commit/6dded6905ed5bbf5c7fe71cfc106abf95c816888)), closes [vtex/faststore-dx-spec-kit#24](https://github.com/vtex/faststore-dx-spec-kit/issues/24)

## [4.6.1-dev.0](https://github.com/vtex/faststore/compare/v4.6.0...v4.6.1-dev.0) (2026-08-18)

**Note:** Version bump only for package faststore

# [4.6.0](https://github.com/vtex/faststore/compare/v4.6.0-dev.6...v4.6.0) (2026-08-18)

**Note:** Version bump only for package faststore

# [4.6.0-dev.6](https://github.com/vtex/faststore/compare/v4.6.0-dev.5...v4.6.0-dev.6) (2026-08-14)

### Bug Fixes

- resolve node_modules bins when running scripts inside .faststore ([#3440](https://github.com/vtex/faststore/issues/3440)) ([2bf174a](https://github.com/vtex/faststore/commit/2bf174a7295d106354d97d7ca2c161ed706cff9a)), closes [#3439](https://github.com/vtex/faststore/issues/3439) [#3419](https://github.com/vtex/faststore/issues/3419)

# [4.6.0-dev.5](https://github.com/vtex/faststore/compare/v4.6.0-dev.4...v4.6.0-dev.5) (2026-08-13)

### Bug Fixes

- **core:** add experimental.revalidate404 and skip PLP query on notFound ([855a3ee](https://github.com/vtex/faststore/commit/855a3ee2e3393ee092d4b261ad83a8757289e132))
- **core:** revalidate ISR cache for notFound PDP/PLP paths ([1d1015e](https://github.com/vtex/faststore/commit/1d1015e8874d794c5f54e572afc3c676fabce69c))

# [4.6.0-dev.4](https://github.com/vtex/faststore/compare/v4.6.0-dev.3...v4.6.0-dev.4) (2026-08-12)

### Bug Fixes

- custom GraphQL typeDefs silently ignored on Windows ([#3419](https://github.com/vtex/faststore/issues/3419)) ([bdeb6a7](https://github.com/vtex/faststore/commit/bdeb6a757c44dda24b96cffc73d34652de165adf))

# [4.6.0-dev.3](https://github.com/vtex/faststore/compare/v4.6.0-dev.2...v4.6.0-dev.3) (2026-08-12)

**Note:** Version bump only for package faststore

# [4.6.0-dev.2](https://github.com/vtex/faststore/compare/v4.6.0-dev.1...v4.6.0-dev.2) (2026-08-12)

### Bug Fixes

- **api:** address Sonar and harden session sales-channel sync ([5f6e8e9](https://github.com/vtex/faststore/commit/5f6e8e909def75f60c24cdaffae9303ed2c0a052))
- **api:** address Sonar findings in validateCart and orderForm URL ([3211231](https://github.com/vtex/faststore/commit/321123179d3e5789fb7730ef94c8f2f0d8b878b1))
- **api:** keep orderForm sales channel after stale validateCart sync ([09b051b](https://github.com/vtex/faststore/commit/09b051b80aaff7183adf7f5e86aece438bcd38f0))
- **api:** preserve orderForm sales channel in validateCart ([2336cda](https://github.com/vtex/faststore/commit/2336cda2c95970850dd0d29c1c18043ca8c9078a))
- **api:** sync adopted orderForm sales channel into session ([8943da7](https://github.com/vtex/faststore/commit/8943da7821f8abec08a39b7907a258bf156b05ee))

### Reverts

- Revert "docs(api): add before/after screenshots for validateCart PR" ([eaaf032](https://github.com/vtex/faststore/commit/eaaf0323b004988d849679ba19ff61ab75dd0875))

# [4.6.0-dev.1](https://github.com/vtex/faststore/compare/v4.6.0-dev.0...v4.6.0-dev.1) (2026-08-11)

## [4.5.1](https://github.com/vtex/faststore/compare/v4.5.1-dev.4...v4.5.1) (2026-08-11)

### Bug Fixes

- **core:** address scroll restoration review feedback ([a5fe6a3](https://github.com/vtex/faststore/commit/a5fe6a35c54e6095f81c7995a815ce6ef3b4dd4e))
- **core:** align beforePopState callback with NextHistoryState ([10719e5](https://github.com/vtex/faststore/commit/10719e5eca199385d9fe18bdd6d7da290716a1d5))
- **core:** compare window to undefined directly for Sonar ([bf05a54](https://github.com/vtex/faststore/commit/bf05a54bb014d120b7bdc95ff7c01a4e9b35b485))
- **core:** harden scroll restore path matching and hydration-safe heights ([34efa6b](https://github.com/vtex/faststore/commit/34efa6bda7549895a4531277c2fe55bd6bbe98a7))
- **core:** hash gallery height keys to avoid truncation collisions ([9e98043](https://github.com/vtex/faststore/commit/9e980438d74e457fa33aa77900438339463a078c))
- **core:** prevent IS redirect hang and improve scroll restoration ([5f30778](https://github.com/vtex/faststore/commit/5f30778161eec2e4381b3fe971479dd7cbe53b08))
- **core:** reset infinite scroll on forward listing navigations ([249226a](https://github.com/vtex/faststore/commit/249226a3acbe4cb26d687cf962125b2593d5949e))
- **core:** resolve Sonar new-code smells for scroll restoration ([59b41ed](https://github.com/vtex/faststore/commit/59b41ed1d2a30ba693726b19895a0279eb1ba464))
- **core:** restore PLP infinite-scroll pages on back navigation ([92b2efa](https://github.com/vtex/faststore/commit/92b2efa1d4d0895a10b5a0e71a4d9bf37cae1686))
- **core:** resync gallery height lock when children change ([5058089](https://github.com/vtex/faststore/commit/50580898d97baf800b97c8a876f7967529859c61))
- **core:** satisfy Sonar on gallery height key hash ([3a6ce47](https://github.com/vtex/faststore/commit/3a6ce47485c26be75d6d76906df3af64c9e34fd6))
- **core:** type scroll restore paint timer for DOM/Node setTimeout ([940c903](https://github.com/vtex/faststore/commit/940c90376f8d2eb77665e73a6fb0ea53c9786c8e))
- **core:** use replaceAll for infinite-scroll session key ([4f52048](https://github.com/vtex/faststore/commit/4f520482a9ba9661782fcf25a286b8f2e6c6b922))

# [4.6.0-dev.0](https://github.com/vtex/faststore/compare/v4.5.1-dev.4...v4.6.0-dev.0) (2026-08-11)

### Features

- removing vtex/diagnostics-nodejs ([#3389](https://github.com/vtex/faststore/issues/3389)) ([74e2d50](https://github.com/vtex/faststore/commit/74e2d503a44903929b90af7701956536690d4e41))

## [4.5.1-dev.4](https://github.com/vtex/faststore/compare/v4.5.1-dev.3...v4.5.1-dev.4) (2026-08-10)

### Bug Fixes

- restore account, path, port arg order on cli dev command ([#3439](https://github.com/vtex/faststore/issues/3439)) ([b13e834](https://github.com/vtex/faststore/commit/b13e8341539fb8108c35a63f26218c4671d308f8)), closes [#3111](https://github.com/vtex/faststore/issues/3111) [#2491](https://github.com/vtex/faststore/issues/2491) [#2491](https://github.com/vtex/faststore/issues/2491) [#3111](https://github.com/vtex/faststore/issues/3111)

## [4.5.1-dev.3](https://github.com/vtex/faststore/compare/v4.5.1-dev.2...v4.5.1-dev.3) (2026-08-10)

### Bug Fixes

- **core:** add twitter card meta tag to default next seo config ([720f3e6](https://github.com/vtex/faststore/commit/720f3e6d04ef523f2fcf0e146c3741b7e5af70fa))
- **core:** add twittermeta tags validaton for tests ([c8f5872](https://github.com/vtex/faststore/commit/c8f5872e42b69ddae5b2abfa0e8d3140e2bc7163))
- **core:** lint error ([d07460f](https://github.com/vtex/faststore/commit/d07460f890ba712c9aecbec25bda5de96bf3e4ef))
- **core:** remove duplicated twitter meta tag ([f388288](https://github.com/vtex/faststore/commit/f388288731ff75fceedba3cd7449ef1088b0b0c2))
- **metaTags:** add twitter meta tags to nextSeo ([9c2439b](https://github.com/vtex/faststore/commit/9c2439b4a668dd81b7bfe5bdc44df575725067ec))

## [4.5.1](https://github.com/vtex/faststore/compare/v4.5.1-dev.2...v4.5.1) (2026-08-11)

- **core:** address scroll restoration review feedback ([a5fe6a3](https://github.com/vtex/faststore/commit/a5fe6a35c54e6095f81c7995a815ce6ef3b4dd4e))
- **core:** align beforePopState callback with NextHistoryState ([10719e5](https://github.com/vtex/faststore/commit/10719e5eca199385d9fe18bdd6d7da290716a1d5))
- **core:** compare window to undefined directly for Sonar ([bf05a54](https://github.com/vtex/faststore/commit/bf05a54bb014d120b7bdc95ff7c01a4e9b35b485))
- **core:** harden scroll restore path matching and hydration-safe heights ([34efa6b](https://github.com/vtex/faststore/commit/34efa6bda7549895a4531277c2fe55bd6bbe98a7))
- **core:** hash gallery height keys to avoid truncation collisions ([9e98043](https://github.com/vtex/faststore/commit/9e980438d74e457fa33aa77900438339463a078c))
- **core:** prevent IS redirect hang and improve scroll restoration ([5f30778](https://github.com/vtex/faststore/commit/5f30778161eec2e4381b3fe971479dd7cbe53b08))
- **core:** reset infinite scroll on forward listing navigations ([249226a](https://github.com/vtex/faststore/commit/249226a3acbe4cb26d687cf962125b2593d5949e))
- **core:** resolve Sonar new-code smells for scroll restoration ([59b41ed](https://github.com/vtex/faststore/commit/59b41ed1d2a30ba693726b19895a0279eb1ba464))
- **core:** restore PLP infinite-scroll pages on back navigation ([92b2efa](https://github.com/vtex/faststore/commit/92b2efa1d4d0895a10b5a0e71a4d9bf37cae1686))
- **core:** resync gallery height lock when children change ([5058089](https://github.com/vtex/faststore/commit/50580898d97baf800b97c8a876f7967529859c61))
- **core:** satisfy Sonar on gallery height key hash ([3a6ce47](https://github.com/vtex/faststore/commit/3a6ce47485c26be75d6d76906df3af64c9e34fd6))
- **core:** type scroll restore paint timer for DOM/Node setTimeout ([940c903](https://github.com/vtex/faststore/commit/940c90376f8d2eb77665e73a6fb0ea53c9786c8e))
- **core:** use replaceAll for infinite-scroll session key ([4f52048](https://github.com/vtex/faststore/commit/4f520482a9ba9661782fcf25a286b8f2e6c6b922))

## [4.5.1-dev.2](https://github.com/vtex/faststore/compare/v4.5.1-dev.1...v4.5.1-dev.2) (2026-08-04)

### Bug Fixes

- **api:** keep excludent productClusterIds as repeated path facets ([3103e86](https://github.com/vtex/faststore/commit/3103e8647764acd3c8eab5b6ccf64e65a8f00662))

## [4.5.1-dev.1](https://github.com/vtex/faststore/compare/v4.5.1-dev.0...v4.5.1-dev.1) (2026-08-04)

**Note:** Version bump only for package faststore

## [4.5.1-dev.0](https://github.com/vtex/faststore/compare/v4.5.0...v4.5.1-dev.0) (2026-08-03)

**Note:** Version bump only for package faststore

# [4.5.0](https://github.com/vtex/faststore/compare/v4.5.0-dev.7...v4.5.0) (2026-08-03)

**Note:** Version bump only for package faststore

# [4.5.0-dev.7](https://github.com/vtex/faststore/compare/v4.5.0-dev.6...v4.5.0-dev.7) (2026-08-03)

### Features

- CMS-driven custom My Account pages ([#3411](https://github.com/vtex/faststore/issues/3411)) ([e38b278](https://github.com/vtex/faststore/commit/e38b2780bb7386a8ef7b83a9e3de5956bf6de50e))

# [4.5.0-dev.6](https://github.com/vtex/faststore/compare/v4.5.0-dev.5...v4.5.0-dev.6) (2026-07-28)

### Bug Fixes

- prevent My Account 500s from empty session profile and missing CMS content ([#3417](https://github.com/vtex/faststore/issues/3417)) ([2c2a18f](https://github.com/vtex/faststore/commit/2c2a18fe8f4127404d6634933cce778a64169c08))

# [4.5.0-dev.5](https://github.com/vtex/faststore/compare/v4.5.0-dev.4...v4.5.0-dev.5) (2026-07-27)

### Features

- forward Pricing Fallback price token to Checkout ([#3415](https://github.com/vtex/faststore/issues/3415)) ([bc6cda2](https://github.com/vtex/faststore/commit/bc6cda2cdaed0540896ca7202246ad2d3dcd5766))

# [4.5.0-dev.4](https://github.com/vtex/faststore/compare/v4.5.0-dev.3...v4.5.0-dev.4) (2026-07-24)

### Features

- **core:** localized product URLs, breadcrumbs PDP and PLPs ([#3402](https://github.com/vtex/faststore/issues/3402)) ([3c6b6ef](https://github.com/vtex/faststore/commit/3c6b6ef29ef902ccae3ff784297b24e6c6bc7802)), closes [#3352](https://github.com/vtex/faststore/issues/3352) [#3401](https://github.com/vtex/faststore/issues/3401)

# [4.5.0-dev.3](https://github.com/vtex/faststore/compare/v4.5.0-dev.2...v4.5.0-dev.3) (2026-07-22)

### Features

- **core:** move recommendation session start to CMS Global Section ([8589056](https://github.com/vtex/faststore/commit/8589056046b38e5dbc4f8ce6dcc669f7a15a4d85))

# [4.5.0-dev.2](https://github.com/vtex/faststore/compare/v4.5.0-dev.1...v4.5.0-dev.2) (2026-07-20)

### Features

- copy fonts and nested assets from public/ to build ([#3412](https://github.com/vtex/faststore/issues/3412)) ([ce07376](https://github.com/vtex/faststore/commit/ce07376a7c6aabf727746afdd7e486e3e6afaa76)), closes [#3332](https://github.com/vtex/faststore/issues/3332)

# [4.5.0-dev.1](https://github.com/vtex/faststore/compare/v4.5.0-dev.0...v4.5.0-dev.1) (2026-07-14)

### Bug Fixes

- **api:** add storeCookies option to fetchAPI for recommendations ([0e36d26](https://github.com/vtex/faststore/commit/0e36d269600ad9d219e8899ad58d6f81b18f70cb))
- **api:** close Recommendation describe block after merge with dev ([1852ee1](https://github.com/vtex/faststore/commit/1852ee1c70602898b482439f247e018d21956a3e))
- **api:** expose recommendation and personalization operations ([961112a](https://github.com/vtex/faststore/commit/961112a8d2434e9fa961e7b6805850d90165d70f))
- **api:** use private cache scope for personalized recommendations ([ec92aef](https://github.com/vtex/faststore/commit/ec92aefc06d173b179478e6a94a68651d8c4e7cc))
- **core:** add recommendation/personalization GraphQL typeDefs ([5f3999b](https://github.com/vtex/faststore/commit/5f3999b3a045d6ca7218cbc9eadee00021a4231c))
- **core:** harden RecommendationShelf per review feedback ([e369181](https://github.com/vtex/faststore/commit/e36918123b0f14d9628d7ef71238ac714c99a7fc))
- **ProductGallery:** cast context to PLPContext for SEO title retrieval ([c674edc](https://github.com/vtex/faststore/commit/c674edccb35fabd5432185a4b85290f8447b7af6))

### Features

- **api, core:** implement server-side validation for recommendations and enable opt-in feature ([060d0a0](https://github.com/vtex/faststore/commit/060d0a0a151faa8494d1ae781f18baad5505b149))
- **api, core:** return StoreProduct from recommendations for consistent interface ([1ea6afa](https://github.com/vtex/faststore/commit/1ea6afacbc768c1395b3b46e735bac6a0cfed73e))
- **core:** add RecommendationShelf component for personalized product recommendations ([3214947](https://github.com/vtex/faststore/commit/3214947496a3ca28282af1b8a07a8f0567be01e2))
- **core:** add RecommendationShelf section with personalization tracking ([6c426a8](https://github.com/vtex/faststore/commit/6c426a80bd3e408eac989b00d4b10d45b74f2967))
- **core:** B2B contract switcher in the account drawer ([#3390](https://github.com/vtex/faststore/issues/3390)) ([380396a](https://github.com/vtex/faststore/commit/380396a7405f7bdb472b1219274d84807c61e153)), closes [#3354](https://github.com/vtex/faststore/issues/3354)
- **core:** enhance RecommendationShelf with configurable items context and carousel settings ([7b4e2d2](https://github.com/vtex/faststore/commit/7b4e2d274d8acb07b74f6a29c34e806eff311b1f))
- **core:** make RecommendationShelf carousel and product card configurable ([402816e](https://github.com/vtex/faststore/commit/402816e0dda8529ea081d9dcfd50626d889bf4f8))

# [4.5.0-dev.0](https://github.com/vtex/faststore/compare/v4.4.1-dev.0...v4.5.0-dev.0) (2026-07-03)

### Features

- quotes list for B2B buyers in My Account ([#3388](https://github.com/vtex/faststore/issues/3388)) ([a6c1ef6](https://github.com/vtex/faststore/commit/a6c1ef6d13abd1f525832ccca9a5c0dc6a4b1a87)), closes [faststore-dx-spec-kit#13](https://github.com/faststore-dx-spec-kit/issues/13)

## [4.4.1-dev.0](https://github.com/vtex/faststore/compare/v4.4.0...v4.4.1-dev.0) (2026-07-02)

**Note:** Version bump only for package faststore

# [4.4.0](https://github.com/vtex/faststore/compare/v4.4.0-dev.6...v4.4.0) (2026-07-02)

**Note:** Version bump only for package faststore

# [4.4.0-dev.6](https://github.com/vtex/faststore/compare/v4.4.0-dev.5...v4.4.0-dev.6) (2026-07-02)

# [4.3.0](https://github.com/vtex/faststore/compare/v4.3.0-dev.8...v4.3.0) (2026-06-17)

### Bug Fixes

- fix vtex message ([e9b2105](https://github.com/vtex/faststore/commit/e9b21055dba0ba24658eda1511056ef29d6b0274))

### Features

- graduate v4.3.0 ([#3396](https://github.com/vtex/faststore/issues/3396)) ([b489766](https://github.com/vtex/faststore/commit/b4897664c7826dcd59bfde7c3599c93259d4d11f)), closes [#3276](https://github.com/vtex/faststore/issues/3276) [#3334](https://github.com/vtex/faststore/issues/3334) [#3386](https://github.com/vtex/faststore/issues/3386) [#3380](https://github.com/vtex/faststore/issues/3380) [#3394](https://github.com/vtex/faststore/issues/3394) [#3395](https://github.com/vtex/faststore/issues/3395) [#3381](https://github.com/vtex/faststore/issues/3381) [#3379](https://github.com/vtex/faststore/issues/3379) [#3375](https://github.com/vtex/faststore/issues/3375)

# [4.4.0-dev.5](https://github.com/vtex/faststore/compare/v4.4.0-dev.4...v4.4.0-dev.5) (2026-07-01)

### Features

- make cms-sync content-source aware (CMS + CP) ([#3406](https://github.com/vtex/faststore/issues/3406)) ([8e4e4ca](https://github.com/vtex/faststore/commit/8e4e4cab61b6e6fec05b8ae014e4ed2298028b92)), closes [#5c1a1](https://github.com/vtex/faststore/issues/5c1a1) [#ff6b6](https://github.com/vtex/faststore/issues/ff6b6) [#3a0d0](https://github.com/vtex/faststore/issues/3a0d0) [#ff6b6](https://github.com/vtex/faststore/issues/ff6b6) [#10391](https://github.com/vtex/faststore/issues/10391) [#3ddc84](https://github.com/vtex/faststore/issues/3ddc84) [#1](https://github.com/vtex/faststore/issues/1) [#14](https://github.com/vtex/faststore/issues/14) [#15](https://github.com/vtex/faststore/issues/15) [#18](https://github.com/vtex/faststore/issues/18)

# [4.4.0-dev.4](https://github.com/vtex/faststore/compare/v4.4.0-dev.3...v4.4.0-dev.4) (2026-06-30)

### Features

- add i18n support for /pvt/account navigation ([#3400](https://github.com/vtex/faststore/issues/3400)) ([695dd0e](https://github.com/vtex/faststore/commit/695dd0ee8e06e32ad76c23925c5e095740430f0f))

# [4.4.0-dev.3](https://github.com/vtex/faststore/compare/v4.4.0-dev.2...v4.4.0-dev.3) (2026-06-29)

### Bug Fixes

- sync IS locale with URL and selectedFacets on navigation ([#3405](https://github.com/vtex/faststore/issues/3405)) ([90d644d](https://github.com/vtex/faststore/commit/90d644dcf7a232c3f2bea316658580b10108b502)), closes [#3401](https://github.com/vtex/faststore/issues/3401) [#3401](https://github.com/vtex/faststore/issues/3401)

# [4.4.0-dev.2](https://github.com/vtex/faststore/compare/v4.4.0-dev.1...v4.4.0-dev.2) (2026-06-25)

### Bug Fixes

- **core:** version authenticator routes to v1 ([#3398](https://github.com/vtex/faststore/issues/3398)) ([a4ac863](https://github.com/vtex/faststore/commit/a4ac863f35b91d3980f9a11e81aede3606f92efe))

# [4.4.0-dev.1](https://github.com/vtex/faststore/compare/v4.4.0-dev.0...v4.4.0-dev.1) (2026-06-24)

### Features

- my account cms ([#3354](https://github.com/vtex/faststore/issues/3354)) ([2400c45](https://github.com/vtex/faststore/commit/2400c4537e58d5f4093d8c10275443a0876f62f8))

# [4.4.0-dev.0](https://github.com/vtex/faststore/compare/v4.3.1-dev.0...v4.4.0-dev.0) (2026-06-19)

### Features

- **api:** Migrate to VTEX Intelligent Search V1 API ([#3385](https://github.com/vtex/faststore/issues/3385)) ([74e034a](https://github.com/vtex/faststore/commit/74e034aed44d97634ae4fcafbe3e48745b68fa65)), closes [#3376](https://github.com/vtex/faststore/issues/3376)

## [4.3.1-dev.0](https://github.com/vtex/faststore/compare/v4.3.0-dev.8...v4.3.1-dev.0) (2026-06-17)

**Note:** Version bump only for package faststore

# [4.3.0](https://github.com/vtex/faststore/compare/v4.2.0...v4.3.0) (2026-06-17)

### Bug Fixes

- fix vtex message ([e9b2105](https://github.com/vtex/faststore/commit/e9b21055dba0ba24658eda1511056ef29d6b0274))

### Features

- graduate v4.3.0 ([#3396](https://github.com/vtex/faststore/issues/3396)) ([b489766](https://github.com/vtex/faststore/commit/b4897664c7826dcd59bfde7c3599c93259d4d11f)), closes [#3276](https://github.com/vtex/faststore/issues/3276) [#3334](https://github.com/vtex/faststore/issues/3334) [#3386](https://github.com/vtex/faststore/issues/3386) [#3380](https://github.com/vtex/faststore/issues/3380) [#3394](https://github.com/vtex/faststore/issues/3394) [#3395](https://github.com/vtex/faststore/issues/3395) [#3381](https://github.com/vtex/faststore/issues/3381) [#3379](https://github.com/vtex/faststore/issues/3379) [#3375](https://github.com/vtex/faststore/issues/3375)

# [4.3.0-dev.8](https://github.com/vtex/faststore/compare/v4.3.0-dev.7...v4.3.0-dev.8) (2026-06-17)

### Features

- Password Protection (v4) ([#3276](https://github.com/vtex/faststore/issues/3276)) ([575f162](https://github.com/vtex/faststore/commit/575f162f6ec6fda9d3134ab61f673a897dcc2f56))

# [4.3.0-dev.7](https://github.com/vtex/faststore/compare/v4.3.0-dev.6...v4.3.0-dev.7) (2026-06-17)

### Bug Fixes

- **core:** use authenticator route for setpassword ([#3380](https://github.com/vtex/faststore/issues/3380)) ([a155269](https://github.com/vtex/faststore/commit/a155269678d8a0584a98008b1384bf146f6da1cb))

# [4.3.0-dev.6](https://github.com/vtex/faststore/compare/v4.3.0-dev.5...v4.3.0-dev.6) (2026-06-17)

### Bug Fixes

- migrate partytown [@builder](https://github.com/builder).io → [@qwik](https://github.com/qwik).dev@0.14.0 ([#3394](https://github.com/vtex/faststore/issues/3394)) ([dae8d3b](https://github.com/vtex/faststore/commit/dae8d3b3823b3e1758af9547cae9bd92cef480b9))

# [4.3.0-dev.5](https://github.com/vtex/faststore/compare/v4.3.0-dev.4...v4.3.0-dev.5) (2026-06-16)

### Bug Fixes

- **api:** use account-scoped cookie in orderEntry headers ([#3395](https://github.com/vtex/faststore/issues/3395)) ([d5f6ac3](https://github.com/vtex/faststore/commit/d5f6ac3d49e70fd0c11475baecae72d3bffbef84)), closes [#3334](https://github.com/vtex/faststore/issues/3334) [#3381](https://github.com/vtex/faststore/issues/3381) [#3381](https://github.com/vtex/faststore/issues/3381)
- forward auth token only via account-scoped cookie ([#3381](https://github.com/vtex/faststore/issues/3381)) ([37d6fcf](https://github.com/vtex/faststore/commit/37d6fcf3937d0ff9b45a7ca08ab6935cfadd7542))

# [4.3.0-dev.4](https://github.com/vtex/faststore/compare/v4.3.0-dev.3...v4.3.0-dev.4) (2026-06-15)

**Note:** Version bump only for package faststore

# [4.3.0-dev.3](https://github.com/vtex/faststore/compare/v4.3.0-dev.2...v4.3.0-dev.3) (2026-06-15)

### Features

- adding sitemap to cms LP content-type ([#3386](https://github.com/vtex/faststore/issues/3386)) ([7e81ae2](https://github.com/vtex/faststore/commit/7e81ae208003ece9e19d50ab24489f9c27773929))

# [4.3.0-dev.2](https://github.com/vtex/faststore/compare/v4.3.0-dev.1...v4.3.0-dev.2) (2026-06-10)

### Features

- file upload via Order Entry Service (OES) ([#3334](https://github.com/vtex/faststore/issues/3334)) ([03edc11](https://github.com/vtex/faststore/commit/03edc11952ea61fda4127aae4812b204845ecdb1))

# [4.3.0-dev.1](https://github.com/vtex/faststore/compare/v4.3.0-dev.0...v4.3.0-dev.1) (2026-06-08)

### Bug Fixes

- **core:** propagate upstream error status instead of always 500 ([#3379](https://github.com/vtex/faststore/issues/3379)) ([c03d3df](https://github.com/vtex/faststore/commit/c03d3dff7f5920e834a318417a4a02cc653453cf))

# [4.3.0-dev.0](https://github.com/vtex/faststore/compare/v4.2.0...v4.3.0-dev.0) (2026-06-01)

# [4.2.0-dev.5](https://github.com/vtex/faststore/compare/v4.2.0-dev.4...v4.2.0-dev.5) (2026-06-01)

# [4.2.0-dev.4](https://github.com/vtex/faststore/compare/v4.2.0-dev.3...v4.2.0-dev.4) (2026-06-01)

### Bug Fixes

- **core:** fix locale validation for disabled localization and pvt routes ([#3358](https://github.com/vtex/faststore/issues/3358)) ([ec7d876](https://github.com/vtex/faststore/commit/ec7d876855fd0f4d2a42231351a61b7a9e675439))
- preview pnpm pack ([#3367](https://github.com/vtex/faststore/issues/3367)) ([186579c](https://github.com/vtex/faststore/commit/186579c4cca44e4d21c25068f075c0fbb6a56d96))

# [4.2.0-dev.3](https://github.com/vtex/faststore/compare/v4.2.0-dev.2...v4.2.0-dev.3) (2026-06-01)

### Performance Improvements

- **core:** SSR ProductGallery and fix CLS on screen-size detection (VTE-9) ([#3349](https://github.com/vtex/faststore/issues/3349)) ([e70a23b](https://github.com/vtex/faststore/commit/e70a23b54504be4cddc97e76c89cf4323fe0941e)), closes [#3345](https://github.com/vtex/faststore/issues/3345)

# [4.2.0-dev.2](https://github.com/vtex/faststore/compare/v4.2.0-dev.1...v4.2.0-dev.2) (2026-06-01)

### Bug Fixes

- strip packageManager from generated .faststore/package.json ([#3335](https://github.com/vtex/faststore/issues/3335)) ([5a2b793](https://github.com/vtex/faststore/commit/5a2b793c4b12f986c72e801fb03809b568a99344))

# [4.2.0-dev.1](https://github.com/vtex/faststore/compare/v4.2.0-dev.0...v4.2.0-dev.1) (2026-06-01)

### Bug Fixes

- createNextJSPages throwing preventing copy of store discovery-co… ([#3356](https://github.com/vtex/faststore/issues/3356)) ([cf318ab](https://github.com/vtex/faststore/commit/cf318abfecf4c6497d40bfe58203acc90b199696))
- image loader error at vtex assets ([#3363](https://github.com/vtex/faststore/issues/3363)) ([36105d0](https://github.com/vtex/faststore/commit/36105d0d7529d9076aa606329b3ac7b03e354b0b))
- **sdk:** refetch first PLP page from page-load time, not build time ([#3350](https://github.com/vtex/faststore/issues/3350)) ([608c636](https://github.com/vtex/faststore/commit/608c6362eff32b0dabba9d51ada09e50699cd3c8)), closes [#3345](https://github.com/vtex/faststore/issues/3345)
- **ui:** replace mixed-support flex alignment values with flex-prefixed equivalents ([#3357](https://github.com/vtex/faststore/issues/3357)) ([3d5a42b](https://github.com/vtex/faststore/commit/3d5a42bebe02e9c09e61681ebda6961e9ffa7fd7))

### Performance Improvements

- **plp:** prioritize first product image as LCP (VTE-14) ([#3348](https://github.com/vtex/faststore/issues/3348)) ([8fd5dea](https://github.com/vtex/faststore/commit/8fd5dea1832d2e6113cdaa2c86f4dcf12189cafc)), closes [#3345](https://github.com/vtex/faststore/issues/3345)

# [4.2.0-dev.0](https://github.com/vtex/faststore/compare/v4.1.2...v4.2.0-dev.0) (2026-06-01)

### Features

- paginate listEntries with scroll ([#3282](https://github.com/vtex/faststore/issues/3282)) ([2e43804](https://github.com/vtex/faststore/commit/2e43804b7c3ee336eee5a19f1a11d3185c01102d))

## [4.1.2-dev.8](https://github.com/vtex/faststore/compare/v4.1.2-dev.7...v4.1.2-dev.8) (2026-05-28)

### Bug Fixes

- localization race condition ([#3281](https://github.com/vtex/faststore/issues/3281)) ([75cb5df](https://github.com/vtex/faststore/commit/75cb5dfb5dd3dcd58a15273df5f4c20bb1c8987b)), closes [#3111](https://github.com/vtex/faststore/issues/3111) [#3111](https://github.com/vtex/faststore/issues/3111)

## [4.1.2-dev.7](https://github.com/vtex/faststore/compare/v4.1.2-dev.6...v4.1.2-dev.7) (2026-05-28)

## [4.1.2-dev.6](https://github.com/vtex/faststore/compare/v4.1.2-dev.5...v4.1.2-dev.6) (2026-05-27)

## [4.1.2-dev.5](https://github.com/vtex/faststore/compare/v4.1.2-dev.4...v4.1.2-dev.5) (2026-05-21)

### Bug Fixes

- url resolution in windows ([#3337](https://github.com/vtex/faststore/issues/3337)) ([2476091](https://github.com/vtex/faststore/commit/24760916bdcfc73c7d4ef7f92829976d4f1f97d6))

## [4.1.2-dev.4](https://github.com/vtex/faststore/compare/v4.1.2-dev.3...v4.1.2-dev.4) (2026-05-20)

## [4.1.2-dev.3](https://github.com/vtex/faststore/compare/v4.1.2-dev.2...v4.1.2-dev.3) (2026-05-20)

### Bug Fixes

- **ui:** use dvh for SlideOver height on mobile - SFS-3108 ([#3333](https://github.com/vtex/faststore/issues/3333)) ([487fe0f](https://github.com/vtex/faststore/commit/487fe0f452b25a3653091aeec647ab7f6bcb97d4))

## [4.1.2-dev.2](https://github.com/vtex/faststore/compare/v4.1.2-dev.1...v4.1.2-dev.2) (2026-05-19)

### Bug Fixes

- generate plugin themes with Sass [@use](https://github.com/use) instead of [@import](https://github.com/import) ([#3283](https://github.com/vtex/faststore/issues/3283)) ([22c0e74](https://github.com/vtex/faststore/commit/22c0e74d7d3b3714a5e9b6917d7cc60aa36eeb69))

## [4.1.2-dev.1](https://github.com/vtex/faststore/compare/v4.1.1...v4.1.2-dev.1) (2026-05-19)

### Bug Fixes

- bump version ([4fbfa64](https://github.com/vtex/faststore/commit/4fbfa649afc57218dbf8020abc7333c05b0b034f))
- bypass refresh-token flow on localhost in 403 page and useRefreshToken hook ([#3325](https://github.com/vtex/faststore/issues/3325)) ([d48571a](https://github.com/vtex/faststore/commit/d48571a15176497b019bae1462617c3159459421)), closes [#3285](https://github.com/vtex/faststore/issues/3285) [#3285](https://github.com/vtex/faststore/issues/3285)

## [4.1.1-dev.1](https://github.com/vtex/faststore/compare/v4.1.0-dev.11...v4.1.1-dev.1) (2026-05-15)

# [4.1.0-dev.11](https://github.com/vtex/faststore/compare/v4.1.0-dev.10...v4.1.0-dev.11) (2026-05-15)

# [4.1.0-dev.10](https://github.com/vtex/faststore/compare/v4.1.0-dev.8...v4.1.0-dev.10) (2026-05-15)

# [4.1.0-dev.8](https://github.com/vtex/faststore/compare/v4.1.0-dev.7...v4.1.0-dev.8) (2026-05-15)

# [4.1.0-dev.7](https://github.com/vtex/faststore/compare/v4.1.0-dev.6...v4.1.0-dev.7) (2026-05-15)

# [4.1.0-dev.6](https://github.com/vtex/faststore/compare/v4.1.0-dev.5...v4.1.0-dev.6) (2026-05-14)

# [4.1.0-dev.5](https://github.com/vtex/faststore/compare/v4.1.0-dev.4...v4.1.0-dev.5) (2026-05-14)

### Bug Fixes

- region slider section render ([#3318](https://github.com/vtex/faststore/issues/3318)) ([f9f5e0d](https://github.com/vtex/faststore/commit/f9f5e0dbd6c3e92b24a3fb1e21a95bfb1c6744f1)), closes [#2887](https://github.com/vtex/faststore/issues/2887) [#2961](https://github.com/vtex/faststore/issues/2961) [#3071](https://github.com/vtex/faststore/issues/3071)

# [4.1.0-dev.4](https://github.com/vtex/faststore/compare/v4.1.0-dev.3...v4.1.0-dev.4) (2026-05-13)

# [4.1.0-dev.3](https://github.com/vtex/faststore/compare/v4.1.0-dev.2...v4.1.0-dev.3) (2026-05-13)

# [4.1.0-dev.2](https://github.com/vtex/faststore/compare/v4.1.0...v4.1.0-dev.2) (2026-05-12)

### Bug Fixes

- allow_all_components for CMS ([#3312](https://github.com/vtex/faststore/issues/3312)) ([eadeaa3](https://github.com/vtex/faststore/commit/eadeaa36782b40be0fe7fb16604f7a5bc3da2b79))

# [4.1.0-dev.1](https://github.com/vtex/faststore/compare/v4.1.0-dev.0...v4.1.0-dev.1) (2026-05-11)

### Bug Fixes

- PLP "Load more products" overwriting list instead of appending ([#3308](https://github.com/vtex/faststore/issues/3308)) ([e8b08cd](https://github.com/vtex/faststore/commit/e8b08cd4ffeeac63e1ede45ddd75043ef7695813)), closes [#3015](https://github.com/vtex/faststore/issues/3015) [#3015](https://github.com/vtex/faststore/issues/3015)

# [4.1.0-dev.0](https://github.com/vtex/faststore/compare/v4.0.1-dev.2...v4.1.0-dev.0) (2026-05-11)

### Features

- user details adjusts - SFS-2950 ([#3306](https://github.com/vtex/faststore/issues/3306)) ([70b018d](https://github.com/vtex/faststore/commit/70b018d713b4ec0da698bfc377332b356d9fa9cd))

## [4.0.1-dev.2](https://github.com/vtex/faststore/compare/v4.0.1-dev.1...v4.0.1-dev.2) (2026-05-11)

### Bug Fixes

- localization selector stale and reset selection for unsaved changes ([#3301](https://github.com/vtex/faststore/issues/3301)) ([023e52e](https://github.com/vtex/faststore/commit/023e52ee3c8798cfc9f12ed98e99e8efacb1f1d5))

## [4.0.1-dev.1](https://github.com/vtex/faststore/compare/v4.0.1-dev.0...v4.0.1-dev.1) (2026-05-07)

### Bug Fixes

- updates schemas vtex.faststore ([#3304](https://github.com/vtex/faststore/issues/3304)) ([490175f](https://github.com/vtex/faststore/commit/490175ff4cc06bf23f7957bbd1f9d002baa13e43))

## [4.0.1-dev.0](https://github.com/vtex/faststore/compare/v4.0.0...v4.0.1-dev.0) (2026-05-07)

# [4.0.0-dev.4](https://github.com/vtex/faststore/compare/v4.0.0-dev.3...v4.0.0-dev.4) (2026-05-07)

### Bug Fixes

- add repository field to diagnostics package for OIDC provenance ([d1e40ab](https://github.com/vtex/faststore/commit/d1e40abe742b469a68b3d178c10ef56e5184ec29))

# [4.0.0-dev.3](https://github.com/vtex/faststore/compare/v4.0.0-dev.2...v4.0.0-dev.3) (2026-05-07)

### Features

- trigger v4 publish ([bb56584](https://github.com/vtex/faststore/commit/bb565843917c61b4d0023c2ad21284a1aa95c55e))

# [4.0.0-dev.2](https://github.com/vtex/faststore/compare/v4.0.0-dev.1...v4.0.0-dev.2) (2026-05-07)

### Features

- force publish all packages on v4 release ([0e765a3](https://github.com/vtex/faststore/commit/0e765a335da1f16b4a4298caa31900286f324ea8))

# [4.0.0-dev.1](https://github.com/vtex/faststore/compare/v4.0.0-dev.0...v4.0.0-dev.1) (2026-05-07)

### Features

- trigger v4 publish ([7f725d2](https://github.com/vtex/faststore/commit/7f725d27575619a2475b273b779906a745166f84))

# [4.0.0-dev.0](https://github.com/vtex/faststore/compare/v3.99.0...v4.0.0-dev.0) (2026-05-07)

### Bug Fixes

- release command ([e912b5e](https://github.com/vtex/faststore/commit/e912b5e10cf61e65f24502fb077c06799009da61))

# [3.99.0-dev.8](https://github.com/vtex/faststore/compare/v3.99.0-dev.7...v3.99.0-dev.8) (2026-05-04)

# [3.99.0-dev.7](https://github.com/vtex/faststore/compare/v3.99.0-dev.6...v3.99.0-dev.7) (2026-05-04)

### Bug Fixes

- fixing preview tag style ([#3058](https://github.com/vtex/faststore/issues/3058)) ([5084915](https://github.com/vtex/faststore/commit/50849157ac190a57fc151e7e6c9cb10df487bff6))

# [3.99.0-dev.6](https://github.com/vtex/faststore/compare/v3.99.0-dev.4...v3.99.0-dev.6) (2026-05-04)

### Bug Fixes

- Base CMS schema ([#3290](https://github.com/vtex/faststore/issues/3290)) ([3455e89](https://github.com/vtex/faststore/commit/3455e89295e197f4bd18c0b5f84d7b01c0d67009))
- Enhance session validation logic to skip token refresh in local … ([#3285](https://github.com/vtex/faststore/issues/3285)) ([41a330a](https://github.com/vtex/faststore/commit/41a330a9704a29369141e6e78b1f6d01e5a2e1a5))

# [3.99.0-dev.4](https://github.com/vtex/faststore/compare/v3.99.0-dev.3...v3.99.0-dev.4) (2026-04-28)

### Bug Fixes

- Refactor token refresh logic in GraphQL API handler - SFS-3104 ([#3263](https://github.com/vtex/faststore/issues/3263)) ([695ab6a](https://github.com/vtex/faststore/commit/695ab6a9413eb53ef457cfc890c74e41c29c1ab8))

# [3.99.0-dev.3](https://github.com/vtex/faststore/compare/v3.99.0-dev.2...v3.99.0-dev.3) (2026-04-23)

### Features

- add isGift field to StoreOffer type and resolvers - SFS-3040 ([#3220](https://github.com/vtex/faststore/issues/3220)) ([e10fc92](https://github.com/vtex/faststore/commit/e10fc92633a5296a5b03286028d31d9c280561c6))
- Enhance session management with logout - SFS-3105 ([#3268](https://github.com/vtex/faststore/issues/3268)) ([9468e32](https://github.com/vtex/faststore/commit/9468e32a3531ca3c91c7f82a34ac1c750c6a26ef))

# [3.99.0-dev.2](https://github.com/vtex/faststore/compare/v3.99.0-dev.1...v3.99.0-dev.2) (2026-04-21)

### Bug Fixes

- Prevent IDB writes before store hydration completes - SFS-3121 ([#3267](https://github.com/vtex/faststore/issues/3267)) ([0b23e52](https://github.com/vtex/faststore/commit/0b23e526db23d7338c0eda75b673bb0bea05eef3))

# [3.99.0-dev.1](https://github.com/vtex/faststore/compare/v3.98.4...v3.99.0-dev.1) (2026-04-15)

# [3.99.0-dev.0](https://github.com/vtex/faststore/compare/v3.98.1-dev.0...v3.99.0-dev.0) (2026-03-31)

### Features

- Add Shopping Assistant component to FastStore schema ([#3255](https://github.com/vtex/faststore/issues/3255)) ([f4c8ea6](https://github.com/vtex/faststore/commit/f4c8ea65da468d26acac198071882523a8a57215))

## [3.98.1-dev.0](https://github.com/vtex/faststore/compare/v3.98.0...v3.98.1-dev.0) (2026-03-27)

# [3.98.0-dev.10](https://github.com/vtex/faststore/compare/v3.98.0-dev.9...v3.98.0-dev.10) (2026-03-27)

# [3.98.0-dev.9](https://github.com/vtex/faststore/compare/v3.98.0-dev.8...v3.98.0-dev.9) (2026-03-27)

# [3.98.0-dev.8](https://github.com/vtex/faststore/compare/v3.98.0-dev.7...v3.98.0-dev.8) (2026-03-27)

### Features

- Add Quick Order Full Feature ([#3197](https://github.com/vtex/faststore/issues/3197)) ([f5518d7](https://github.com/vtex/faststore/commit/f5518d7f205dccad99b6ea0a127fd09cf77d1edb))

# [3.98.0-dev.7](https://github.com/vtex/faststore/compare/v3.98.0-dev.6...v3.98.0-dev.7) (2026-03-26)

# [3.98.0-dev.6](https://github.com/vtex/faststore/compare/v3.98.0-dev.5...v3.98.0-dev.6) (2026-03-24)

### Bug Fixes

- enhance cache key management in useQuery ([#3230](https://github.com/vtex/faststore/issues/3230)) ([3f28502](https://github.com/vtex/faststore/commit/3f28502a8d381e476728661ea1150d0777ba87d1))

# [3.98.0-dev.5](https://github.com/vtex/faststore/compare/v3.98.0-dev.4...v3.98.0-dev.5) (2026-03-24)

### Features

- Add Webchat component and script integration + hCMS - SFS-3084 ([#3242](https://github.com/vtex/faststore/issues/3242)) ([04c3fbb](https://github.com/vtex/faststore/commit/04c3fbb91d028c5828998388105d327913194074))

# [3.98.0-dev.4](https://github.com/vtex/faststore/compare/v3.98.0-dev.3...v3.98.0-dev.4) (2026-03-23)

### Features

- Add transpilePackages to configuration for Next.js - SFS-3100 ([#3244](https://github.com/vtex/faststore/issues/3244)) ([9399323](https://github.com/vtex/faststore/commit/939932383b3abf78a6c7184ac9f428d90d49401b))

# [3.98.0-dev.3](https://github.com/vtex/faststore/compare/v3.98.0-dev.2...v3.98.0-dev.3) (2026-03-12)

### Features

- Add ActivityFlow data parameters with search-related information ([#3105](https://github.com/vtex/faststore/issues/3105)) ([8f69ff8](https://github.com/vtex/faststore/commit/8f69ff855c31abedba66071132240c53a93ab56d))

# [3.98.0-dev.2](https://github.com/vtex/faststore/compare/v3.98.0-dev.1...v3.98.0-dev.2) (2026-03-03)

### Features

- add mpn (manufacturer code) to product's structured data ([#3234](https://github.com/vtex/faststore/issues/3234)) ([9597e39](https://github.com/vtex/faststore/commit/9597e39a8d63a651b815f90fe3b1ea5409258ca3))

# [3.98.0-dev.1](https://github.com/vtex/faststore/compare/v3.98.0-dev.0...v3.98.0-dev.1) (2026-02-24)

### Features

- update coderabbit instructions ([#3226](https://github.com/vtex/faststore/issues/3226)) ([dfbc58a](https://github.com/vtex/faststore/commit/dfbc58a042443a3018c0b3df569f42918e3e349d))

# [3.98.0-dev.0](https://github.com/vtex/faststore/compare/v3.97.1...v3.98.0-dev.0) (2026-02-24)

# [3.97.0-dev.6](https://github.com/vtex/faststore/compare/v3.97.0-dev.5...v3.97.0-dev.6) (2026-02-19)

### Bug Fixes

- remove query string from preview cookie path ([#3213](https://github.com/vtex/faststore/issues/3213)) ([bc60a59](https://github.com/vtex/faststore/commit/bc60a5968d48f03e0fe52060b19dc8b48f6582f0))

# [3.97.0-dev.5](https://github.com/vtex/faststore/compare/v3.97.0-dev.4...v3.97.0-dev.5) (2026-02-19)

# [3.97.0-dev.4](https://github.com/vtex/faststore/compare/v3.97.0-dev.3...v3.97.0-dev.4) (2026-02-10)

### Bug Fixes

- scripts improvements - update RC url + Partytown loading + logs + fix bugs. ([#3198](https://github.com/vtex/faststore/issues/3198)) ([9a35b63](https://github.com/vtex/faststore/commit/9a35b63a91bc5cd53de553c053ceeed8bb983184))

# [3.97.0-dev.3](https://github.com/vtex/faststore/compare/v3.97.0-dev.2...v3.97.0-dev.3) (2026-02-06)

### Features

- add budget to order details ([#3130](https://github.com/vtex/faststore/issues/3130)) ([f109b02](https://github.com/vtex/faststore/commit/f109b0271542aef02810d2996f00e075a9b9bde6))

# [3.97.0-dev.2](https://github.com/vtex/faststore/compare/v3.97.0...v3.97.0-dev.2) (2026-02-06)

### Features

- reorder feature ([#3153](https://github.com/vtex/faststore/issues/3153)) ([d0fdeec](https://github.com/vtex/faststore/commit/d0fdeec77cd94e16f1b79dcc927487320983ba0e))

# [3.97.0-dev.1](https://github.com/vtex/faststore/compare/v3.96.5...v3.97.0-dev.1) (2026-02-03)

# [3.97.0-dev.0](https://github.com/vtex/faststore/compare/v3.96.4...v3.97.0-dev.0) (2026-01-27)

### Features

- Enable fraction digit formatting for SEO's `product:price:amount` meta tag ([#3179](https://github.com/vtex/faststore/issues/3179)) ([d6e6252](https://github.com/vtex/faststore/commit/d6e6252eb578d782505b8e505ee48cd9fd1526e3))

## [3.96.4-dev.0](https://github.com/vtex/faststore/compare/v3.96.3...v3.96.4-dev.0) (2026-01-21)

# [3.96.0-dev.22](https://github.com/vtex/faststore/compare/v3.96.2...v3.96.0-dev.22) (2026-01-21)

### Bug Fixes

- Clear cart (get new orderForm) if there is no checkout cookie present ([#3178](https://github.com/vtex/faststore/issues/3178)) ([f3f69bc](https://github.com/vtex/faststore/commit/f3f69bca1c54f2859ad4c3ac9a52563a0e8c2571))

# [3.96.0-dev.21](https://github.com/vtex/faststore/compare/v3.96.0-dev.20...v3.96.0-dev.21) (2026-01-08)

### Bug Fixes

- Prevent Partytown cross-origin errors in iframe environments ([#3155](https://github.com/vtex/faststore/issues/3155)) ([997252e](https://github.com/vtex/faststore/commit/997252e9a18807f4c26c350197d4f2d139de58f8))

# [3.96.0-dev.20](https://github.com/vtex/faststore/compare/v3.96.0-dev.19...v3.96.0-dev.20) (2026-01-08)

### Bug Fixes

- Add slug field to landing page schema - CROC-185 ([#3166](https://github.com/vtex/faststore/issues/3166)) ([41b9878](https://github.com/vtex/faststore/commit/41b987825ee5ebb7d311eef33e2ca65034dc130d))

# [3.96.0-dev.19](https://github.com/vtex/faststore/compare/v3.96.0...v3.96.0-dev.19) (2026-01-08)

### Features

- logout clear storage ([#3163](https://github.com/vtex/faststore/issues/3163)) ([1fbacc3](https://github.com/vtex/faststore/commit/1fbacc3b3e32b4f83a2f56c1f97eb0f8ff843f61))

# [3.96.0-dev.18](https://github.com/vtex/faststore/compare/v3.96.0-dev.17...v3.96.0-dev.18) (2025-12-24)

# [3.96.0-dev.17](https://github.com/vtex/faststore/compare/v3.96.0-dev.16...v3.96.0-dev.17) (2025-12-23)

# [3.96.0-dev.16](https://github.com/vtex/faststore/compare/v3.96.0-dev.15...v3.96.0-dev.16) (2025-12-23)

# [3.96.0-dev.15](https://github.com/vtex/faststore/compare/v3.96.0-dev.14...v3.96.0-dev.15) (2025-12-23)

# [3.96.0-dev.14](https://github.com/vtex/faststore/compare/v3.96.0-dev.13...v3.96.0-dev.14) (2025-12-23)

# [3.96.0-dev.13](https://github.com/vtex/faststore/compare/v3.96.0-dev.12...v3.96.0-dev.13) (2025-12-23)

# [3.96.0-dev.12](https://github.com/vtex/faststore/compare/v3.96.0-dev.11...v3.96.0-dev.12) (2025-12-23)

# [3.96.0-dev.11](https://github.com/vtex/faststore/compare/v3.96.0-dev.10...v3.96.0-dev.11) (2025-12-23)

### Bug Fixes

- correct comment for platform specific config in discovery configuration ([0fea6fa](https://github.com/vtex/faststore/commit/0fea6faf812c0f0af3f139b6507b2f342264209c))

# [3.96.0-dev.10](https://github.com/vtex/faststore/compare/v3.96.0-dev.9...v3.96.0-dev.10) (2025-12-23)

# [3.96.0-dev.9](https://github.com/vtex/faststore/compare/v3.96.0-dev.8...v3.96.0-dev.9) (2025-12-23)

# [3.96.0-dev.8](https://github.com/vtex/faststore/compare/v3.96.0-dev.7...v3.96.0-dev.8) (2025-12-23)

# [3.96.0-dev.7](https://github.com/vtex/faststore/compare/v3.96.0-dev.6...v3.96.0-dev.7) (2025-12-23)

### Bug Fixes

- correct comment for platform specific API configuration in discovery config ([b03968c](https://github.com/vtex/faststore/commit/b03968c84cfb935b71ef64f575dcdf3e8f624b5a))

# [3.96.0-dev.6](https://github.com/vtex/faststore/compare/v3.96.0-dev.5...v3.96.0-dev.6) (2025-12-23)

# [3.96.0-dev.5](https://github.com/vtex/faststore/compare/v3.96.0-dev.4...v3.96.0-dev.5) (2025-12-23)

### Features

- Trigger build ([28b6ec0](https://github.com/vtex/faststore/commit/28b6ec0489080be0a3431ec2ead7bfce0da75a34))

# [3.96.0-dev.4](https://github.com/vtex/faststore/compare/v3.96.0-dev.3...v3.96.0-dev.4) (2025-12-23)

### Bug Fixes

- update release workflow to handle both main and dev branches ([#3160](https://github.com/vtex/faststore/issues/3160)) ([4247f92](https://github.com/vtex/faststore/commit/4247f9254f47056e726418290f4f019760a81935))

# [3.96.0-dev.3](https://github.com/vtex/faststore/compare/v3.96.0-dev.2...v3.96.0-dev.3) (2025-12-22)

# [3.96.0-dev.2](https://github.com/vtex/faststore/compare/v3.96.0-dev.1...v3.96.0-dev.2) (2025-12-18)

### Bug Fixes

- adds cache busting to bypass cache when logged in/out. ([#3152](https://github.com/vtex/faststore/issues/3152)) ([862ea50](https://github.com/vtex/faststore/commit/862ea50999214771c4fa38fa70db789b4de5e59b))

# [3.96.0-dev.1](https://github.com/vtex/faststore/compare/v3.96.0-dev.0...v3.96.0-dev.1) (2025-12-16)

# [3.96.0-dev.0](https://github.com/vtex/faststore/compare/v3.95.1-dev.0...v3.96.0-dev.0) (2025-12-10)

### Features

- adds `priceTags` as tax - SFS-2970 ([#3144](https://github.com/vtex/faststore/issues/3144)) ([d1b3869](https://github.com/vtex/faststore/commit/d1b38699f2955890be1759e1d6d6cf55e1c4dda9))

## [3.95.1-dev.0](https://github.com/vtex/faststore/compare/v3.95.0...v3.95.1-dev.0) (2025-12-02)

# [3.95.0-dev.3](https://github.com/vtex/faststore/compare/v3.95.0-dev.2...v3.95.0-dev.3) (2025-12-02)

# [3.95.0-dev.1](https://github.com/vtex/faststore/compare/v3.95.0-dev.0...v3.95.0-dev.1) (2025-12-01)

### Bug Fixes

- Consider the session when finding orderForm changes ([#3091](https://github.com/vtex/faststore/issues/3091)) ([b5cfb55](https://github.com/vtex/faststore/commit/b5cfb557ae7bfda912f93d14cb59369184d6eae3))
- remove unnecessary fields from session in validateSession function ([#3124](https://github.com/vtex/faststore/issues/3124)) ([d64b7f6](https://github.com/vtex/faststore/commit/d64b7f61cb62881f448fafad2ed4d4b3771cdeca))
- Update `validateCart` mutation tests ([#3132](https://github.com/vtex/faststore/issues/3132)) ([c8cbb52](https://github.com/vtex/faststore/commit/c8cbb5204562ddee126c63a576ba1f4d264092f7))
- Update search results description formatting ([#3128](https://github.com/vtex/faststore/issues/3128)) ([73fb9ed](https://github.com/vtex/faststore/commit/73fb9ed457a520766a13964e1abd9d8a24b537b3))

# [3.95.0-dev.0](https://github.com/vtex/faststore/compare/v3.94.1-dev.0...v3.95.0-dev.0) (2025-11-20)

### Features

- Add svg extension to public folder copy's allow list ([#3123](https://github.com/vtex/faststore/issues/3123)) ([15aca77](https://github.com/vtex/faststore/commit/15aca77a3e4309d780dcb2c1511618a450c61e0f))

## [3.94.1-dev.0](https://github.com/vtex/faststore/compare/v3.94.0...v3.94.1-dev.0) (2025-11-19)

# [3.93.0-dev.4](https://github.com/vtex/faststore/compare/v3.93.0-dev.3...v3.93.0-dev.4) (2025-11-17)

### Bug Fixes

- Show skeleton when product price is validating ([#3112](https://github.com/vtex/faststore/issues/3112)) ([1acb303](https://github.com/vtex/faststore/commit/1acb30334e2a17fe81630d3b0d631152c4e635f3))

# [3.93.0-dev.3](https://github.com/vtex/faststore/compare/v3.93.0-dev.2...v3.93.0-dev.3) (2025-11-17)

### Bug Fixes

- build among diff modules ([#3119](https://github.com/vtex/faststore/issues/3119)) ([fde7eb6](https://github.com/vtex/faststore/commit/fde7eb6635aaa4e0821fb8f6c6fb71f24604330b))
- validateSession error when isSessionReady is sent - SFS-2944 ([#3115](https://github.com/vtex/faststore/issues/3115)) ([951bfc3](https://github.com/vtex/faststore/commit/951bfc39b61a3cf1e05f915974310c716b37810e))

### Features

- add filter and selected tag for pending my approval ([#3001](https://github.com/vtex/faststore/issues/3001)) ([#3101](https://github.com/vtex/faststore/issues/3101)) ([c4c3f6a](https://github.com/vtex/faststore/commit/c4c3f6a9c4380a07502f4a42241cf541c52ef58f)), closes [vtex-sites/b2bfaststoredev.store#358](https://github.com/vtex-sites/b2bfaststoredev.store/issues/358)

# [3.93.0-dev.2](https://github.com/vtex/faststore/compare/v3.93.0-dev.1...v3.93.0-dev.2) (2025-11-07)

### Bug Fixes

- **ui:** update slider variable for border-radius in the mozilla rules ([#3077](https://github.com/vtex/faststore/issues/3077)) ([c491593](https://github.com/vtex/faststore/commit/c49159374edd41c9b4827f3ab902cdc2fc294101))

# [3.93.0-dev.1](https://github.com/vtex/faststore/compare/v3.93.0...v3.93.0-dev.1) (2025-11-06)

### Bug Fixes

- Handle empty footer logo scenario ([#3094](https://github.com/vtex/faststore/issues/3094)) ([7323d8a](https://github.com/vtex/faststore/commit/7323d8a7d8cb09ad1d7ada7ca3269b8a28c7b91d))

# [3.93.0-dev.0](https://github.com/vtex/faststore/compare/v3.92.1-dev.0...v3.93.0-dev.0) (2025-11-03)

### Features

- Add RTL Support ([#3097](https://github.com/vtex/faststore/issues/3097)) ([e293857](https://github.com/vtex/faststore/commit/e293857070b265419aee793ba09fd0795e7d7b44))

## [3.92.1-dev.0](https://github.com/vtex/faststore/compare/v3.92.0...v3.92.1-dev.0) (2025-11-03)

## [3.91.3-dev.1](https://github.com/vtex/faststore/compare/v3.91.3-dev.0...v3.91.3-dev.1) (2025-10-30)

## [3.91.3-dev.0](https://github.com/vtex/faststore/compare/v3.91.2...v3.91.3-dev.0) (2025-10-30)

### Bug Fixes

- add background color to TextareaField label ([#3079](https://github.com/vtex/faststore/issues/3079)) ([9e5a64d](https://github.com/vtex/faststore/commit/9e5a64d51d9983f028ec5cf0004cfed633b1ee8d)), closes [#2705](https://github.com/vtex/faststore/issues/2705) [/github.com/vtex/faststore/pull/2705#pullrequestreview-2710467780](https://github.com//github.com/vtex/faststore/pull/2705/issues/pullrequestreview-2710467780) [#2705](https://github.com/vtex/faststore/issues/2705) [/github.com/vtex/faststore/pull/2705#pullrequestreview-2710467780](https://github.com//github.com/vtex/faststore/pull/2705/issues/pullrequestreview-2710467780)
- remove purchaseAgentId filter - SFS-2942 ([#3085](https://github.com/vtex/faststore/issues/3085)) ([270588f](https://github.com/vtex/faststore/commit/270588f1e7490ff94e296c4da7116c4112883359))

### Features

- faststore's default image loader ([#3082](https://github.com/vtex/faststore/issues/3082)) ([a0b5f17](https://github.com/vtex/faststore/commit/a0b5f173dacf349e536604e74a3c52a33cac3fd2))

# [4.2.0](https://github.com/vtex/faststore/compare/v4.1.2...v4.2.0) (2026-06-01)

### Bug Fixes

- preview pnpm pack ([#3367](https://github.com/vtex/faststore/issues/3367)) ([48c36c5](https://github.com/vtex/faststore/commit/48c36c5ee90fc20ce7eb188b034db8f59627afb2))

### Features

- release version 2026 06 01 ([#3370](https://github.com/vtex/faststore/issues/3370)) ([61fcbdf](https://github.com/vtex/faststore/commit/61fcbdfde6a8bb6eb6f0f00d9b5ac3f28421dbf3))
- Release version 2026 06 01 1 ([#3373](https://github.com/vtex/faststore/issues/3373)) ([df3cb4d](https://github.com/vtex/faststore/commit/df3cb4de391a252831dd28cf3bd46f7493bea742))

# [4.2.0-dev.5](https://github.com/vtex/faststore/compare/v4.2.0-dev.4...v4.2.0-dev.5) (2026-06-01)

**Note:** Version bump only for package faststore

# 4.2.0-dev.4 (2026-06-01)

### Bug Fixes

- preview pnpm pack ([#3367](https://github.com/vtex/faststore/issues/3367)) ([186579c](https://github.com/vtex/faststore/commit/186579c4cca44e4d21c25068f075c0fbb6a56d96))

# [4.2.0-dev.3](https://github.com/vtex/faststore/compare/v4.2.0-dev.2...v4.2.0-dev.3) (2026-06-01)

### Performance Improvements

- **core:** SSR ProductGallery and fix CLS on screen-size detection (VTE-9) ([#3349](https://github.com/vtex/faststore/issues/3349)) ([e70a23b](https://github.com/vtex/faststore/commit/e70a23b54504be4cddc97e76c89cf4323fe0941e)), closes [#3345](https://github.com/vtex/faststore/issues/3345)

# [4.2.0-dev.2](https://github.com/vtex/faststore/compare/v4.2.0-dev.1...v4.2.0-dev.2) (2026-06-01)

### Bug Fixes

- strip packageManager from generated .faststore/package.json ([#3335](https://github.com/vtex/faststore/issues/3335)) ([5a2b793](https://github.com/vtex/faststore/commit/5a2b793c4b12f986c72e801fb03809b568a99344))

# 4.2.0-dev.1 (2026-06-01)

### Bug Fixes

- createNextJSPages throwing preventing copy of store discovery-co… ([#3356](https://github.com/vtex/faststore/issues/3356)) ([cf318ab](https://github.com/vtex/faststore/commit/cf318abfecf4c6497d40bfe58203acc90b199696))
- **sdk:** refetch first PLP page from page-load time, not build time ([#3350](https://github.com/vtex/faststore/issues/3350)) ([608c636](https://github.com/vtex/faststore/commit/608c6362eff32b0dabba9d51ada09e50699cd3c8)), closes [#3345](https://github.com/vtex/faststore/issues/3345)

# [4.2.0-dev.0](https://github.com/vtex/faststore/compare/v4.1.2-dev.8...v4.2.0-dev.0) (2026-06-01)

### Features

- paginate listEntries with scroll ([#3282](https://github.com/vtex/faststore/issues/3282)) ([2e43804](https://github.com/vtex/faststore/commit/2e43804b7c3ee336eee5a19f1a11d3185c01102d))

## [4.1.2-dev.8](https://github.com/vtex/faststore/compare/v4.1.2-dev.7...v4.1.2-dev.8) (2026-05-28)

### Bug Fixes

- localization race condition ([#3281](https://github.com/vtex/faststore/issues/3281)) ([75cb5df](https://github.com/vtex/faststore/commit/75cb5dfb5dd3dcd58a15273df5f4c20bb1c8987b)), closes [#3111](https://github.com/vtex/faststore/issues/3111) [#3111](https://github.com/vtex/faststore/issues/3111)

## [4.1.2-dev.7](https://github.com/vtex/faststore/compare/v4.1.2-dev.6...v4.1.2-dev.7) (2026-05-28)

**Note:** Version bump only for package faststore

## [4.1.2-dev.6](https://github.com/vtex/faststore/compare/v4.1.2-dev.5...v4.1.2-dev.6) (2026-05-27)

**Note:** Version bump only for package faststore

## [4.1.2-dev.5](https://github.com/vtex/faststore/compare/v4.1.2-dev.4...v4.1.2-dev.5) (2026-05-21)

### Bug Fixes

- url resolution in windows ([#3337](https://github.com/vtex/faststore/issues/3337)) ([2476091](https://github.com/vtex/faststore/commit/24760916bdcfc73c7d4ef7f92829976d4f1f97d6))

## [4.1.2-dev.4](https://github.com/vtex/faststore/compare/v4.1.2-dev.3...v4.1.2-dev.4) (2026-05-20)

**Note:** Version bump only for package faststore

## [4.1.2-dev.3](https://github.com/vtex/faststore/compare/v4.1.2-dev.2...v4.1.2-dev.3) (2026-05-20)

### Bug Fixes

- **ui:** use dvh for SlideOver height on mobile - SFS-3108 ([#3333](https://github.com/vtex/faststore/issues/3333)) ([487fe0f](https://github.com/vtex/faststore/commit/487fe0f452b25a3653091aeec647ab7f6bcb97d4))

## [4.1.2-dev.2](https://github.com/vtex/faststore/compare/v4.1.2-dev.1...v4.1.2-dev.2) (2026-05-19)

### Bug Fixes

- generate plugin themes with Sass [@use](https://github.com/use) instead of [@import](https://github.com/import) ([#3283](https://github.com/vtex/faststore/issues/3283)) ([22c0e74](https://github.com/vtex/faststore/commit/22c0e74d7d3b3714a5e9b6917d7cc60aa36eeb69))

## 4.1.2-dev.1 (2026-05-19)

### Bug Fixes

- bypass refresh-token flow on localhost in 403 page and useRefreshToken hook ([#3325](https://github.com/vtex/faststore/issues/3325)) ([d48571a](https://github.com/vtex/faststore/commit/d48571a15176497b019bae1462617c3159459421)), closes [#3285](https://github.com/vtex/faststore/issues/3285) [#3285](https://github.com/vtex/faststore/issues/3285)

## 4.1.2-dev.0 (2026-05-15)

### Bug Fixes

- bump version ([4fbfa64](https://github.com/vtex/faststore/commit/4fbfa649afc57218dbf8020abc7333c05b0b034f))

## 4.1.1 (2026-05-15)

### Bug Fixes

- graduate version 4.1.1 ([#3331](https://github.com/vtex/faststore/issues/3331)) ([c26d990](https://github.com/vtex/faststore/commit/c26d990010d8643ceb2ed95ab1737f4eca80e240))
- version bump 4.1.1 ([#3329](https://github.com/vtex/faststore/issues/3329)) ([59345b3](https://github.com/vtex/faststore/commit/59345b3584c3ec5fc6f532e1b5c1bcce9c5c5b97)), closes [#3318](https://github.com/vtex/faststore/issues/3318) [#3312](https://github.com/vtex/faststore/issues/3312) [#3319](https://github.com/vtex/faststore/issues/3319) [#3327](https://github.com/vtex/faststore/issues/3327) [#3320](https://github.com/vtex/faststore/issues/3320) [#3314](https://github.com/vtex/faststore/issues/3314) [#3317](https://github.com/vtex/faststore/issues/3317)

## [4.1.1-dev.1](https://github.com/vtex/faststore/compare/v4.1.0-dev.11...v4.1.1-dev.1) (2026-05-15)

**Note:** Version bump only for package faststore

# 4.1.0-dev.11 (2026-05-15)

**Note:** Version bump only for package faststore

# [4.1.0-dev.10](https://github.com/vtex/faststore/compare/v4.1.0...v4.1.0-dev.10) (2026-05-15)

**Note:** Version bump only for package faststore

# [4.1.0-dev.9](https://github.com/vtex/faststore/compare/v4.1.0-dev.8...v4.1.0-dev.9) (2026-05-15)

**Note:** Version bump only for package faststore

# [4.1.0-dev.8](https://github.com/vtex/faststore/compare/v4.1.0-dev.7...v4.1.0-dev.8) (2026-05-15)

**Note:** Version bump only for package faststore

# [4.1.0-dev.7](https://github.com/vtex/faststore/compare/v4.1.0-dev.6...v4.1.0-dev.7) (2026-05-15)

**Note:** Version bump only for package faststore

# [4.1.0-dev.6](https://github.com/vtex/faststore/compare/v4.1.0-dev.5...v4.1.0-dev.6) (2026-05-14)

**Note:** Version bump only for package faststore

# [4.1.0-dev.5](https://github.com/vtex/faststore/compare/v4.1.0-dev.4...v4.1.0-dev.5) (2026-05-14)

### Bug Fixes

- region slider section render ([#3318](https://github.com/vtex/faststore/issues/3318)) ([f9f5e0d](https://github.com/vtex/faststore/commit/f9f5e0dbd6c3e92b24a3fb1e21a95bfb1c6744f1)), closes [#2887](https://github.com/vtex/faststore/issues/2887) [#2961](https://github.com/vtex/faststore/issues/2961) [#3071](https://github.com/vtex/faststore/issues/3071)

# [4.1.0-dev.4](https://github.com/vtex/faststore/compare/v4.1.0-dev.3...v4.1.0-dev.4) (2026-05-13)

**Note:** Version bump only for package faststore

# [4.1.0-dev.3](https://github.com/vtex/faststore/compare/v4.1.0-dev.2...v4.1.0-dev.3) (2026-05-13)

**Note:** Version bump only for package faststore

# [4.1.0-dev.2](https://github.com/vtex/faststore/compare/v4.1.0-dev.1...v4.1.0-dev.2) (2026-05-12)

### Bug Fixes

- allow_all_components for CMS ([#3312](https://github.com/vtex/faststore/issues/3312)) ([eadeaa3](https://github.com/vtex/faststore/commit/eadeaa36782b40be0fe7fb16604f7a5bc3da2b79))

# 4.1.0 (2026-05-11)

### Features

- version bump 4.1.0 ([#3310](https://github.com/vtex/faststore/issues/3310)) ([1ea7bac](https://github.com/vtex/faststore/commit/1ea7bac649d783e50a9e79f8fe412009ae4a87f7)), closes [#3309](https://github.com/vtex/faststore/issues/3309) [#3308](https://github.com/vtex/faststore/issues/3308) [#3306](https://github.com/vtex/faststore/issues/3306) [#3304](https://github.com/vtex/faststore/issues/3304) [#3301](https://github.com/vtex/faststore/issues/3301)

# [4.1.0-dev.1](https://github.com/vtex/faststore/compare/v4.1.0-dev.0...v4.1.0-dev.1) (2026-05-11)

### Bug Fixes

- PLP "Load more products" overwriting list instead of appending ([#3308](https://github.com/vtex/faststore/issues/3308)) ([e8b08cd](https://github.com/vtex/faststore/commit/e8b08cd4ffeeac63e1ede45ddd75043ef7695813)), closes [#3015](https://github.com/vtex/faststore/issues/3015) [#3015](https://github.com/vtex/faststore/issues/3015)

# [4.1.0-dev.0](https://github.com/vtex/faststore/compare/v4.0.1-dev.2...v4.1.0-dev.0) (2026-05-11)

### Features

- user details adjusts - SFS-2950 ([#3306](https://github.com/vtex/faststore/issues/3306)) ([70b018d](https://github.com/vtex/faststore/commit/70b018d713b4ec0da698bfc377332b356d9fa9cd))

## [4.0.1-dev.2](https://github.com/vtex/faststore/compare/v4.0.1-dev.1...v4.0.1-dev.2) (2026-05-11)

### Bug Fixes

- localization selector stale and reset selection for unsaved changes ([#3301](https://github.com/vtex/faststore/issues/3301)) ([023e52e](https://github.com/vtex/faststore/commit/023e52ee3c8798cfc9f12ed98e99e8efacb1f1d5))

## [4.0.1-dev.1](https://github.com/vtex/faststore/compare/v4.0.1-dev.0...v4.0.1-dev.1) (2026-05-07)

### Bug Fixes

- updates schemas vtex.faststore ([#3304](https://github.com/vtex/faststore/issues/3304)) ([490175f](https://github.com/vtex/faststore/commit/490175ff4cc06bf23f7957bbd1f9d002baa13e43))

## [4.0.1-dev.0](https://github.com/vtex/faststore/compare/v4.0.0...v4.0.1-dev.0) (2026-05-07)

# 4.0.0-dev.4 (2026-05-07)

**Note:** Version bump only for package faststore

# [4.0.0](https://github.com/vtex/faststore/compare/v3.99.0...v4.0.0) (2026-05-07)

### Features

- FastStore v4 ([#3302](https://github.com/vtex/faststore/issues/3302)) ([c7ca1a2](https://github.com/vtex/faststore/commit/c7ca1a2a9a6161bdf30e33a965ecf2fda9ef3fbf))

# [4.0.0-dev.4](https://github.com/vtex/faststore/compare/v4.0.0-dev.3...v4.0.0-dev.4) (2026-05-07)

### Bug Fixes

- add repository field to diagnostics package for OIDC provenance ([d1e40ab](https://github.com/vtex/faststore/commit/d1e40abe742b469a68b3d178c10ef56e5184ec29))

# [4.0.0-dev.3](https://github.com/vtex/faststore/compare/v4.0.0-dev.2...v4.0.0-dev.3) (2026-05-07)

### Features

- trigger v4 publish ([bb56584](https://github.com/vtex/faststore/commit/bb565843917c61b4d0023c2ad21284a1aa95c55e))

# [4.0.0-dev.2](https://github.com/vtex/faststore/compare/v4.0.0-dev.1...v4.0.0-dev.2) (2026-05-07)

### Features

- force publish all packages on v4 release ([0e765a3](https://github.com/vtex/faststore/commit/0e765a335da1f16b4a4298caa31900286f324ea8))

# [4.0.0-dev.1](https://github.com/vtex/faststore/compare/v4.0.0-dev.0...v4.0.0-dev.1) (2026-05-07)

### Features

- trigger v4 publish ([7f725d2](https://github.com/vtex/faststore/commit/7f725d27575619a2475b273b779906a745166f84))

# 3.99.0-dev.9 (2026-05-07)

### Bug Fixes

- release command ([e912b5e](https://github.com/vtex/faststore/commit/e912b5e10cf61e65f24502fb077c06799009da61))

# 3.99.0-dev.8 (2026-05-04)

**Note:** Version bump only for package faststore

# [3.99.0-dev.7](https://github.com/vtex/faststore/compare/v3.99.0-dev.6...v3.99.0-dev.7) (2026-05-04)

### Bug Fixes

- fixing preview tag style ([#3058](https://github.com/vtex/faststore/issues/3058)) ([5084915](https://github.com/vtex/faststore/commit/50849157ac190a57fc151e7e6c9cb10df487bff6))

# 3.99.0-dev.6 (2026-05-04)

### Bug Fixes

- Base CMS schema ([#3290](https://github.com/vtex/faststore/issues/3290)) ([3455e89](https://github.com/vtex/faststore/commit/3455e89295e197f4bd18c0b5f84d7b01c0d67009))

# 3.99.0-dev.5 (2026-05-04)

### Bug Fixes

- Enhance session validation logic to skip token refresh in local … ([#3285](https://github.com/vtex/faststore/issues/3285)) ([41a330a](https://github.com/vtex/faststore/commit/41a330a9704a29369141e6e78b1f6d01e5a2e1a5))

# 3.99.0-dev.4 (2026-04-28)

### Bug Fixes

- Refactor token refresh logic in GraphQL API handler - SFS-3104 ([#3263](https://github.com/vtex/faststore/issues/3263)) ([695ab6a](https://github.com/vtex/faststore/commit/695ab6a9413eb53ef457cfc890c74e41c29c1ab8))

# 3.99.0-dev.3 (2026-04-23)

### Features

- add isGift field to StoreOffer type and resolvers - SFS-3040 ([#3220](https://github.com/vtex/faststore/issues/3220)) ([e10fc92](https://github.com/vtex/faststore/commit/e10fc92633a5296a5b03286028d31d9c280561c6))
- Enhance session management with logout - SFS-3105 ([#3268](https://github.com/vtex/faststore/issues/3268)) ([9468e32](https://github.com/vtex/faststore/commit/9468e32a3531ca3c91c7f82a34ac1c750c6a26ef))

# [3.99.0-dev.2](https://github.com/vtex/faststore/compare/v3.99.0-dev.1...v3.99.0-dev.2) (2026-04-21)

### Bug Fixes

- Prevent IDB writes before store hydration completes - SFS-3121 ([#3267](https://github.com/vtex/faststore/issues/3267)) ([0b23e52](https://github.com/vtex/faststore/commit/0b23e526db23d7338c0eda75b673bb0bea05eef3))

# [3.99.0-dev.1](https://github.com/vtex/faststore/compare/v3.99.0-dev.0...v3.99.0-dev.1) (2026-04-15)

**Note:** Version bump only for package faststore

# [3.99.0-dev.0](https://github.com/vtex/faststore/compare/v3.98.1-dev.0...v3.99.0-dev.0) (2026-03-31)

### Features

- Add Shopping Assistant component to FastStore schema ([#3255](https://github.com/vtex/faststore/issues/3255)) ([f4c8ea6](https://github.com/vtex/faststore/commit/f4c8ea65da468d26acac198071882523a8a57215))

## [3.98.4](https://github.com/vtex/faststore/compare/v3.98.3...v3.98.4) (2026-04-15)

**Note:** Version bump only for package faststore

## [3.98.3](https://github.com/vtex/faststore/compare/v3.98.2...v3.98.3) (2026-04-09)

### Bug Fixes

- Store ID param sent to Content Platform client ([#3265](https://github.com/vtex/faststore/issues/3265)) ([63fffd8](https://github.com/vtex/faststore/commit/63fffd878403c4d0c9aff8f6d56064dfa42ab833))

## [3.98.2](https://github.com/vtex/faststore/compare/v3.98.1...v3.98.2) (2026-04-09)

### Bug Fixes

- unsafe props ternary ([#3254](https://github.com/vtex/faststore/issues/3254)) ([00f35b5](https://github.com/vtex/faststore/commit/00f35b5b49a756b6de84d1739ae157e3f074f01e))

## [3.98.1](https://github.com/vtex/faststore/compare/v3.98.0...v3.98.1) (2026-04-07)

### Bug Fixes

- simplify city and postal code display logic in `RegionBar` and `RegionButton` ([#3259](https://github.com/vtex/faststore/issues/3259)) ([8944bee](https://github.com/vtex/faststore/commit/8944bee9cb92ccea2b6ca24309cfa5478b6f4d0d))

# 3.98.0 (2026-03-27)

### Bug Fixes

- Set `after` attribute as string instead of integer ([#3245](https://github.com/vtex/faststore/issues/3245)) ([c40d3fc](https://github.com/vtex/faststore/commit/c40d3fcf0018099cc067bb7082757535ca9839b0))

### Features

- version 2026 03 27 ([#3251](https://github.com/vtex/faststore/issues/3251)) ([f330a43](https://github.com/vtex/faststore/commit/f330a43661567ad8edb468acd3416bb7ffacd8b6))

# [3.98.0-dev.10](https://github.com/vtex/faststore/compare/v3.98.0-dev.9...v3.98.0-dev.10) (2026-03-27)

**Note:** Version bump only for package faststore

# [3.98.0-dev.9](https://github.com/vtex/faststore/compare/v3.98.0-dev.8...v3.98.0-dev.9) (2026-03-27)

**Note:** Version bump only for package faststore

# [3.98.0-dev.8](https://github.com/vtex/faststore/compare/v3.98.0-dev.7...v3.98.0-dev.8) (2026-03-27)

### Features

- Add Quick Order Full Feature ([#3197](https://github.com/vtex/faststore/issues/3197)) ([f5518d7](https://github.com/vtex/faststore/commit/f5518d7f205dccad99b6ea0a127fd09cf77d1edb))

# [3.98.0-dev.7](https://github.com/vtex/faststore/compare/v3.98.0-dev.6...v3.98.0-dev.7) (2026-03-26)

**Note:** Version bump only for package faststore

# [3.98.0-dev.6](https://github.com/vtex/faststore/compare/v3.98.0-dev.5...v3.98.0-dev.6) (2026-03-24)

### Bug Fixes

- enhance cache key management in useQuery ([#3230](https://github.com/vtex/faststore/issues/3230)) ([3f28502](https://github.com/vtex/faststore/commit/3f28502a8d381e476728661ea1150d0777ba87d1))

# [3.98.0-dev.5](https://github.com/vtex/faststore/compare/v3.98.0-dev.4...v3.98.0-dev.5) (2026-03-24)

### Features

- Add Webchat component and script integration + hCMS - SFS-3084 ([#3242](https://github.com/vtex/faststore/issues/3242)) ([04c3fbb](https://github.com/vtex/faststore/commit/04c3fbb91d028c5828998388105d327913194074))

# [3.98.0-dev.4](https://github.com/vtex/faststore/compare/v3.98.0-dev.3...v3.98.0-dev.4) (2026-03-23)

### Features

- Add transpilePackages to configuration for Next.js - SFS-3100 ([#3244](https://github.com/vtex/faststore/issues/3244)) ([9399323](https://github.com/vtex/faststore/commit/939932383b3abf78a6c7184ac9f428d90d49401b))

# [3.98.0-dev.3](https://github.com/vtex/faststore/compare/v3.98.0-dev.2...v3.98.0-dev.3) (2026-03-12)

### Features

- Add ActivityFlow data parameters with search-related information ([#3105](https://github.com/vtex/faststore/issues/3105)) ([8f69ff8](https://github.com/vtex/faststore/commit/8f69ff855c31abedba66071132240c53a93ab56d))

# [3.98.0-dev.2](https://github.com/vtex/faststore/compare/v3.98.0-dev.1...v3.98.0-dev.2) (2026-03-03)

### Features

- add mpn (manufacturer code) to product's structured data ([#3234](https://github.com/vtex/faststore/issues/3234)) ([9597e39](https://github.com/vtex/faststore/commit/9597e39a8d63a651b815f90fe3b1ea5409258ca3))

# 3.98.0-dev.1 (2026-02-24)

### Features

- update coderabbit instructions ([#3226](https://github.com/vtex/faststore/issues/3226)) ([dfbc58a](https://github.com/vtex/faststore/commit/dfbc58a042443a3018c0b3df569f42918e3e349d))

# [3.98.0-dev.0](https://github.com/vtex/faststore/compare/v3.97.0-dev.6...v3.98.0-dev.0) (2026-02-24)

### Features

- release version 20260224 ([#3225](https://github.com/vtex/faststore/issues/3225)) ([7a52516](https://github.com/vtex/faststore/commit/7a5251677a8f67066a2e060191b896ae6d0b0d9a))

## [3.97.1](https://github.com/vtex/faststore/compare/v3.97.0...v3.97.1) (2026-02-24)

**Note:** Version bump only for package faststore

# [3.97.0](https://github.com/vtex/faststore/compare/v3.96.5...v3.97.0) (2026-02-03)

**Note:** Version bump only for package faststore

# [3.97.0-dev.6](https://github.com/vtex/faststore/compare/v3.97.0-dev.5...v3.97.0-dev.6) (2026-02-19)

### Bug Fixes

- remove query string from preview cookie path ([#3213](https://github.com/vtex/faststore/issues/3213)) ([bc60a59](https://github.com/vtex/faststore/commit/bc60a5968d48f03e0fe52060b19dc8b48f6582f0))

# [3.97.0-dev.5](https://github.com/vtex/faststore/compare/v3.97.0-dev.4...v3.97.0-dev.5) (2026-02-19)

**Note:** Version bump only for package faststore

# [3.97.0-dev.4](https://github.com/vtex/faststore/compare/v3.97.0-dev.3...v3.97.0-dev.4) (2026-02-10)

### Bug Fixes

- scripts improvements - update RC url + Partytown loading + logs + fix bugs. ([#3198](https://github.com/vtex/faststore/issues/3198)) ([9a35b63](https://github.com/vtex/faststore/commit/9a35b63a91bc5cd53de553c053ceeed8bb983184))

# [3.97.0-dev.3](https://github.com/vtex/faststore/compare/v3.97.0-dev.2...v3.97.0-dev.3) (2026-02-06)

### Features

- add budget to order details ([#3130](https://github.com/vtex/faststore/issues/3130)) ([f109b02](https://github.com/vtex/faststore/commit/f109b0271542aef02810d2996f00e075a9b9bde6))

# 3.97.0-dev.2 (2026-02-06)

### Features

- reorder feature ([#3153](https://github.com/vtex/faststore/issues/3153)) ([d0fdeec](https://github.com/vtex/faststore/commit/d0fdeec77cd94e16f1b79dcc927487320983ba0e))

# [3.97.0-dev.1](https://github.com/vtex/faststore/compare/v3.96.5...v3.97.0-dev.1) (2026-02-03)

# 3.97.0-dev.0 (2026-01-27)

**Note:** Version bump only for package faststore

# [3.97.0-dev.0](https://github.com/vtex/faststore/compare/v3.96.4-dev.0...v3.97.0-dev.0) (2026-01-27)

### Features

- Enable fraction digit formatting for SEO's `product:price:amount` meta tag ([#3179](https://github.com/vtex/faststore/issues/3179)) ([d6e6252](https://github.com/vtex/faststore/commit/d6e6252eb578d782505b8e505ee48cd9fd1526e3))

## [3.96.5](https://github.com/vtex/faststore/compare/v3.96.4...v3.96.5) (2026-02-02)

### Bug Fixes

- normalize set cookies domain host - SFS-3034 ([#3190](https://github.com/vtex/faststore/issues/3190)) ([645c91d](https://github.com/vtex/faststore/commit/645c91debeb16379f41aff6cb2225e2ed3b6086b))

## [3.96.4](https://github.com/vtex/faststore/compare/v3.96.3...v3.96.4) (2026-01-26)

### Bug Fixes

- close filter on apply button click in FilterSlider component ([#3187](https://github.com/vtex/faststore/issues/3187)) ([f3c96eb](https://github.com/vtex/faststore/commit/f3c96eb5e73178d8c863a3e40ac576dc623a0624))

## [3.96.4-dev.0](https://github.com/vtex/faststore/compare/v3.96.3...v3.96.4-dev.0) (2026-01-21)

## [3.96.3](https://github.com/vtex/faststore/compare/v3.96.2...v3.96.3) (2026-01-21)

**Note:** Version bump only for package faststore

## [3.96.2](https://github.com/vtex/faststore/compare/v3.96.1...v3.96.2) (2026-01-14)

### Bug Fixes

- validate cart loop shipping simulation / logged ([#3174](https://github.com/vtex/faststore/issues/3174)) ([41bc64b](https://github.com/vtex/faststore/commit/41bc64bfa48382b3cbe5c05c7a57ce6d3e403da3))

## [3.96.1](https://github.com/vtex/faststore/compare/v3.96.0...v3.96.1) (2026-01-09)

### Bug Fixes

- error shipping without neighborhood ([#3168](https://github.com/vtex/faststore/issues/3168)) ([fa91844](https://github.com/vtex/faststore/commit/fa91844390a8f928b7509f6778518584c147aa48))

# [3.96.0](https://github.com/vtex/faststore/compare/v3.95.0...v3.96.0) (2025-12-24)

### Features

- version 20251223 ([#3161](https://github.com/vtex/faststore/issues/3161)) ([ad5e8d1](https://github.com/vtex/faststore/commit/ad5e8d12fe45f1fb8e1134165172bf1c6b2a91e2))

# 3.96.0-dev.22 (2026-01-21)

**Note:** Version bump only for package faststore

# 3.96.0-dev.22 (2026-01-21)

### Bug Fixes

- Clear cart (get new orderForm) if there is no checkout cookie present ([#3178](https://github.com/vtex/faststore/issues/3178)) ([f3f69bc](https://github.com/vtex/faststore/commit/f3f69bca1c54f2859ad4c3ac9a52563a0e8c2571))

# [3.96.0-dev.21](https://github.com/vtex/faststore/compare/v3.96.0-dev.20...v3.96.0-dev.21) (2026-01-08)

### Bug Fixes

- Prevent Partytown cross-origin errors in iframe environments ([#3155](https://github.com/vtex/faststore/issues/3155)) ([997252e](https://github.com/vtex/faststore/commit/997252e9a18807f4c26c350197d4f2d139de58f8))

# [3.96.0-dev.20](https://github.com/vtex/faststore/compare/v3.96.0-dev.19...v3.96.0-dev.20) (2026-01-08)

### Bug Fixes

- Add slug field to landing page schema - CROC-185 ([#3166](https://github.com/vtex/faststore/issues/3166)) ([41b9878](https://github.com/vtex/faststore/commit/41b987825ee5ebb7d311eef33e2ca65034dc130d))

# [3.96.0-dev.19](https://github.com/vtex/faststore/compare/v3.96.0-dev.18...v3.96.0-dev.19) (2026-01-08)

### Features

- logout clear storage ([#3163](https://github.com/vtex/faststore/issues/3163)) ([1fbacc3](https://github.com/vtex/faststore/commit/1fbacc3b3e32b4f83a2f56c1f97eb0f8ff843f61))

# 3.96.0-dev.18 (2025-12-24)

**Note:** Version bump only for package faststore

# 3.96.0-dev.17 (2025-12-23)

**Note:** Version bump only for package faststore

# [3.96.0-dev.16](https://github.com/vtex/faststore/compare/v3.96.0-dev.15...v3.96.0-dev.16) (2025-12-23)

**Note:** Version bump only for package faststore

# [3.96.0-dev.15](https://github.com/vtex/faststore/compare/v3.96.0-dev.14...v3.96.0-dev.15) (2025-12-23)

**Note:** Version bump only for package faststore

# [3.96.0-dev.14](https://github.com/vtex/faststore/compare/v3.96.0-dev.13...v3.96.0-dev.14) (2025-12-23)

**Note:** Version bump only for package faststore

# [3.96.0-dev.13](https://github.com/vtex/faststore/compare/v3.96.0-dev.12...v3.96.0-dev.13) (2025-12-23)

**Note:** Version bump only for package faststore

# [3.96.0-dev.12](https://github.com/vtex/faststore/compare/v3.96.0-dev.11...v3.96.0-dev.12) (2025-12-23)

**Note:** Version bump only for package faststore

# 3.96.0-dev.11 (2025-12-23)

### Bug Fixes

- correct comment for platform specific config in discovery configuration ([0fea6fa](https://github.com/vtex/faststore/commit/0fea6faf812c0f0af3f139b6507b2f342264209c))

# 3.96.0-dev.10 (2025-12-23)

**Note:** Version bump only for package faststore

# [3.96.0-dev.9](https://github.com/vtex/faststore/compare/v3.96.0-dev.8...v3.96.0-dev.9) (2025-12-23)

**Note:** Version bump only for package faststore

# [3.96.0-dev.8](https://github.com/vtex/faststore/compare/v3.96.0-dev.7...v3.96.0-dev.8) (2025-12-23)

**Note:** Version bump only for package faststore

# 3.96.0-dev.7 (2025-12-23)

### Bug Fixes

- correct comment for platform specific API configuration in discovery config ([b03968c](https://github.com/vtex/faststore/commit/b03968c84cfb935b71ef64f575dcdf3e8f624b5a))

# 3.96.0-dev.6 (2025-12-23)

**Note:** Version bump only for package faststore

# 3.96.0-dev.5 (2025-12-23)

### Features

- Trigger build ([28b6ec0](https://github.com/vtex/faststore/commit/28b6ec0489080be0a3431ec2ead7bfce0da75a34))

# 3.96.0-dev.4 (2025-12-23)

### Bug Fixes

- update release workflow to handle both main and dev branches ([#3160](https://github.com/vtex/faststore/issues/3160)) ([4247f92](https://github.com/vtex/faststore/commit/4247f9254f47056e726418290f4f019760a81935))

# [3.96.0-dev.3](https://github.com/vtex/faststore/compare/v3.96.0-dev.2...v3.96.0-dev.3) (2025-12-22)

**Note:** Version bump only for package faststore

# [3.96.0-dev.2](https://github.com/vtex/faststore/compare/v3.96.0-dev.1...v3.96.0-dev.2) (2025-12-18)

### Bug Fixes

- adds cache busting to bypass cache when logged in/out. ([#3152](https://github.com/vtex/faststore/issues/3152)) ([862ea50](https://github.com/vtex/faststore/commit/862ea50999214771c4fa38fa70db789b4de5e59b))

# [3.96.0-dev.1](https://github.com/vtex/faststore/compare/v3.96.0-dev.0...v3.96.0-dev.1) (2025-12-16)

**Note:** Version bump only for package faststore

# [3.96.0-dev.0](https://github.com/vtex/faststore/compare/v3.95.1-dev.0...v3.96.0-dev.0) (2025-12-10)

### Features

- adds `priceTags` as tax - SFS-2970 ([#3144](https://github.com/vtex/faststore/issues/3144)) ([d1b3869](https://github.com/vtex/faststore/commit/d1b38699f2955890be1759e1d6d6cf55e1c4dda9))

## [3.95.1-dev.0](https://github.com/vtex/faststore/compare/v3.95.0...v3.95.1-dev.0) (2025-12-02)

# 3.95.0 (2025-12-02)

### Features

- release graduate ([#3139](https://github.com/vtex/faststore/issues/3139)) ([90285fc](https://github.com/vtex/faststore/commit/90285fcc453531a897ba52adcb14032e8ebd8065))
- release version 20250212 ([#3138](https://github.com/vtex/faststore/issues/3138)) ([5e51548](https://github.com/vtex/faststore/commit/5e5154898e3756aa8d95efd54d76db0c90248d8d))

# 3.95.0-dev.3 (2025-12-02)

**Note:** Version bump only for package faststore

# [3.95.0-dev.2](https://github.com/vtex/faststore/compare/v3.94.0...v3.95.0-dev.2) (2025-12-02)

### Features

- release version 20250112 ([#3135](https://github.com/vtex/faststore/issues/3135)) ([65440cd](https://github.com/vtex/faststore/commit/65440cd5607e6946b4023882eacf711c215aa138))

# 3.95.0-dev.1 (2025-12-01)

### Bug Fixes

- remove unnecessary fields from session in validateSession function ([#3124](https://github.com/vtex/faststore/issues/3124)) ([d64b7f6](https://github.com/vtex/faststore/commit/d64b7f61cb62881f448fafad2ed4d4b3771cdeca))
- Update `validateCart` mutation tests ([#3132](https://github.com/vtex/faststore/issues/3132)) ([c8cbb52](https://github.com/vtex/faststore/commit/c8cbb5204562ddee126c63a576ba1f4d264092f7))

# [3.95.0-dev.0](https://github.com/vtex/faststore/compare/v3.94.1-dev.0...v3.95.0-dev.0) (2025-11-20)

### Features

- Add svg extension to public folder copy's allow list ([#3123](https://github.com/vtex/faststore/issues/3123)) ([15aca77](https://github.com/vtex/faststore/commit/15aca77a3e4309d780dcb2c1511618a450c61e0f))

## [3.94.1-dev.0](https://github.com/vtex/faststore/compare/v3.94.0...v3.94.1-dev.0) (2025-11-19)

# 3.94.0 (2025-11-19)

### Features

- release version 20251119 17 05 ([#3126](https://github.com/vtex/faststore/issues/3126)) ([9753c3f](https://github.com/vtex/faststore/commit/9753c3ff5ea760767978c41ec138b661a87ad731))
- update version to 3.93.0-dev.4 and clean up changelogs ([#3127](https://github.com/vtex/faststore/issues/3127)) ([0c29d74](https://github.com/vtex/faststore/commit/0c29d749dc2222d01d848ffda9c2ae95dfba22af))

# 3.93.0-dev.4 (2025-11-17)

**Note:** Version bump only for package faststore

# [3.93.0-dev.4](https://github.com/vtex/faststore/compare/v3.93.0-dev.3...v3.93.0-dev.4) (2025-11-17)

### Bug Fixes

- Show skeleton when product price is validating ([#3112](https://github.com/vtex/faststore/issues/3112)) ([1acb303](https://github.com/vtex/faststore/commit/1acb30334e2a17fe81630d3b0d631152c4e635f3))

# 3.93.0-dev.3 (2025-11-17)

### Bug Fixes

- build among diff modules ([#3119](https://github.com/vtex/faststore/issues/3119)) ([fde7eb6](https://github.com/vtex/faststore/commit/fde7eb6635aaa4e0821fb8f6c6fb71f24604330b))

# [3.93.0-dev.2](https://github.com/vtex/faststore/compare/v3.93.0-dev.1...v3.93.0-dev.2) (2025-11-07)

### Bug Fixes

- **ui:** update slider variable for border-radius in the mozilla rules ([#3077](https://github.com/vtex/faststore/issues/3077)) ([c491593](https://github.com/vtex/faststore/commit/c49159374edd41c9b4827f3ab902cdc2fc294101))

# 3.93.0-dev.1 (2025-11-06)

### Bug Fixes

- Handle empty footer logo scenario ([#3094](https://github.com/vtex/faststore/issues/3094)) ([7323d8a](https://github.com/vtex/faststore/commit/7323d8a7d8cb09ad1d7ada7ca3269b8a28c7b91d))

# [3.93.0-dev.0](https://github.com/vtex/faststore/compare/v3.92.1-dev.0...v3.93.0-dev.0) (2025-11-03)

### Features

- Add RTL Support ([#3097](https://github.com/vtex/faststore/issues/3097)) ([e293857](https://github.com/vtex/faststore/commit/e293857070b265419aee793ba09fd0795e7d7b44))

## [3.92.1-dev.0](https://github.com/vtex/faststore/compare/v3.91.3-dev.1...v3.92.1-dev.0) (2025-11-03)

**Note:** Version bump only for package faststore

# [3.92.0](https://github.com/vtex/faststore/compare/v3.91.2...v3.92.0) (2025-11-03)

### Features

- release ([#3092](https://github.com/vtex/faststore/issues/3092)) ([6dfe2ba](https://github.com/vtex/faststore/commit/6dfe2ba42dd03137ea53c85ad5aa3ee5a13c2fbf))

## [3.91.3-dev.1](https://github.com/vtex/faststore/compare/v3.91.3-dev.0...v3.91.3-dev.1) (2025-10-30)

**Note:** Version bump only for package faststore

## 3.91.3-dev.0 (2025-10-30)

### Bug Fixes

- add background color to TextareaField label ([#3079](https://github.com/vtex/faststore/issues/3079)) ([9e5a64d](https://github.com/vtex/faststore/commit/9e5a64d51d9983f028ec5cf0004cfed633b1ee8d)), closes [#2705](https://github.com/vtex/faststore/issues/2705) [/github.com/vtex/faststore/pull/2705#pullrequestreview-2710467780](https://github.com//github.com/vtex/faststore/pull/2705/issues/pullrequestreview-2710467780) [#2705](https://github.com/vtex/faststore/issues/2705) [/github.com/vtex/faststore/pull/2705#pullrequestreview-2710467780](https://github.com//github.com/vtex/faststore/pull/2705/issues/pullrequestreview-2710467780)
- remove purchaseAgentId filter - SFS-2942 ([#3085](https://github.com/vtex/faststore/issues/3085)) ([270588f](https://github.com/vtex/faststore/commit/270588f1e7490ff94e296c4da7116c4112883359))

## 3.91.2 (2025-10-27)

### Bug Fixes

- update buying policy alert message to include dynamic description SFS-2861 ([#3076](https://github.com/vtex/faststore/issues/3076)) ([f8f470e](https://github.com/vtex/faststore/commit/f8f470e7d70a0a2556e6136d84f57540b734b528))
- update SEO for search page ([#3081](https://github.com/vtex/faststore/issues/3081)) ([315a244](https://github.com/vtex/faststore/commit/315a244c3ee119f0c5d1f61a095ac70754582026))

## [3.91.1](https://github.com/vtex/faststore/compare/v3.91.0...v3.91.1) (2025-10-24)

### Bug Fixes

- signin button flickering - SFS-2862 ([#3078](https://github.com/vtex/faststore/issues/3078)) ([edd4ac0](https://github.com/vtex/faststore/commit/edd4ac084817467e6dcedc6cd5fe89923b0f55e3))

# [3.91.0](https://github.com/vtex/faststore/compare/v3.90.1...v3.91.0) (2025-10-24)

### Features

- user validation improvements + refresh token SSR and api - SFS-2909 ([#3065](https://github.com/vtex/faststore/issues/3065)) ([97071ee](https://github.com/vtex/faststore/commit/97071ee21fcee0b038dfafa06633ef597136898e))

## [3.90.1](https://github.com/vtex/faststore/compare/v3.90.0...v3.90.1) (2025-10-20)

### Bug Fixes

- selectedFacets value for ProductShelf and ProductTiles ([#3073](https://github.com/vtex/faststore/issues/3073)) ([3e68ca1](https://github.com/vtex/faststore/commit/3e68ca1a600ba35c83d5493e708a8538953c02d0))

# [3.90.0](https://github.com/vtex/faststore/compare/v3.89.6...v3.90.0) (2025-10-13)

### Features

- show manage button only when the user be manage ([#3067](https://github.com/vtex/faststore/issues/3067)) ([08c1798](https://github.com/vtex/faststore/commit/08c17988d1a4d8aaba8016473898d2ee2ce5c244))

## [3.89.6](https://github.com/vtex/faststore/compare/v3.89.5...v3.89.6) (2025-10-09)

### Bug Fixes

- My Account orders list table ([#3066](https://github.com/vtex/faststore/issues/3066)) ([394f401](https://github.com/vtex/faststore/commit/394f40162aa190da328daf40715ac1a1db0d6d70))

## [3.89.5](https://github.com/vtex/faststore/compare/v3.89.4...v3.89.5) (2025-10-08)

### Bug Fixes

- Hide `Placed by` column from orders list and filters ([#3064](https://github.com/vtex/faststore/issues/3064)) ([d6ac4c8](https://github.com/vtex/faststore/commit/d6ac4c82727963cd430aa27a0c56f3d77ebd4870))

## [3.89.4](https://github.com/vtex/faststore/compare/v3.89.3...v3.89.4) (2025-10-06)

### Bug Fixes

- org drawer corporate name - SFS-2904 ([#3062](https://github.com/vtex/faststore/issues/3062)) ([0ab3a92](https://github.com/vtex/faststore/commit/0ab3a925567d5905db8c9c688e1087b649790121))

## [3.89.3](https://github.com/vtex/faststore/compare/v3.89.2...v3.89.3) (2025-10-03)

### Bug Fixes

- implement app key/token utility for header management in MD requests. - SFS-2881 ([#3055](https://github.com/vtex/faststore/issues/3055)) ([1b42506](https://github.com/vtex/faststore/commit/1b42506a05bbb38f31ade73075529cd488428450))

## 3.89.2 (2025-10-02)

### Bug Fixes

- Filter quantity badge and labels references SFS-2896 ([#3061](https://github.com/vtex/faststore/issues/3061)) ([cfcf650](https://github.com/vtex/faststore/commit/cfcf650b5d1462c3988bc83fe2cb83981a2afa04))
- refactor `ProductShelf` component to import directly - SFS-2895 ([#3059](https://github.com/vtex/faststore/issues/3059)) ([24ee8fb](https://github.com/vtex/faststore/commit/24ee8fb8020cf037f4fe83b7ace1a747c383cbcf))

## [3.89.1](https://github.com/vtex/faststore/compare/v3.89.0...v3.89.1) (2025-10-02)

### Bug Fixes

- updates contract name SFS-2863 ([#3051](https://github.com/vtex/faststore/issues/3051)) ([3b884e4](https://github.com/vtex/faststore/commit/3b884e49eabbbd4d5832f342c759d1301c98dc0e))

# [3.89.0](https://github.com/vtex/faststore/compare/v3.88.7...v3.89.0) (2025-10-02)

### Features

- My Account QA SFS-2859 ([#3040](https://github.com/vtex/faststore/issues/3040)) ([5e36a5f](https://github.com/vtex/faststore/commit/5e36a5f31acb1523024ad6e7063ca51aabe2f303)), closes [/github.com/vtex/faststore/blob/af6d2acbbc2fb72778c7223897ec7846736b4c87/packages/core/src/components/account/orders/MyAccountOrderDetails/MyAccountOrderDetails.tsx#L1](https://github.com//github.com/vtex/faststore/blob/af6d2acbbc2fb72778c7223897ec7846736b4c87/packages/core/src/components/account/orders/MyAccountOrderDetails/MyAccountOrderDetails.tsx/issues/L1)

## [3.88.7](https://github.com/vtex/faststore/compare/v3.88.6...v3.88.7) (2025-09-25)

### Bug Fixes

- refactor search dropdown to handle analytics events asynchronously ([#3057](https://github.com/vtex/faststore/issues/3057)) ([ebd0ead](https://github.com/vtex/faststore/commit/ebd0eadfaf80f493e4defd88e47517f346720810))

## [3.88.6](https://github.com/vtex/faststore/compare/v3.88.5...v3.88.6) (2025-09-23)

### Bug Fixes

- Revert "feat: add organization management permission validation ([#3029](https://github.com/vtex/faststore/issues/3029))" - SFS-2880 ([#3054](https://github.com/vtex/faststore/issues/3054)) ([68854b1](https://github.com/vtex/faststore/commit/68854b120b28d910b4ab48c93c1fbb60fe0e470d))

## [3.88.5](https://github.com/vtex/faststore/compare/v3.88.4...v3.88.5) (2025-09-22)

### Bug Fixes

- update account URL logic in ButtonSignIn component ([#3049](https://github.com/vtex/faststore/issues/3049)) ([df2a3a5](https://github.com/vtex/faststore/commit/df2a3a55e1960d63351147232009bceea786aca5))

## [3.88.4](https://github.com/vtex/faststore/compare/v3.88.3...v3.88.4) (2025-09-22)

**Note:** Version bump only for package faststore

## [3.88.3](https://github.com/vtex/faststore/compare/v3.88.2...v3.88.3) (2025-09-22)

**Note:** Version bump only for package faststore

## [3.88.2](https://github.com/vtex/faststore/compare/v3.88.1...v3.88.2) (2025-09-19)

### Bug Fixes

- improve error handling in user order query - SFS-2866 ([#3043](https://github.com/vtex/faststore/issues/3043)) ([efb9c08](https://github.com/vtex/faststore/commit/efb9c08a805e0ba9e5d49823b09be475ee1eee04))

## [3.88.1](https://github.com/vtex/faststore/compare/v3.88.0...v3.88.1) (2025-09-19)

### Bug Fixes

- remove facets parameter from validate session ([#3046](https://github.com/vtex/faststore/issues/3046)) ([9516a0f](https://github.com/vtex/faststore/commit/9516a0f9296f94b6123060887914f10f16c2f4e7))

# [3.88.0](https://github.com/vtex/faststore/compare/v3.87.0...v3.88.0) (2025-09-18)

### Features

- [CP-768] adding support for lexical rich text objects ([#3004](https://github.com/vtex/faststore/issues/3004)) ([3e8fdaa](https://github.com/vtex/faststore/commit/3e8fdaa4bb728d2bde038ac96a2045f5d8670744)), closes [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R189](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R189) [/github.com/vtex/faststore/pull/3004/files#diff-fe1a4c11824f3dfcc33af60e6612a2054705df8f7273932db1b5f9c0ed023172R20](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-fe1a4c11824f3dfcc33af60e6612a2054705df8f7273932db1b5f9c0ed023172R20) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R205](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R205) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R98](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R98) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R153](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R153) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R106](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R106) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R119](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R119) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R145](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R145) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R148](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R148) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R149](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R149) [/github.com/vtex/faststore/pull/3004/files#diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R150](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-0b1e74171da3dc2cd19600bd739a8db011c54e9032c01abe19ababa21b1cf947R150) [/github.com/vtex/faststore/pull/3004/files#diff-946e28ce25fa403debb36f7f2bb8bad070f7ddd8586e4dd834649afcf4b529eeR32](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-946e28ce25fa403debb36f7f2bb8bad070f7ddd8586e4dd834649afcf4b529eeR32) [/github.com/vtex/faststore/pull/3004/files#diff-3a4a8bba967d6107c9b71ef5c1a0835620593286a58dc65031f8a29e8584c071R27](https://github.com//github.com/vtex/faststore/pull/3004/files/issues/diff-3a4a8bba967d6107c9b71ef5c1a0835620593286a58dc65031f8a29e8584c071R27)

# [3.87.0](https://github.com/vtex/faststore/compare/v3.86.4...v3.87.0) (2025-09-18)

### Features

- Delivery Promise 2.2 - in stock filter ([#2972](https://github.com/vtex/faststore/issues/2972)) ([7bfb830](https://github.com/vtex/faststore/commit/7bfb8308c76b0914d59875fbe95d3cab6e98eba3))

## [3.86.4](https://github.com/vtex/faststore/compare/v3.86.3...v3.86.4) (2025-09-17)

### Bug Fixes

- `ShippingSimulation` table SFS-2622 ([#3030](https://github.com/vtex/faststore/issues/3030)) ([dfcb924](https://github.com/vtex/faststore/commit/dfcb9245527dd8bf90cd183fed7f556bf8b35a4d))

## [3.86.3](https://github.com/vtex/faststore/compare/v3.86.2...v3.86.3) (2025-09-17)

### Bug Fixes

- add all the path to the plugin API route after the /plugins prefix ([#3042](https://github.com/vtex/faststore/issues/3042)) ([dca59ac](https://github.com/vtex/faststore/commit/dca59ac05ed28a0dbfbbbd9d1d3aa1980f42cf9a))

## [3.86.2](https://github.com/vtex/faststore/compare/v3.86.1...v3.86.2) (2025-09-16)

### Bug Fixes

- update contract URL to remove 'pvt' prefix in OrganizationDrawer… ([#3039](https://github.com/vtex/faststore/issues/3039)) ([6e73b8e](https://github.com/vtex/faststore/commit/6e73b8e024ff66b90dc3ba48dfd53a81a582851b))

## [3.86.1](https://github.com/vtex/faststore/compare/v3.86.0...v3.86.1) (2025-09-16)

### Bug Fixes

- conditionally set href for contract link in OrganizationDrawerHe… ([#3038](https://github.com/vtex/faststore/issues/3038)) ([b076715](https://github.com/vtex/faststore/commit/b076715dafea3173a69e1fc9ef1844f8e4d5e973))

# [3.86.0](https://github.com/vtex/faststore/compare/v3.85.0...v3.86.0) (2025-09-15)

### Features

- ensure pvt route in my account pages SFS-2852 ([#3026](https://github.com/vtex/faststore/issues/3026)) ([93b089a](https://github.com/vtex/faststore/commit/93b089abd3bca04ef8fbdbecc7f81dd00a852987))

# [3.85.0](https://github.com/vtex/faststore/compare/v3.84.5...v3.85.0) (2025-09-15)

### Features

- add organization management permission validation ([#3029](https://github.com/vtex/faststore/issues/3029)) ([67d6125](https://github.com/vtex/faststore/commit/67d61252cba42045a4c225f2cba14656645a1dbb))

## [3.84.5](https://github.com/vtex/faststore/compare/v3.84.4...v3.84.5) (2025-09-15)

### Bug Fixes

- Use `corporateName` in profile page ([#3035](https://github.com/vtex/faststore/issues/3035)) ([663621d](https://github.com/vtex/faststore/commit/663621dcdf0e1e6771a11ab5de4688fdf94cc028)), closes [vtex-sites/faststoreqa.store#864](https://github.com/vtex-sites/faststoreqa.store/issues/864)

## [3.84.4](https://github.com/vtex/faststore/compare/v3.84.3...v3.84.4) (2025-09-15)

**Note:** Version bump only for package faststore

## [3.84.3](https://github.com/vtex/faststore/compare/v3.84.2...v3.84.3) (2025-09-12)

### Bug Fixes

- don't require restart when switching themes ([#3018](https://github.com/vtex/faststore/issues/3018)) ([52afa59](https://github.com/vtex/faststore/commit/52afa59addae3c050786463a4aa39f3390c84971))

## [3.84.2](https://github.com/vtex/faststore/compare/v3.84.1...v3.84.2) (2025-09-12)

### Bug Fixes

- list order pagination page change ([#3031](https://github.com/vtex/faststore/issues/3031)) ([16c5cf7](https://github.com/vtex/faststore/commit/16c5cf7cdc1d494f82f08fd6aff2816ef72aac26))

## [3.84.1](https://github.com/vtex/faststore/compare/v3.84.0...v3.84.1) (2025-09-11)

### Bug Fixes

- Use enhanceSku in allVariantProducts ([#3028](https://github.com/vtex/faststore/issues/3028)) ([c11edcf](https://github.com/vtex/faststore/commit/c11edcf5ac93b6e042e665f3e9e90bdf9a4b3a04))

# [3.84.0](https://github.com/vtex/faststore/compare/v3.83.1...v3.84.0) (2025-09-09)

### Features

- Adds delivery promise badges to product card ([#2994](https://github.com/vtex/faststore/issues/2994)) ([87279c8](https://github.com/vtex/faststore/commit/87279c82a0ba83c9dffc5872b94cead98189dd23))

## [3.83.1](https://github.com/vtex/faststore/compare/v3.83.0...v3.83.1) (2025-09-09)

### Bug Fixes

- search update ([#3015](https://github.com/vtex/faststore/issues/3015)) ([74d3261](https://github.com/vtex/faststore/commit/74d3261267e111801b6e9fd46086c8d289a83d1e))

# [3.83.0](https://github.com/vtex/faststore/compare/v3.82.4...v3.83.0) (2025-09-09)

### Features

- adjust Custom Fields in MyAccountListOrdersTable ([#3003](https://github.com/vtex/faststore/issues/3003)) ([5e3fcf1](https://github.com/vtex/faststore/commit/5e3fcf18f3ce50f7a93d78f0f5f92c447dcdf31a))

## [3.82.4](https://github.com/vtex/faststore/compare/v3.82.3...v3.82.4) (2025-09-08)

### Bug Fixes

- geolocation undefined handling ([#3022](https://github.com/vtex/faststore/issues/3022)) ([ce76372](https://github.com/vtex/faststore/commit/ce76372806abcb8bc82976a5fc3ff17014fb3bf5))

## [3.82.3](https://github.com/vtex/faststore/compare/v3.82.2...v3.82.3) (2025-09-08)

**Note:** Version bump only for package faststore

## [3.82.2](https://github.com/vtex/faststore/compare/v3.82.1...v3.82.2) (2025-09-05)

**Note:** Version bump only for package faststore

## [3.82.1](https://github.com/vtex/faststore/compare/v3.82.0...v3.82.1) (2025-09-05)

### Bug Fixes

- CMS Sync with default contentSource.project ([#3021](https://github.com/vtex/faststore/issues/3021)) ([f223738](https://github.com/vtex/faststore/commit/f2237388b38a527d64b07cd4d5ba4e9c9efd6b8f))

# [3.82.0](https://github.com/vtex/faststore/compare/v3.81.0...v3.82.0) (2025-09-05)

### Features

- Delivery Promise 2.1 - filters by Delivery Option ([#2926](https://github.com/vtex/faststore/issues/2926)) ([d365a5e](https://github.com/vtex/faststore/commit/d365a5ea0da451a58c87fd6bcfd7f49df2c96158)), closes [#2928](https://github.com/vtex/faststore/issues/2928) [#2930](https://github.com/vtex/faststore/issues/2930) [#2937](https://github.com/vtex/faststore/issues/2937)

# 3.81.0 (2025-09-05)

### Bug Fixes

- avoid unnecessary server restarts by moving updateNextConfig to setup only ([#2983](https://github.com/vtex/faststore/issues/2983)) ([b26238e](https://github.com/vtex/faststore/commit/b26238e9484108196b067f135e29e3360eecdaeb)), closes [#2500](https://github.com/vtex/faststore/issues/2500)

### Features

- Allow users to select which CMS builder to use ([#2997](https://github.com/vtex/faststore/issues/2997)) ([3862832](https://github.com/vtex/faststore/commit/3862832aaf366453b8a26844e2c452647a534b4d))

# 3.80.0 (2025-09-04)

### Bug Fixes

- remove SearchShopperResult type definition ([#3017](https://github.com/vtex/faststore/issues/3017)) ([3d914b0](https://github.com/vtex/faststore/commit/3d914b0ab80ce8c06d48b5c95ccc7124bdd2d62e))

### Features

- add shopper phone and email in ordered by card ([#3014](https://github.com/vtex/faststore/issues/3014)) ([31bf49b](https://github.com/vtex/faststore/commit/31bf49bb717f740ad6ff741ce2ae77322ec3f5a6))

## [3.79.1](https://github.com/vtex/faststore/compare/v3.79.0...v3.79.1) (2025-09-04)

**Note:** Version bump only for package faststore

# [3.79.0](https://github.com/vtex/faststore/compare/v3.78.0...v3.79.0) (2025-09-03)

### Features

- Add appkey and apptoken to VtexCommerce and Page components ([#3008](https://github.com/vtex/faststore/issues/3008)) ([e99a132](https://github.com/vtex/faststore/commit/e99a1321ea27ed9baadd87fbce4fd5798a9d0d25))

# [3.78.0](https://github.com/vtex/faststore/compare/v3.77.3...v3.78.0) (2025-09-02)

### Features

- Product Comparison ([#3000](https://github.com/vtex/faststore/issues/3000)) ([2150bee](https://github.com/vtex/faststore/commit/2150bee82e570205421859e14de8416d5e34c545))

## [3.77.3](https://github.com/vtex/faststore/compare/v3.77.2...v3.77.3) (2025-09-01)

### Bug Fixes

- Update search page when changing terms ([#2992](https://github.com/vtex/faststore/issues/2992)) ([90be90f](https://github.com/vtex/faststore/commit/90be90ff8aa29127dbe89d4a9b8512f6d1427f38)), closes [dp-faststore-org/vendemo-dp#74](https://github.com/dp-faststore-org/vendemo-dp/issues/74) [vtex-sites/faststoreqa.store#857](https://github.com/vtex-sites/faststoreqa.store/issues/857)

## [3.77.2](https://github.com/vtex/faststore/compare/v3.77.1...v3.77.2) (2025-08-21)

### Bug Fixes

- validate mutations after offline network ([#2998](https://github.com/vtex/faststore/issues/2998)) ([659605f](https://github.com/vtex/faststore/commit/659605f45ccf53cfb7a6959fe9f9f0fe3f1a6c93))

## [3.77.1](https://github.com/vtex/faststore/compare/v3.77.0...v3.77.1) (2025-08-20)

### Bug Fixes

- use ? operator to get dateRangeFacet ([#2996](https://github.com/vtex/faststore/issues/2996)) ([e67d63d](https://github.com/vtex/faststore/commit/e67d63d1624aba4a5baf880d525487ff482db0c7))

# [3.77.0](https://github.com/vtex/faststore/compare/v3.76.0...v3.77.0) (2025-08-18)

### Features

- Better monorepo support ([#2978](https://github.com/vtex/faststore/issues/2978)) ([c32b23b](https://github.com/vtex/faststore/commit/c32b23baaed5269527661beee7bcde0db9887c36))

# [3.76.0](https://github.com/vtex/faststore/compare/v3.75.1...v3.76.0) (2025-08-14)

### Features

- order list placed by filter-SFS-2702 ([#2988](https://github.com/vtex/faststore/issues/2988)) ([1c9b557](https://github.com/vtex/faststore/commit/1c9b557a3fd2310ca4d1ffb7fd4135f60a44109d))

## [3.75.1](https://github.com/vtex/faststore/compare/v3.75.0...v3.75.1) (2025-08-08)

**Note:** Version bump only for package faststore

# [3.75.0](https://github.com/vtex/faststore/compare/v3.74.0...v3.75.0) (2025-08-07)

### Features

- remove client name and placed by from order list - SFS-2795 ([#2981](https://github.com/vtex/faststore/issues/2981)) ([5368859](https://github.com/vtex/faststore/commit/5368859dc5f0dd742e628c20e427a75e388f2126))

# [3.74.0](https://github.com/vtex/faststore/compare/v3.73.0...v3.74.0) (2025-08-07)

### Features

- add flag --watch-plugins on dev command ([#2880](https://github.com/vtex/faststore/issues/2880)) ([5816538](https://github.com/vtex/faststore/commit/5816538786aff756c8a3f035096dfb35c6530d60)), closes [#2563](https://github.com/vtex/faststore/issues/2563)

# [3.73.0](https://github.com/vtex/faststore/compare/v3.72.1...v3.73.0) (2025-08-07)

### Features

- implement password setting functionality and user email retrieval ([#2957](https://github.com/vtex/faststore/issues/2957)) ([a49aa1b](https://github.com/vtex/faststore/commit/a49aa1b6d55310a64639459b9082530f4a955731))

## [3.72.1](https://github.com/vtex/faststore/compare/v3.72.0...v3.72.1) (2025-08-07)

### Bug Fixes

- Prevent PLPs' specific facets being cleared ([#2977](https://github.com/vtex/faststore/issues/2977)) ([e15ec3e](https://github.com/vtex/faststore/commit/e15ec3e851269d768a632da8683b5345937b66ca)), closes [vtex-sites/faststoreqa.store#853](https://github.com/vtex-sites/faststoreqa.store/issues/853)

# [3.72.0](https://github.com/vtex/faststore/compare/v3.71.0...v3.72.0) (2025-08-05)

### Features

- refresh token - SFS-2462 ([#2936](https://github.com/vtex/faststore/issues/2936)) ([0fc856f](https://github.com/vtex/faststore/commit/0fc856f46ffe800debccd90078564e9ff524e727)), closes [#1](https://github.com/vtex/faststore/issues/1) [#2](https://github.com/vtex/faststore/issues/2)

# [3.71.0](https://github.com/vtex/faststore/compare/v3.70.2...v3.71.0) (2025-08-05)

### Features

- show creation date for first step in status card ([#2971](https://github.com/vtex/faststore/issues/2971)) ([e9a79ac](https://github.com/vtex/faststore/commit/e9a79acf14c7a518cc7e587a8e36eec332e72a08))

## [3.70.2](https://github.com/vtex/faststore/compare/v3.70.1...v3.70.2) (2025-08-05)

### Bug Fixes

- Quick Order typings ([#2974](https://github.com/vtex/faststore/issues/2974)) ([e28c523](https://github.com/vtex/faststore/commit/e28c523bdc83273ad7cbb7d08cfdeb99ad676ede))

## [3.70.1](https://github.com/vtex/faststore/compare/v3.70.0...v3.70.1) (2025-08-04)

### Bug Fixes

- Using SEO product name and description input if available ([#2969](https://github.com/vtex/faststore/issues/2969)) ([590000d](https://github.com/vtex/faststore/commit/590000d63539e0ce476018027a7ed2fdd2589c45)), closes [#2701](https://github.com/vtex/faststore/issues/2701)

# [3.70.0](https://github.com/vtex/faststore/compare/v3.69.1...v3.70.0) (2025-08-01)

### Features

- [CP-407] Add support for rendering components based on their $componentKey ([#2915](https://github.com/vtex/faststore/issues/2915)) ([7e679c4](https://github.com/vtex/faststore/commit/7e679c43976ab7f874b73b53e59bfaf0a4e99483))

## [3.69.1](https://github.com/vtex/faststore/compare/v3.69.0...v3.69.1) (2025-08-01)

### Bug Fixes

- removing unwanted facets on product shelf to prevent duplication… ([#2970](https://github.com/vtex/faststore/issues/2970)) ([6ba3ca0](https://github.com/vtex/faststore/commit/6ba3ca06ecee058bc93ef9fa784a585f0a8c6563))

# [3.69.0](https://github.com/vtex/faststore/compare/v3.68.2...v3.69.0) (2025-07-31)

### Features

- add shopper name data to user order page ([#2967](https://github.com/vtex/faststore/issues/2967)) ([6b2eb05](https://github.com/vtex/faststore/commit/6b2eb05e6590363c1a91ff1e802784606a0b1917))

## [3.68.2](https://github.com/vtex/faststore/compare/v3.68.1...v3.68.2) (2025-07-29)

### Bug Fixes

- cancel order withAutCookie SFS-2684 ([#2954](https://github.com/vtex/faststore/issues/2954)) ([f0e4cca](https://github.com/vtex/faststore/commit/f0e4cca07932d02b884993a7fa7db83489f91ef2))

## [3.68.1](https://github.com/vtex/faststore/compare/v3.68.0...v3.68.1) (2025-07-29)

### Bug Fixes

- B2B session info ([#2950](https://github.com/vtex/faststore/issues/2950)) ([6dcaa88](https://github.com/vtex/faststore/commit/6dcaa880e3b86b44c13402a558e008eddbebe724))

# [3.68.0](https://github.com/vtex/faststore/compare/v3.67.0...v3.68.0) (2025-07-28)

### Features

- Delivery Promise 1.2 - filters by shipping method ([#2784](https://github.com/vtex/faststore/issues/2784)) ([dacf843](https://github.com/vtex/faststore/commit/dacf843c81f19984a01f7a97ff25e3801e41ed07)), closes [#2803](https://github.com/vtex/faststore/issues/2803) [#2826](https://github.com/vtex/faststore/issues/2826) [#2845](https://github.com/vtex/faststore/issues/2845) [#2847](https://github.com/vtex/faststore/issues/2847) [#2851](https://github.com/vtex/faststore/issues/2851) [#2852](https://github.com/vtex/faststore/issues/2852) [#2847](https://github.com/vtex/faststore/issues/2847) [#2872](https://github.com/vtex/faststore/issues/2872) [#2886](https://github.com/vtex/faststore/issues/2886) [#2909](https://github.com/vtex/faststore/issues/2909) [#2916](https://github.com/vtex/faststore/issues/2916) [#2918](https://github.com/vtex/faststore/issues/2918) [#2922](https://github.com/vtex/faststore/issues/2922) [#2887](https://github.com/vtex/faststore/issues/2887) [#2944](https://github.com/vtex/faststore/issues/2944) [#2953](https://github.com/vtex/faststore/issues/2953) [#2956](https://github.com/vtex/faststore/issues/2956) [#2955](https://github.com/vtex/faststore/issues/2955) [#2961](https://github.com/vtex/faststore/issues/2961) [#2962](https://github.com/vtex/faststore/issues/2962)

# [3.67.0](https://github.com/vtex/faststore/compare/v3.66.0...v3.67.0) (2025-07-23)

### Features

- add the host to the client-cms request. SFS-2610 ([#2920](https://github.com/vtex/faststore/issues/2920)) ([119aa88](https://github.com/vtex/faststore/commit/119aa8884c639235b8bd24694e33b28fa14d243f))

# [3.66.0](https://github.com/vtex/faststore/compare/v3.65.2...v3.66.0) (2025-07-23)

### Features

- add mutation to set new password ([#2949](https://github.com/vtex/faststore/issues/2949)) ([f2f3beb](https://github.com/vtex/faststore/commit/f2f3bebfafd9500e3eb2f9d98220f7400ea9fd0e))

## [3.65.2](https://github.com/vtex/faststore/compare/v3.65.1...v3.65.2) (2025-07-22)

### Bug Fixes

- duplicated meta tags ([#2947](https://github.com/vtex/faststore/issues/2947)) ([4934609](https://github.com/vtex/faststore/commit/4934609cca34b1e5e7c843a4bd61fb851e954f03))

## [3.65.1](https://github.com/vtex/faststore/compare/v3.65.0...v3.65.1) (2025-07-17)

### Bug Fixes

- validate cart should consider coupon in marketingData ([#2948](https://github.com/vtex/faststore/issues/2948)) ([ed063f4](https://github.com/vtex/faststore/commit/ed063f4df26178206a91892b59255c8332e65795))

# [3.65.0](https://github.com/vtex/faststore/compare/v3.64.1...v3.65.0) (2025-07-16)

### Features

- my account release 3 ([#2883](https://github.com/vtex/faststore/issues/2883)) ([be2c32a](https://github.com/vtex/faststore/commit/be2c32ae5cb0d892e34a96c2d73b06d31f8af137))

## [3.64.1](https://github.com/vtex/faststore/compare/v3.64.0...v3.64.1) (2025-07-16)

### Bug Fixes

- format date manually on MyAccountSelectedTags to work with user timezone ([#2946](https://github.com/vtex/faststore/issues/2946)) ([3f001ff](https://github.com/vtex/faststore/commit/3f001ff55d4369589428cb569caa205d4d87e1af))

# [3.64.0](https://github.com/vtex/faststore/compare/v3.63.1...v3.64.0) (2025-07-15)

### Features

- add uniqueId field to UserOrder items and update related components ([#2945](https://github.com/vtex/faststore/issues/2945)) ([d48ea5a](https://github.com/vtex/faststore/commit/d48ea5af35a538f7e07c14cf90330b87cf27178a))

## [3.63.1](https://github.com/vtex/faststore/compare/v3.63.0...v3.63.1) (2025-07-15)

### Bug Fixes

- use allowCancellation to validate cancel order button ([#2942](https://github.com/vtex/faststore/issues/2942)) ([1f0f6a9](https://github.com/vtex/faststore/commit/1f0f6a9dc27436b6de63e2aff58a1086d4b2ae2a)), closes [/github.com/vtex/my-orders/blob/ff400736a4b6ea8eb70298c2de26a6e974489fc3/react/pages/CancelOrder.jsx#L116](https://github.com//github.com/vtex/my-orders/blob/ff400736a4b6ea8eb70298c2de26a6e974489fc3/react/pages/CancelOrder.jsx/issues/L116) [/github.com/vtex/my-orders/blob/ff400736a4b6ea8eb70298c2de26a6e974489fc3/react/components/Order/OrderActions.jsx#L41](https://github.com//github.com/vtex/my-orders/blob/ff400736a4b6ea8eb70298c2de26a6e974489fc3/react/components/Order/OrderActions.jsx/issues/L41)

# [3.63.0](https://github.com/vtex/faststore/compare/v3.62.0...v3.63.0) (2025-07-14)

### Features

- add param for custom event ([#2927](https://github.com/vtex/faststore/issues/2927)) ([b73d4da](https://github.com/vtex/faststore/commit/b73d4dad8d22a9eb498e020af6db24a8e8cd16f7)), closes [#parameter_2](https://github.com/vtex/faststore/issues/parameter_2) [#parameter_3](https://github.com/vtex/faststore/issues/parameter_3) [#parameter_2](https://github.com/vtex/faststore/issues/parameter_2) [#parameter_3](https://github.com/vtex/faststore/issues/parameter_3)

# [3.62.0](https://github.com/vtex/faststore/compare/v3.61.0...v3.62.0) (2025-07-11)

### Features

- Allow unavailable items on cart ([#2938](https://github.com/vtex/faststore/issues/2938)) ([309e014](https://github.com/vtex/faststore/commit/309e014f50a0e2d5293b08e6b1b6b0fe6bcfd6b2)), closes [vtex-sites/faststoreqa.store#837](https://github.com/vtex-sites/faststoreqa.store/issues/837)

# [3.61.0](https://github.com/vtex/faststore/compare/v3.60.4...v3.61.0) (2025-07-04)

### Features

- implement CP branch preview support ([#2885](https://github.com/vtex/faststore/issues/2885)) ([a55fe24](https://github.com/vtex/faststore/commit/a55fe24dac70ccfedc6296001bd5c18225affeda)), closes [/github.com/vtex/faststore/pull/2885/files#diff-63a7f8cba93bce2eb5ed6be3a1bcf1fbde76d643b165ae2a1a44cc8765dfb73fR40](https://github.com//github.com/vtex/faststore/pull/2885/files/issues/diff-63a7f8cba93bce2eb5ed6be3a1bcf1fbde76d643b165ae2a1a44cc8765dfb73fR40) [/github.com/vtex/faststore/pull/2885/files#diff-63a7f8cba93bce2eb5ed6be3a1bcf1fbde76d643b165ae2a1a44cc8765dfb73fR250](https://github.com//github.com/vtex/faststore/pull/2885/files/issues/diff-63a7f8cba93bce2eb5ed6be3a1bcf1fbde76d643b165ae2a1a44cc8765dfb73fR250) [/github.com/vtex/faststore/pull/2885/files#diff-8dd0ec358e808043c69af593825ff65e9afe1dd776dad04f15480a45b57a2608L36](https://github.com//github.com/vtex/faststore/pull/2885/files/issues/diff-8dd0ec358e808043c69af593825ff65e9afe1dd776dad04f15480a45b57a2608L36) [/github.com/vtex/faststore/pull/2885/files#diff-6728e613609d08999bccf3fc982a6a61c19d6d8eb08eb4d7adb66f4a6924843dR14](https://github.com//github.com/vtex/faststore/pull/2885/files/issues/diff-6728e613609d08999bccf3fc982a6a61c19d6d8eb08eb4d7adb66f4a6924843dR14) [/github.com/vtex/faststore/pull/2885/files#diff-7c7bcf90ece929b012c8fa7a7b62eac4ab72ca06aa5684add108af699bd62f50R38](https://github.com//github.com/vtex/faststore/pull/2885/files/issues/diff-7c7bcf90ece929b012c8fa7a7b62eac4ab72ca06aa5684add108af699bd62f50R38) [/github.com/vtex/faststore/pull/2885/files#diff-b45ed72491ecc419d59ca49fa8b4fc7a45deb55758a6a401f3c8401c11114227R148](https://github.com//github.com/vtex/faststore/pull/2885/files/issues/diff-b45ed72491ecc419d59ca49fa8b4fc7a45deb55758a6a401f3c8401c11114227R148) [/github.com/vtex/faststore/pull/2885/files#diff-8dd0ec358e808043c69af593825ff65e9afe1dd776dad04f15480a45b57a2608R52](https://github.com//github.com/vtex/faststore/pull/2885/files/issues/diff-8dd0ec358e808043c69af593825ff65e9afe1dd776dad04f15480a45b57a2608R52) [/github.com/vtex/faststore/pull/2885/files#diff-6728e613609d08999bccf3fc982a6a61c19d6d8eb08eb4d7adb66f4a6924843dR22](https://github.com//github.com/vtex/faststore/pull/2885/files/issues/diff-6728e613609d08999bccf3fc982a6a61c19d6d8eb08eb4d7adb66f4a6924843dR22) [/github.com/vtex/faststore/blob/main/packages/core/discovery.config.default.js#L128](https://github.com//github.com/vtex/faststore/blob/main/packages/core/discovery.config.default.js/issues/L128) [/github.com/vtex/faststore/blob/main/packages/core/discovery.config.default.js#L128](https://github.com//github.com/vtex/faststore/blob/main/packages/core/discovery.config.default.js/issues/L128)

## [3.60.4](https://github.com/vtex/faststore/compare/v3.60.3...v3.60.4) (2025-07-04)

### Bug Fixes

- Shipping Simulation table style ([#2925](https://github.com/vtex/faststore/issues/2925)) ([a291826](https://github.com/vtex/faststore/commit/a291826f3806ef906f3a6bf7c3f8d9edec61a661))

## [3.60.3](https://github.com/vtex/faststore/compare/v3.60.2...v3.60.3) (2025-07-02)

**Note:** Version bump only for package faststore

## [3.60.2](https://github.com/vtex/faststore/compare/v3.60.1...v3.60.2) (2025-07-02)

**Note:** Version bump only for package faststore

## [3.60.1](https://github.com/vtex/faststore/compare/v3.60.0...v3.60.1) (2025-06-24)

### Bug Fixes

- search cookie domain ([#2870](https://github.com/vtex/faststore/issues/2870)) ([4bfe976](https://github.com/vtex/faststore/commit/4bfe976324cee3b056af75dbe993900366bc779f))

# [3.60.0](https://github.com/vtex/faststore/compare/v3.59.0...v3.60.0) (2025-06-23)

### Features

- add check for deprecated secret files in build and dev commands ([#2797](https://github.com/vtex/faststore/issues/2797)) ([88f6870](https://github.com/vtex/faststore/commit/88f687080ab7d1f6781e076591ef082f9cfc197a)), closes [/#diff-3b0340e6f408eb23ee2bdd40008c9ca70e2f115de9f8369097574ab4c0b67c2fR9](https://github.com///issues/diff-3b0340e6f408eb23ee2bdd40008c9ca70e2f115de9f8369097574ab4c0b67c2fR9) [/#diff-3b0340e6f408eb23ee2bdd40008c9ca70e2f115de9f8369097574ab4c0b67c2fR30-R32](https://github.com///issues/diff-3b0340e6f408eb23ee2bdd40008c9ca70e2f115de9f8369097574ab4c0b67c2fR30-R32) [/#diff-d107b455dc30a6f411ae4210b2d8e1297f4116ffac62f8c4e4081bebc5a21eddL7-R14](https://github.com///issues/diff-d107b455dc30a6f411ae4210b2d8e1297f4116ffac62f8c4e4081bebc5a21eddL7-R14) [/#diff-d107b455dc30a6f411ae4210b2d8e1297f4116ffac62f8c4e4081bebc5a21eddR148-R149](https://github.com///issues/diff-d107b455dc30a6f411ae4210b2d8e1297f4116ffac62f8c4e4081bebc5a21eddR148-R149)

# [3.59.0](https://github.com/vtex/faststore/compare/v3.58.0...v3.59.0) (2025-06-20)

### Features

- add canCancelOrder flag ([#2914](https://github.com/vtex/faststore/issues/2914)) ([033aadc](https://github.com/vtex/faststore/commit/033aadcf50adadc1a101664533d3e1cbc72017e0))

# [3.58.0](https://github.com/vtex/faststore/compare/v3.57.0...v3.58.0) (2025-06-20)

### Features

- add user validation query and implement access control in MyAccount ([#2899](https://github.com/vtex/faststore/issues/2899)) ([48978bf](https://github.com/vtex/faststore/commit/48978bf90e486b5eaa38ee230e7d8f9a269fb910))

# [3.57.0](https://github.com/vtex/faststore/compare/v3.56.3...v3.57.0) (2025-06-20)

### Features

- show empty state instead of table ([#2913](https://github.com/vtex/faststore/issues/2913)) ([5803953](https://github.com/vtex/faststore/commit/580395323bde2f9f1ca5da222c75dc359ac695a5))

## [3.56.3](https://github.com/vtex/faststore/compare/v3.56.2...v3.56.3) (2025-06-20)

### Bug Fixes

- send all status in only one param ([#2912](https://github.com/vtex/faststore/issues/2912)) ([c9b03e3](https://github.com/vtex/faststore/commit/c9b03e3037ec0d6c6fc247bccad5bc98a9955c6e))

## [3.56.2](https://github.com/vtex/faststore/compare/v3.56.1...v3.56.2) (2025-06-19)

### Bug Fixes

- use window.location.href to apply filters ([#2911](https://github.com/vtex/faststore/issues/2911)) ([3e71577](https://github.com/vtex/faststore/commit/3e71577ac9728ad8911dcbfaea241a0a4bb815ba))

## 3.56.1 (2025-06-19)

### Bug Fixes

- account name ([#2908](https://github.com/vtex/faststore/issues/2908)) ([98e5877](https://github.com/vtex/faststore/commit/98e587770d9b5b2a2250c84377ec3d4a6e14087b))
- redirect order details ([#2910](https://github.com/vtex/faststore/issues/2910)) ([a9b1f59](https://github.com/vtex/faststore/commit/a9b1f59952aff8084f47f6d85fc6d4c3356f5017))

# [3.56.0](https://github.com/vtex/faststore/compare/v3.55.1...v3.56.0) (2025-06-19)

### Features

- add shopper first name to userName in b2b object in session ([#2902](https://github.com/vtex/faststore/issues/2902)) ([4542b5f](https://github.com/vtex/faststore/commit/4542b5f814b2d36f65b922ff594f5e24c913b89d))

## [3.55.1](https://github.com/vtex/faststore/compare/v3.55.0...v3.55.1) (2025-06-18)

### Bug Fixes

- sends geoCoordinates long/lat format to session ([#2904](https://github.com/vtex/faststore/issues/2904)) ([7f2e8e1](https://github.com/vtex/faststore/commit/7f2e8e17b15c188999342df1d5e04342b7aeaa4b))

# [3.55.0](https://github.com/vtex/faststore/compare/v3.54.0...v3.55.0) (2025-06-18)

### Features

- extract error status handling and improve error messages ([#2903](https://github.com/vtex/faststore/issues/2903)) ([26c1eea](https://github.com/vtex/faststore/commit/26c1eea2278ce2364d8bcc45bf8d261e97cb3fa8))

# [3.54.0](https://github.com/vtex/faststore/compare/v3.53.0...v3.54.0) (2025-06-17)

### Features

- add link to order details in MyAccountListOrdersTable ([#2896](https://github.com/vtex/faststore/issues/2896)) ([3186a91](https://github.com/vtex/faststore/commit/3186a91440a889a75a0b702ddc1248caf013156a))

# [3.53.0](https://github.com/vtex/faststore/compare/v3.52.1...v3.53.0) (2025-06-16)

### Features

- sfs 2523 contract name main menu ([#2895](https://github.com/vtex/faststore/issues/2895)) ([60adc92](https://github.com/vtex/faststore/commit/60adc92721a4a9eef6db66d1f7c3b563474b554d))

## [3.52.1](https://github.com/vtex/faststore/compare/v3.52.0...v3.52.1) (2025-06-16)

### Bug Fixes

- Search events params to track conversion ([#2891](https://github.com/vtex/faststore/issues/2891)) ([17510c9](https://github.com/vtex/faststore/commit/17510c942a2b1cbdeeb2cd6a7e39dba43fe73345))

# [3.52.0](https://github.com/vtex/faststore/compare/v3.51.0...v3.52.0) (2025-06-12)

### Features

- **core:** implement my account logout ([#2893](https://github.com/vtex/faststore/issues/2893)) ([797f4a5](https://github.com/vtex/faststore/commit/797f4a5fa66561972531650c87ae9d743c798ab9))

# [3.51.0](https://github.com/vtex/faststore/compare/v3.50.4...v3.51.0) (2025-06-04)

### Features

- list orders custom fields new structure and layout ([#2871](https://github.com/vtex/faststore/issues/2871)) ([6842899](https://github.com/vtex/faststore/commit/68428999e0651a5754164bca41f03e7c1c7d2ed3))

## [3.50.4](https://github.com/vtex/faststore/compare/v3.50.3...v3.50.4) (2025-06-03)

### Bug Fixes

- Add support for `shipping` facet ([#2878](https://github.com/vtex/faststore/issues/2878)) ([dc5f859](https://github.com/vtex/faststore/commit/dc5f859e91f76d3b366e2e8d751d99fdd13bd74e)), closes [vtex-sites/faststoreqa.store#820](https://github.com/vtex-sites/faststoreqa.store/issues/820)

## 3.50.3 (2025-06-02)

**Note:** Version bump only for package faststore

## [3.50.2](https://github.com/vtex/faststore/compare/v3.50.1...v3.50.2) (2025-05-27)

### Bug Fixes

- theme styles import ([#2868](https://github.com/vtex/faststore/issues/2868)) ([91724d7](https://github.com/vtex/faststore/commit/91724d78ee71a000957716e6ebc06ee105d1c024))

## [3.50.1](https://github.com/vtex/faststore/compare/v3.50.0...v3.50.1) (2025-05-27)

**Note:** Version bump only for package faststore

# [3.50.0](https://github.com/vtex/faststore/compare/v3.49.2...v3.50.0) (2025-05-27)

### Features

- sfs 2278 sfs 2518 account order design adjusts ([#2861](https://github.com/vtex/faststore/issues/2861)) ([20dc56c](https://github.com/vtex/faststore/commit/20dc56cd118b942d5ed384f395eaa8fd1365f4e4))

## [3.49.2](https://github.com/vtex/faststore/compare/v3.49.1...v3.49.2) (2025-05-27)

### Reverts

- Revert "chore: updates next from 13.5.8 to 13.5.9" ([f7c199c](https://github.com/vtex/faststore/commit/f7c199c912272412bdbc855ea805f5f2ee56b161))

## 3.49.1 (2025-05-27)

**Note:** Version bump only for package faststore

# [3.49.0](https://github.com/vtex/faststore/compare/v3.48.0...v3.49.0) (2025-05-26)

### Features

- improve validate session requests SFS-2517 ([#2857](https://github.com/vtex/faststore/issues/2857)) ([42a4131](https://github.com/vtex/faststore/commit/42a41319dd5b98d257f0f2121caaf74f1a399f12))

# [3.48.0](https://github.com/vtex/faststore/compare/v3.47.2...v3.48.0) (2025-05-26)

### Features

- list orders custom fields + design improvements SFS-2513 SFS-2515 ([#2854](https://github.com/vtex/faststore/issues/2854)) ([20d5471](https://github.com/vtex/faststore/commit/20d547178f2e2a6ae1a7dde4d4e1b5dcbae5e4d6))

## [3.47.2](https://github.com/vtex/faststore/compare/v3.47.1...v3.47.2) (2025-05-23)

### Bug Fixes

- Prevent `checkDeps` error ([#2864](https://github.com/vtex/faststore/issues/2864)) ([228a56f](https://github.com/vtex/faststore/commit/228a56ffa85bb7eb0663841aa74efe60d0531171))

## [3.47.1](https://github.com/vtex/faststore/compare/v3.47.0...v3.47.1) (2025-05-22)

### Bug Fixes

- search product styles tokens ([#2860](https://github.com/vtex/faststore/issues/2860)) ([e9c672e](https://github.com/vtex/faststore/commit/e9c672ed8697a48931bf6e17af10b79c250d595b))

# [3.47.0](https://github.com/vtex/faststore/compare/v3.46.0...v3.47.0) (2025-05-22)

### Features

- clean up GraphQL types and queries for user orders SFS-2516 ([#2858](https://github.com/vtex/faststore/issues/2858)) ([8ed42d5](https://github.com/vtex/faststore/commit/8ed42d590d0e0557f99ae1fc015f70d71a88a743))

# [3.46.0](https://github.com/vtex/faststore/compare/v3.45.0...v3.46.0) (2025-05-21)

### Features

- userEmail instead of roles in Drawer SFS-2514 ([#2853](https://github.com/vtex/faststore/issues/2853)) ([56f36ba](https://github.com/vtex/faststore/commit/56f36bab29c39b530f5ddc3e734077f69c682e4a))

# 3.45.0 (2025-05-20)

### Features

- my account release 2 ([#2786](https://github.com/vtex/faststore/issues/2786)) ([2a6339c](https://github.com/vtex/faststore/commit/2a6339ce060ff2707a6734f5c4fdae8b4f4c4480))

## [3.44.3](https://github.com/vtex/faststore/compare/v3.44.2...v3.44.3) (2025-05-16)

**Note:** Version bump only for package faststore

## [3.44.2](https://github.com/vtex/faststore/compare/v3.44.1...v3.44.2) (2025-05-14)

### Bug Fixes

- discovery config import ([#2844](https://github.com/vtex/faststore/issues/2844)) ([5986512](https://github.com/vtex/faststore/commit/5986512b7d236ddea056d85ec63acb11e8c27873))

## [3.44.1](https://github.com/vtex/faststore/compare/v3.44.0...v3.44.1) (2025-05-13)

### Bug Fixes

- Revert "fix: Sets domain search cookies" ([#2840](https://github.com/vtex/faststore/issues/2840)) ([44ae6bf](https://github.com/vtex/faststore/commit/44ae6bff88b5113c75faae466286b435b0d0ff5b)), closes [vtex/faststore#2811](https://github.com/vtex/faststore/issues/2811)

# [3.44.0](https://github.com/vtex/faststore/compare/v3.43.0...v3.44.0) (2025-05-13)

### Features

- Delivery Promise - navigation based on shopper location ([#2716](https://github.com/vtex/faststore/issues/2716)) ([d683080](https://github.com/vtex/faststore/commit/d683080b9806bf7587be5ef84d403e30d3969e51)), closes [#2708](https://github.com/vtex/faststore/issues/2708) [#2728](https://github.com/vtex/faststore/issues/2728) [#2739](https://github.com/vtex/faststore/issues/2739) [#2745](https://github.com/vtex/faststore/issues/2745) [#2749](https://github.com/vtex/faststore/issues/2749) [#2750](https://github.com/vtex/faststore/issues/2750) [#2768](https://github.com/vtex/faststore/issues/2768) [#2772](https://github.com/vtex/faststore/issues/2772) [#2775](https://github.com/vtex/faststore/issues/2775) [#2809](https://github.com/vtex/faststore/issues/2809) [#2817](https://github.com/vtex/faststore/issues/2817) [#2824](https://github.com/vtex/faststore/issues/2824) [#2835](https://github.com/vtex/faststore/issues/2835)

# [3.43.0](https://github.com/vtex/faststore/compare/v3.42.0...v3.43.0) (2025-05-12)

### Features

- [CP-432] [CP-433] Adding CP integration as a data source alternative to hCMS ([#2807](https://github.com/vtex/faststore/issues/2807)) ([122e2d9](https://github.com/vtex/faststore/commit/122e2d94cb94a6edc9726a3be8d83e62fa44a51e)), closes [/github.com/vtex/faststore/pull/2807/files#diff-63a7f8cba93bce2eb5ed6be3a1bcf1fbde76d643b165ae2a1a44cc8765dfb73fR141](https://github.com//github.com/vtex/faststore/pull/2807/files/issues/diff-63a7f8cba93bce2eb5ed6be3a1bcf1fbde76d643b165ae2a1a44cc8765dfb73fR141) [/github.com/vtex/faststore/pull/2807/files#diff-8dd0ec358e808043c69af593825ff65e9afe1dd776dad04f15480a45b57a2608R91](https://github.com//github.com/vtex/faststore/pull/2807/files/issues/diff-8dd0ec358e808043c69af593825ff65e9afe1dd776dad04f15480a45b57a2608R91) [/github.com/vtex/faststore/pull/2807/files#diff-63a7f8cba93bce2eb5ed6be3a1bcf1fbde76d643b165ae2a1a44cc8765dfb73fR24](https://github.com//github.com/vtex/faststore/pull/2807/files/issues/diff-63a7f8cba93bce2eb5ed6be3a1bcf1fbde76d643b165ae2a1a44cc8765dfb73fR24)

# [3.42.0](https://github.com/vtex/faststore/compare/v3.41.9...v3.42.0) (2025-05-08)

### Features

- Quick Order feature ([#2831](https://github.com/vtex/faststore/issues/2831)) ([875c6f4](https://github.com/vtex/faststore/commit/875c6f4ad4eb780cfa6f8a7aad445db5b3da2ee6))

## [3.41.9](https://github.com/vtex/faststore/compare/v3.41.8...v3.41.9) (2025-05-01)

### Bug Fixes

- Sets domain search cookies ([#2811](https://github.com/vtex/faststore/issues/2811)) ([83bda9a](https://github.com/vtex/faststore/commit/83bda9a80554f57974e78e7bef1c454dc1bae3a7))

## [3.41.8](https://github.com/vtex/faststore/compare/v3.41.7...v3.41.8) (2025-04-30)

**Note:** Version bump only for package faststore

## [3.41.7](https://github.com/vtex/faststore/compare/v3.41.6...v3.41.7) (2025-04-24)

**Note:** Version bump only for package faststore

## [3.41.6](https://github.com/vtex/faststore/compare/v3.41.5...v3.41.6) (2025-04-24)

### Bug Fixes

- Search page blink ([#2789](https://github.com/vtex/faststore/issues/2789)) ([4fa98be](https://github.com/vtex/faststore/commit/4fa98bee61c7c5ad335afaa4b0572817e8a5124e)), closes [vtex-sites/faststoreqa.store#775](https://github.com/vtex-sites/faststoreqa.store/issues/775)

## [3.41.5](https://github.com/vtex/faststore/compare/v3.41.4...v3.41.5) (2025-04-22)

### Bug Fixes

- Tooltip positions ([#2799](https://github.com/vtex/faststore/issues/2799)) ([2044412](https://github.com/vtex/faststore/commit/20444128fbc609941793aec4472f498233878e6d))

## [3.41.4](https://github.com/vtex/faststore/compare/v3.41.3...v3.41.4) (2025-04-17)

**Note:** Version bump only for package faststore

## [3.41.3](https://github.com/vtex/faststore/compare/v3.41.2...v3.41.3) (2025-04-16)

### Bug Fixes

- Allow control to `Checkbox`'s `checked` attribute ([#2614](https://github.com/vtex/faststore/issues/2614)) ([f0b8f2b](https://github.com/vtex/faststore/commit/f0b8f2bdcda879854c84e99bc3f59844b16fb564))

## [3.41.2](https://github.com/vtex/faststore/compare/v3.41.1...v3.41.2) (2025-04-16)

### Bug Fixes

- add key prop to Component in App for better rendering ([#2793](https://github.com/vtex/faststore/issues/2793)) ([b790bc0](https://github.com/vtex/faststore/commit/b790bc069ee67dfc2907f01b84239c29bbdc83b6))

## [3.41.1](https://github.com/vtex/faststore/compare/v3.41.0...v3.41.1) (2025-04-16)

### Bug Fixes

- log error and properly end response in GraphQL handler ([#2792](https://github.com/vtex/faststore/issues/2792)) ([878923c](https://github.com/vtex/faststore/commit/878923cbecf073b06251c3fcdb79560b9ee6ebc0))

# [3.41.0](https://github.com/vtex/faststore/compare/v3.40.2...v3.41.0) (2025-04-15)

### Features

- explicitly add allowRedirect to IS req ([#2791](https://github.com/vtex/faststore/issues/2791)) ([379d614](https://github.com/vtex/faststore/commit/379d6141dd631da066d54d779512eace1ad63f7a))

## [3.40.2](https://github.com/vtex/faststore/compare/v3.40.1...v3.40.2) (2025-04-15)

### Bug Fixes

- handle invalid requests in `parseRequest` function ([#2790](https://github.com/vtex/faststore/issues/2790)) ([fca3c26](https://github.com/vtex/faststore/commit/fca3c265ecd4d9390775da9d6be014d9b26f40d1))

## [3.40.1](https://github.com/vtex/faststore/compare/v3.40.0...v3.40.1) (2025-04-14)

### Bug Fixes

- term required in `ClientSearchSuggestionsQuery` (useSuggestions) ([#2785](https://github.com/vtex/faststore/issues/2785)) ([17cc81c](https://github.com/vtex/faststore/commit/17cc81c41e6542b16b89053cb543926da67375c2))

# [3.40.0](https://github.com/vtex/faststore/compare/v3.39.0...v3.40.0) (2025-04-11)

### Features

- GA `view_item_list` event only when item is in viewport of `ProductGallery` ([#2771](https://github.com/vtex/faststore/issues/2771)) ([16a4efa](https://github.com/vtex/faststore/commit/16a4efa23b7459a4327df0bc994b96c15f44ee5e))

# [3.39.0](https://github.com/vtex/faststore/compare/v3.38.3...v3.39.0) (2025-04-11)

### Features

- MyAccount redirects using SSR - SFS-2440 ([#2782](https://github.com/vtex/faststore/issues/2782)) ([6f92f41](https://github.com/vtex/faststore/commit/6f92f41e647298734bcc0f503810845c1558fd6f))

## 3.38.3 (2025-04-11)

### Bug Fixes

- properly end response for unsupported HTTP methods in GraphQL API ([#2781](https://github.com/vtex/faststore/issues/2781)) ([58f6caf](https://github.com/vtex/faststore/commit/58f6cafa7946ddd3970994dece423f7fff8e55c8))
- update telemetry configuration to use integer ([#2780](https://github.com/vtex/faststore/issues/2780)) ([8e9900e](https://github.com/vtex/faststore/commit/8e9900e0e1824133f4751415a79e5c8edb70a332))

## [3.38.2](https://github.com/vtex/faststore/compare/v3.38.1...v3.38.2) (2025-04-10)

### Bug Fixes

- returns 4XX error when query not exist ([#2779](https://github.com/vtex/faststore/issues/2779)) ([013454e](https://github.com/vtex/faststore/commit/013454e6b5bcd1f0e6ddb4d5ff49affd664a9209))

## [3.38.1](https://github.com/vtex/faststore/compare/v3.38.0...v3.38.1) (2025-04-10)

**Note:** Version bump only for package faststore

# [3.38.0](https://github.com/vtex/faststore/compare/v3.37.0...v3.38.0) (2025-04-10)

### Features

- only send is query event when url has fuzzy and operator ([#2774](https://github.com/vtex/faststore/issues/2774)) ([c6d722e](https://github.com/vtex/faststore/commit/c6d722e55dde5cab16005505f84448a2070fae78))

# [3.37.0](https://github.com/vtex/faststore/compare/v3.36.0...v3.37.0) (2025-04-10)

### Features

- Add PDP redirects support ([#2777](https://github.com/vtex/faststore/issues/2777)) ([fe76b0e](https://github.com/vtex/faststore/commit/fe76b0ed9f63f393cb54c57cf955be76c1d16cde)), closes [#2583](https://github.com/vtex/faststore/issues/2583) [vtex-sites/faststoreqa.store#764](https://github.com/vtex-sites/faststoreqa.store/issues/764)

# [3.36.0](https://github.com/vtex/faststore/compare/v3.35.1...v3.36.0) (2025-04-09)

### Features

- My Account Menu and Extensibility ([#2761](https://github.com/vtex/faststore/issues/2761)) ([0daf07a](https://github.com/vtex/faststore/commit/0daf07a7fdf524992472d9f9b4a013885aa175a2)), closes [#2729](https://github.com/vtex/faststore/issues/2729) [#2720](https://github.com/vtex/faststore/issues/2720) [#2738](https://github.com/vtex/faststore/issues/2738) [#2752](https://github.com/vtex/faststore/issues/2752)

## [3.35.1](https://github.com/vtex/faststore/compare/v3.35.0...v3.35.1) (2025-04-08)

### Bug Fixes

- multiple view_cart events ([#2770](https://github.com/vtex/faststore/issues/2770)) ([9e8234b](https://github.com/vtex/faststore/commit/9e8234b0e097b7c4a749584e491c556cbdab4a31))

# [3.35.0](https://github.com/vtex/faststore/compare/v3.34.0...v3.35.0) (2025-04-08)

### Features

- add API GraphQL cache control using flags ([#2756](https://github.com/vtex/faststore/issues/2756)) ([8b4dc64](https://github.com/vtex/faststore/commit/8b4dc6485f9e262cc5da47a51c3075715acdb0db))

# [3.34.0](https://github.com/vtex/faststore/compare/v3.33.5...v3.34.0) (2025-04-08)

### Features

- prevents double page_view events ([#2767](https://github.com/vtex/faststore/issues/2767)) ([82fca88](https://github.com/vtex/faststore/commit/82fca888b6d203744ad66e6e009046d3088f42db))

## [3.33.5](https://github.com/vtex/faststore/compare/v3.33.4...v3.33.5) (2025-04-03)

### Bug Fixes

- loading rc with accountName ([#2762](https://github.com/vtex/faststore/issues/2762)) ([d49e996](https://github.com/vtex/faststore/commit/d49e9961884a0d5c1c2a7078f718b4214370de94))

## [3.33.4](https://github.com/vtex/faststore/compare/v3.33.3...v3.33.4) (2025-04-02)

### Bug Fixes

- validate response status before parsing to json ([#2759](https://github.com/vtex/faststore/issues/2759)) ([f10400c](https://github.com/vtex/faststore/commit/f10400cb57aeb85bee71c3d7d38857d7983b6c41))

## [3.33.3](https://github.com/vtex/faststore/compare/v3.33.2...v3.33.3) (2025-04-01)

### Bug Fixes

- handle params and prevents send `page=NaN` or `count=0` to IS ([#2755](https://github.com/vtex/faststore/issues/2755)) ([c0f6e2f](https://github.com/vtex/faststore/commit/c0f6e2f9eef21be1f111f2ca902cae386159c43b))

## [3.33.2](https://github.com/vtex/faststore/compare/v3.33.1...v3.33.2) (2025-04-01)

### Bug Fixes

- adds .end to the catch of api/graphql ([#2754](https://github.com/vtex/faststore/issues/2754)) ([3465adc](https://github.com/vtex/faststore/commit/3465adcac170e4beeeacd5db8bfacdcab3a6b559))

## [3.33.1](https://github.com/vtex/faststore/compare/v3.33.0...v3.33.1) (2025-04-01)

### Bug Fixes

- Encode redirect destination ([#2757](https://github.com/vtex/faststore/issues/2757)) ([bbbcc6b](https://github.com/vtex/faststore/commit/bbbcc6be72112960c41ce70278f9130662bddfe5))

# [3.33.0](https://github.com/vtex/faststore/compare/v3.32.1...v3.33.0) (2025-03-31)

### Features

- loads first page product gallery from Build Time (getStaticProps) + improve number of requests (+) ([#2721](https://github.com/vtex/faststore/issues/2721)) ([9a74405](https://github.com/vtex/faststore/commit/9a74405b53ce31211e2d5a2c61874a535e47d654)), closes [/github.com/vtex/faststore/blob/47fd98ef2e3380bc2b84f5ff7922068d75077d45/packages/core/src/sdk/product/useShouldFetchFirstPage.ts#L3](https://github.com//github.com/vtex/faststore/blob/47fd98ef2e3380bc2b84f5ff7922068d75077d45/packages/core/src/sdk/product/useShouldFetchFirstPage.ts/issues/L3)

## [3.32.1](https://github.com/vtex/faststore/compare/v3.32.0...v3.32.1) (2025-03-28)

### Bug Fixes

- call redirect-evaluate only for pages ([#2748](https://github.com/vtex/faststore/issues/2748)) ([cc5bde1](https://github.com/vtex/faststore/commit/cc5bde1334a4eb1924a645a3587c2b66dd51fb84))

# [3.32.0](https://github.com/vtex/faststore/compare/v3.31.0...v3.32.0) (2025-03-27)

### Features

- Manually disable `hideUnavailableItems` flag for PDP queries ([#2747](https://github.com/vtex/faststore/issues/2747)) ([9022088](https://github.com/vtex/faststore/commit/90220885d1aa3a0213d447207353cf5b9d99be23)), closes [vtex-sites/starter.store#738](https://github.com/vtex-sites/starter.store/issues/738)

# [3.31.0](https://github.com/vtex/faststore/compare/v3.30.1...v3.31.0) (2025-03-26)

### Features

- adds deliveryChannel in shipping simulation ([#2746](https://github.com/vtex/faststore/issues/2746)) ([1dd68ed](https://github.com/vtex/faststore/commit/1dd68ed3465beec511b434258cb2e7ae3a3af214))

## [3.30.1](https://github.com/vtex/faststore/compare/v3.30.0...v3.30.1) (2025-03-25)

**Note:** Version bump only for package faststore

# [3.30.0](https://github.com/vtex/faststore/compare/v3.29.1...v3.30.0) (2025-03-21)

### Features

- Add plugins apis support ([#2664](https://github.com/vtex/faststore/issues/2664)) ([11f2fb7](https://github.com/vtex/faststore/commit/11f2fb718ba4b414d2da09d066711cd6e448b5c0))

## [3.29.1](https://github.com/vtex/faststore/compare/v3.29.0...v3.29.1) (2025-03-21)

### Bug Fixes

- pass cookies to intelligent search requests ([#2740](https://github.com/vtex/faststore/issues/2740)) ([fd4ba80](https://github.com/vtex/faststore/commit/fd4ba806ad37856829b1f737416a2e3aad042b0b))

# [3.29.0](https://github.com/vtex/faststore/compare/v3.28.1...v3.29.0) (2025-03-21)

### Features

- add UTM to orderForm ([#2736](https://github.com/vtex/faststore/issues/2736)) ([e423cef](https://github.com/vtex/faststore/commit/e423cef2992f003b8d8add119cb1847069a1571d)), closes [/github.com/vtex-apps/checkout-graphql/blob/df8f02932e9710fa437cf2c550e98cf9b7dc3726/node/resolvers/items.ts#L152-L157](https://github.com//github.com/vtex-apps/checkout-graphql/blob/df8f02932e9710fa437cf2c550e98cf9b7dc3726/node/resolvers/items.ts/issues/L152-L157)

## [3.28.1](https://github.com/vtex/faststore/compare/v3.28.0...v3.28.1) (2025-03-20)

### Bug Fixes

- PLP layout shift ([#2733](https://github.com/vtex/faststore/issues/2733)) ([ee01257](https://github.com/vtex/faststore/commit/ee01257ad2661527abdd5be28e7064dace19fd8d))

# 3.28.0 (2025-03-20)

### Bug Fixes

- add pnpm-lock.yaml to ignored files in biome.json ([#2737](https://github.com/vtex/faststore/issues/2737)) ([e308698](https://github.com/vtex/faststore/commit/e308698a406e27f0112ff1dc2e83564c42c83d85))

### Features

- add support for VTEX assets loader in image component ([#2731](https://github.com/vtex/faststore/issues/2731)) ([aea7456](https://github.com/vtex/faststore/commit/aea7456aaf0e6aacd0ba64759136c51fd08c642f)), closes [/#diff-4da6f8e98efa58c9a40ce9b654b9bfeecb6813091999cdea3d2408679d1bf3d3R119](https://github.com///issues/diff-4da6f8e98efa58c9a40ce9b654b9bfeecb6813091999cdea3d2408679d1bf3d3R119) [/#diff-73ffbd4b30ea7347ce7cc718527810b0f8b51f897bcf48efdd48fbe36652afdaR10-R15](https://github.com///issues/diff-73ffbd4b30ea7347ce7cc718527810b0f8b51f897bcf48efdd48fbe36652afdaR10-R15) [/#diff-73ffbd4b30ea7347ce7cc718527810b0f8b51f897bcf48efdd48fbe36652afdaR28-R39](https://github.com///issues/diff-73ffbd4b30ea7347ce7cc718527810b0f8b51f897bcf48efdd48fbe36652afdaR28-R39)

# [3.27.0](https://github.com/vtex/faststore/compare/v3.26.1...v3.27.0) (2025-03-20)

### Features

- update next-seo to ^6.6.0 and adjust SEO settings ([#2735](https://github.com/vtex/faststore/issues/2735)) ([75534f4](https://github.com/vtex/faststore/commit/75534f4c95b4d5d02b4b5b5e72b745adee856e62)), closes [/#diff-4da6f8e98efa58c9a40ce9b654b9bfeecb6813091999cdea3d2408679d1bf3d3R120-R121](https://github.com///issues/diff-4da6f8e98efa58c9a40ce9b654b9bfeecb6813091999cdea3d2408679d1bf3d3R120-R121) [/#diff-44cee9f10a52af4534def49e35d22467e888a2689e6f535f4009801be8917cd7R8-R9](https://github.com///issues/diff-44cee9f10a52af4534def49e35d22467e888a2689e6f535f4009801be8917cd7R8-R9) [/#diff-0b810c38f3c138a3d5e44854edefd5eb966617ca84e62f06511f60acc40546c7L74-R74](https://github.com///issues/diff-0b810c38f3c138a3d5e44854edefd5eb966617ca84e62f06511f60acc40546c7L74-R74)

## [3.26.1](https://github.com/vtex/faststore/compare/v3.26.0...v3.26.1) (2025-03-19)

### Bug Fixes

- Prevent whitespaces in Search page's `canonical` ([#2732](https://github.com/vtex/faststore/issues/2732)) ([224435f](https://github.com/vtex/faststore/commit/224435f4316fe0072fb702f3b2a97df0e9599847)), closes [vtex-sites/starter.store#726](https://github.com/vtex-sites/starter.store/issues/726)

# 3.26.0 (2025-03-19)

### Features

- Add SEO specifics for PDP ([#2730](https://github.com/vtex/faststore/issues/2730)) ([f2a0420](https://github.com/vtex/faststore/commit/f2a0420d6af360e2668641b38d4eae71419b1d72)), closes [vtex-sites/starter.store#724](https://github.com/vtex-sites/starter.store/issues/724)

## [3.25.11](https://github.com/vtex/faststore/compare/v3.25.10...v3.25.11) (2025-03-17)

**Note:** Version bump only for package faststore

## [3.25.10](https://github.com/vtex/faststore/compare/v3.25.9...v3.25.10) (2025-03-11)

### Bug Fixes

- override to use core breadcrumb component ([#2715](https://github.com/vtex/faststore/issues/2715)) ([7bb499b](https://github.com/vtex/faststore/commit/7bb499b7d7edd1a5959f1f3e7cd8399ef0cb71be))

## [3.25.9](https://github.com/vtex/faststore/compare/v3.25.8...v3.25.9) (2025-03-10)

**Note:** Version bump only for package faststore

## [3.25.8](https://github.com/vtex/faststore/compare/v3.25.7...v3.25.8) (2025-03-10)

### Bug Fixes

- Adds back SKUMatrix to PDP ([#2699](https://github.com/vtex/faststore/issues/2699)) ([90c8c04](https://github.com/vtex/faststore/commit/90c8c04be0c11a68bd0665cfe895d48ed9a9cd50))

## [3.25.7](https://github.com/vtex/faststore/compare/v3.25.6...v3.25.7) (2025-03-10)

### Bug Fixes

- Get offer url only if `enableClientOffer` is enabled ([#2680](https://github.com/vtex/faststore/issues/2680)) ([4d44454](https://github.com/vtex/faststore/commit/4d4445453abf03b2c450d81670fce01ef3a1c9c7))

## [3.25.6](https://github.com/vtex/faststore/compare/v3.25.5...v3.25.6) (2025-03-07)

### Bug Fixes

- Breadcrumb display and it style ([#2714](https://github.com/vtex/faststore/issues/2714)) ([d4f146d](https://github.com/vtex/faststore/commit/d4f146dc4b4570b1bbd6af16a84f68a1cdeab000))

## [3.25.5](https://github.com/vtex/faststore/compare/v3.25.4...v3.25.5) (2025-03-07)

### Bug Fixes

- Do not include similar categories in the breadcrumb list ([#2711](https://github.com/vtex/faststore/issues/2711)) ([c058011](https://github.com/vtex/faststore/commit/c058011e79ef451d2445488f67a1a058155505de))

## [3.25.4](https://github.com/vtex/faststore/compare/v3.25.3...v3.25.4) (2025-03-07)

### Bug Fixes

- ClientShippingSimulationQuery being called multiple times ([#2710](https://github.com/vtex/faststore/issues/2710)) ([5a85c10](https://github.com/vtex/faststore/commit/5a85c10166110e081992a65f7b6798e304f87c41))

## [3.25.3](https://github.com/vtex/faststore/compare/v3.25.2...v3.25.3) (2025-03-07)

### Bug Fixes

- Product Details' Buy Button excessive state reset ([#2712](https://github.com/vtex/faststore/issues/2712)) ([a84fdde](https://github.com/vtex/faststore/commit/a84fdde93f3a0b61f8a75bcc87143a03d864d768))

## [3.25.2](https://github.com/vtex/faststore/compare/v3.25.1...v3.25.2) (2025-03-06)

### Bug Fixes

- `Newsletter` section behaviour - SFS-2265 ([#2703](https://github.com/vtex/faststore/issues/2703)) ([7f7e98a](https://github.com/vtex/faststore/commit/7f7e98a82aef0c190f47b29b09e0ce7146d81873))

## [3.25.1](https://github.com/vtex/faststore/compare/v3.25.0...v3.25.1) (2025-02-28)

**Note:** Version bump only for package faststore

# [3.25.0](https://github.com/vtex/faststore/compare/v3.24.1...v3.25.0) (2025-02-28)

### Features

- Add `category`, `mainEntityOfPage` and `[@id](https://github.com/id)` to Product structured data ([#2694](https://github.com/vtex/faststore/issues/2694)) ([1e9f81e](https://github.com/vtex/faststore/commit/1e9f81eb85ad4d40f64181967940ef629d979a4a))

## [3.24.1](https://github.com/vtex/faststore/compare/v3.24.0...v3.24.1) (2025-02-26)

### Bug Fixes

- removes MissingContentError checks in getPage ([#2704](https://github.com/vtex/faststore/issues/2704)) ([0c75ea0](https://github.com/vtex/faststore/commit/0c75ea05b0d3c8ee62daa988c80152ba1464755c))

# [3.24.0](https://github.com/vtex/faststore/compare/v3.23.0...v3.24.0) (2025-02-26)

### Features

- Multiple global content types ([#2668](https://github.com/vtex/faststore/issues/2668)) ([8555310](https://github.com/vtex/faststore/commit/85553101b1d8f3ec510259007ff1d594ec33c338))

# [3.23.0](https://github.com/vtex/faststore/compare/v3.22.3...v3.23.0) (2025-02-26)

### Features

- adds `productTitle` and `metaTagDescription` from IS as SEO data from the PDP - SFS-2252 ([#2701](https://github.com/vtex/faststore/issues/2701)) ([ca368a0](https://github.com/vtex/faststore/commit/ca368a03f47a8c211baab2810d8057c87f3d854f))

## [3.22.3](https://github.com/vtex/faststore/compare/v3.22.2...v3.22.3) (2025-02-24)

### Bug Fixes

- add yarn to volta config ([#2698](https://github.com/vtex/faststore/issues/2698)) ([421bdca](https://github.com/vtex/faststore/commit/421bdca9105bd6f31e6f15db55192827ba8e6dfc))

## 3.22.2 (2025-02-20)

### Bug Fixes

- Removes CI invalid input ([#2689](https://github.com/vtex/faststore/issues/2689)) ([30ea4b5](https://github.com/vtex/faststore/commit/30ea4b5d38fee5f9aacda60c0bd3b3296875864c))
- Removes url image as required field for Organization ([#2697](https://github.com/vtex/faststore/issues/2697)) ([f325a28](https://github.com/vtex/faststore/commit/f325a28764767fdd6b92d22ef06703a78afdf1a6))

## [3.22.1](https://github.com/vtex/faststore/compare/v3.22.0...v3.22.1) (2025-02-18)

**Note:** Version bump only for package faststore

# [3.22.0](https://github.com/vtex/faststore/compare/v3.21.0...v3.22.0) (2025-02-18)

### Features

- add textareafield component ([#2641](https://github.com/vtex/faststore/issues/2641)) ([5e8dbf3](https://github.com/vtex/faststore/commit/5e8dbf392ee32feede0cdc6174c526a10ce19a22)), closes [PR#2640](https://github.com/PR/issues/2640)

# [3.21.0](https://github.com/vtex/faststore/compare/v3.20.0...v3.21.0) (2025-02-18)

### Features

- empty search with global sections ([#2690](https://github.com/vtex/faststore/issues/2690)) ([56c67d8](https://github.com/vtex/faststore/commit/56c67d8847f5b7c1c8d1d693a70c2f80c48f6c2a))

# [3.20.0](https://github.com/vtex/faststore/compare/v3.19.0...v3.20.0) (2025-02-18)

### Features

- add tooltip component ([#2644](https://github.com/vtex/faststore/issues/2644)) ([ed1826d](https://github.com/vtex/faststore/commit/ed1826d86751b3304f8297432facbe795ae6e91f))

# [3.19.0](https://github.com/vtex/faststore/compare/v3.18.0...v3.19.0) (2025-02-18)

### Features

- Adding organization structured data json ([#2623](https://github.com/vtex/faststore/issues/2623)) ([c97f437](https://github.com/vtex/faststore/commit/c97f4371b694bb55e812c866154e4ed3e594f868))

# [3.18.0](https://github.com/vtex/faststore/compare/v3.17.0...v3.18.0) (2025-02-17)

### Features

- create modal footer compound component ([#2672](https://github.com/vtex/faststore/issues/2672)) ([1a55c95](https://github.com/vtex/faststore/commit/1a55c95f6a2a6cf356647999befab9ba3897c8e7))

# [3.17.0](https://github.com/vtex/faststore/compare/v3.16.0...v3.17.0) (2025-02-17)

### Features

- create textarea component ([#2640](https://github.com/vtex/faststore/issues/2640)) ([15271ca](https://github.com/vtex/faststore/commit/15271cadb0d526ac5a1322a33b57d78635a9976d))

# [3.16.0](https://github.com/vtex/faststore/compare/v3.15.3...v3.16.0) (2025-02-13)

### Features

- add rating field ([#2636](https://github.com/vtex/faststore/issues/2636)) ([f6ab024](https://github.com/vtex/faststore/commit/f6ab024ca606a5f3c59732df02c933063187124a)), closes [PR#2635](https://github.com/PR/issues/2635)

## 3.15.3 (2025-02-13)

### Bug Fixes

- attempts to run publish directly in ci ([#2683](https://github.com/vtex/faststore/issues/2683)) ([44bb50d](https://github.com/vtex/faststore/commit/44bb50d0f03285cb3e48284004675a81385ade9b))

## [3.15.2](https://github.com/vtex/faststore/compare/v3.15.1...v3.15.2) (2025-02-05)

### Bug Fixes

- align ts versions ([#2673](https://github.com/vtex/faststore/issues/2673)) ([64035df](https://github.com/vtex/faststore/commit/64035df4d15334fffe66b55d81f475449bc7839e))

## [3.15.1](https://github.com/vtex/faststore/compare/v3.15.0...v3.15.1) (2025-02-04)

### Bug Fixes

- adds revalidate as false when not experimental ([#2671](https://github.com/vtex/faststore/issues/2671)) ([75331e0](https://github.com/vtex/faststore/commit/75331e0008cf41a70b3ab0f47a6fd28f85fd1a84))

# 3.15.0 (2025-02-04)

### Bug Fixes

- update lock file ([#2670](https://github.com/vtex/faststore/issues/2670)) ([12a440d](https://github.com/vtex/faststore/commit/12a440d2b30e37a4bb6ddc933b5a19b20d11c6a4))

### Features

- Offer SDK ([#2575](https://github.com/vtex/faststore/issues/2575)) ([f4e11ac](https://github.com/vtex/faststore/commit/f4e11ac68ae4afd79a1a89c122155e18bc452ad5))

## [3.14.3](https://github.com/vtex/faststore/compare/v3.14.2...v3.14.3) (2025-02-04)

### Bug Fixes

- remove unnecessary colon ([#2669](https://github.com/vtex/faststore/issues/2669)) ([b0475c3](https://github.com/vtex/faststore/commit/b0475c38fe71a1ef2930cd58445c2387794d5066))

## 3.14.2 (2025-02-03)

**Note:** Version bump only for package faststore

## [3.14.1](https://github.com/vtex/faststore/compare/v3.14.0...v3.14.1) (2025-02-03)

**Note:** Version bump only for package faststore

# [3.14.0](https://github.com/vtex/faststore/compare/v3.13.1...v3.14.0) (2025-02-03)

### Features

- add h1 in EmptySearch component ([#2659](https://github.com/vtex/faststore/issues/2659)) ([76088bb](https://github.com/vtex/faststore/commit/76088bb166cf0cf8ebbb22558961dc1484daa4b4))

## 3.13.1 (2025-01-31)

### Bug Fixes

- husky config ([#2661](https://github.com/vtex/faststore/issues/2661)) ([38ffbaf](https://github.com/vtex/faststore/commit/38ffbaf1b8c68609dc9a8c44437984e362761c60))

# [3.13.0](https://github.com/vtex/faststore/compare/v3.12.1...v3.13.0) (2025-01-31)

### Features

- enables search seo `noFollow` from config ([#2656](https://github.com/vtex/faststore/issues/2656)) ([96ba214](https://github.com/vtex/faststore/commit/96ba2142c9255a67456e95f0600f21eb60681441))

## [3.12.1](https://github.com/vtex/faststore/compare/v3.12.0...v3.12.1) (2025-01-30)

**Note:** Version bump only for package faststore

# [3.12.0](https://github.com/vtex/faststore/compare/v3.11.4...v3.12.0) (2025-01-29)

### Features

- enables search page seo `noIndex` from config ([#2652](https://github.com/vtex/faststore/issues/2652)) ([31c61a6](https://github.com/vtex/faststore/commit/31c61a65ad1774f19c53e7b2ce7af157d24434d9))

## [3.11.4](https://github.com/vtex/faststore/compare/v3.11.3...v3.11.4) (2025-01-29)

**Note:** Version bump only for package faststore

## [3.11.3](https://github.com/vtex/faststore/compare/v3.11.2...v3.11.3) (2025-01-29)

**Note:** Version bump only for package faststore

## [3.11.2](https://github.com/vtex/faststore/compare/v3.11.1...v3.11.2) (2025-01-29)

**Note:** Version bump only for package faststore

## [3.11.1](https://github.com/vtex/faststore/compare/v3.11.0...v3.11.1) (2025-01-29)

**Note:** Version bump only for package faststore

# [3.11.0](https://github.com/vtex/faststore/compare/v3.10.0...v3.11.0) (2025-01-29)

### Features

- search page with SSR ([#2619](https://github.com/vtex/faststore/issues/2619)) ([6fd2d0d](https://github.com/vtex/faststore/commit/6fd2d0d5e92f0922f8d97237d9d04a7eadc5e894))

# [3.10.0](https://github.com/vtex/faststore/compare/v3.9.3...v3.10.0) (2025-01-29)

### Features

- add `title` and `description` templates for product listing pages ([#2643](https://github.com/vtex/faststore/issues/2643)) ([00221d9](https://github.com/vtex/faststore/commit/00221d98439b693af3c2c0082ec7ef600637e19e))

## [3.9.3](https://github.com/vtex/faststore/compare/v3.9.2...v3.9.3) (2025-01-28)

### Bug Fixes

- **sdk:** safari rendering ([#2642](https://github.com/vtex/faststore/issues/2642)) ([39746cd](https://github.com/vtex/faststore/commit/39746cd6094ca1f3f08918b88c20c47d87dadd19))

## [3.9.2](https://github.com/vtex/faststore/compare/v3.9.1...v3.9.2) (2025-01-27)

**Note:** Version bump only for package faststore

## [3.9.1](https://github.com/vtex/faststore/compare/v3.9.0...v3.9.1) (2025-01-27)

### Bug Fixes

- **api:** Use collection `name` when `title` isn't available ([#2625](https://github.com/vtex/faststore/issues/2625)) ([236bb3c](https://github.com/vtex/faststore/commit/236bb3cffb5ca58b2393c618e03ce2545f5fab71))

# 3.9.0 (2025-01-22)

### Features

- Adds Plugins feature ([#2563](https://github.com/vtex/faststore/issues/2563)) ([83c1bf9](https://github.com/vtex/faststore/commit/83c1bf904f744842060e0dfdb7449406800df157))

# [3.8.0](https://github.com/vtex/faststore/compare/v3.7.0...v3.8.0) (2025-01-15)

### Features

- load out of viewport sections after TTI ([#2604](https://github.com/vtex/faststore/issues/2604)) ([98f8109](https://github.com/vtex/faststore/commit/98f8109d406150edf8172a4b8f8e3d4f39f28362))

# [3.7.0](https://github.com/vtex/faststore/compare/v3.6.0...v3.7.0) (2025-01-15)

### Features

- adds SKUMatrix component ([#2588](https://github.com/vtex/faststore/issues/2588)) ([0d7db56](https://github.com/vtex/faststore/commit/0d7db567be1e7b9b9375580b0a8cf665ee69d1c0))

# [3.6.0](https://github.com/vtex/faststore/compare/v3.5.1...v3.6.0) (2025-01-13)

### Features

- Consider order number from Checkout cookie ([#2592](https://github.com/vtex/faststore/issues/2592)) ([b1198db](https://github.com/vtex/faststore/commit/b1198db94b065f5ad4ab742a717c1b43030c22dd))

## [3.5.1](https://github.com/vtex/faststore/compare/v3.5.0...v3.5.1) (2025-01-09)

### Bug Fixes

- Reset infinite scroll if search's total pages is less than current state's total pages ([#2610](https://github.com/vtex/faststore/issues/2610)) ([7faedd2](https://github.com/vtex/faststore/commit/7faedd2ac636a354f0d6c3160309d5d1245ff27b))

# 3.5.0 (2025-01-09)

### Bug Fixes

- revert the commit ccfbac80a8694b8e674c4657d51e3478ff2605bd ([#2609](https://github.com/vtex/faststore/issues/2609)) ([49679ae](https://github.com/vtex/faststore/commit/49679ae3a735f7fa29d716b6e9f6d4941d73a647))

### Features

- Dynamically import `BreadcrumbBase` internal components ([#2611](https://github.com/vtex/faststore/issues/2611)) ([0992d10](https://github.com/vtex/faststore/commit/0992d10f0a12b54cd79403720abc0198a4d8f3e2))

## 3.4.4 (2024-12-20)

### Bug Fixes

- removes `useUI()` dependents sections from `LazyLoadingSection` ([#2602](https://github.com/vtex/faststore/issues/2602)) ([1953438](https://github.com/vtex/faststore/commit/1953438b29ec0081f0dc12fe73a06cd10225a8e8))

## 3.4.3 (2024-12-20)

**Note:** Version bump only for package faststore

## 3.4.2 (2024-12-20)

**Note:** Version bump only for package faststore

## 3.4.1 (2024-12-20)

**Note:** Version bump only for package faststore

# [3.4.0](https://github.com/vtex/faststore/compare/v3.3.0...v3.4.0) (2024-12-19)

### Features

- handle RC Events ([#2567](https://github.com/vtex/faststore/issues/2567)) ([486563d](https://github.com/vtex/faststore/commit/486563dd6e15a04686c99bcfaea6f216520255c9))

# [3.3.0](https://github.com/vtex/faststore/compare/v3.2.1...v3.3.0) (2024-12-18)

### Features

- `Filter` with next/dynamic and lazy import ([#2596](https://github.com/vtex/faststore/issues/2596)) ([73e5496](https://github.com/vtex/faststore/commit/73e54965e656f848c20865cd2760158d634bb0c0))

## [3.2.1](https://github.com/vtex/faststore/compare/v3.2.0...v3.2.1) (2024-12-16)

**Note:** Version bump only for package faststore

# [3.2.0](https://github.com/vtex/faststore/compare/v3.1.4...v3.2.0) (2024-12-16)

### Features

- add new redirects feature ([#2583](https://github.com/vtex/faststore/issues/2583)) ([4624a5d](https://github.com/vtex/faststore/commit/4624a5d101fccc40788c362ab744f250386a8d4d))

## [3.1.4](https://github.com/vtex/faststore/compare/v3.1.3...v3.1.4) (2024-12-16)

**Note:** Version bump only for package faststore

## 3.1.3 (2024-12-13)

**Note:** Version bump only for package faststore

## [3.1.2](https://github.com/vtex/faststore/compare/v3.1.1...v3.1.2) (2024-12-11)

### Bug Fixes

- **sdk:** page view event trigger ([#2586](https://github.com/vtex/faststore/issues/2586)) ([3988760](https://github.com/vtex/faststore/commit/398876013a293302f9a802b93f0f0880cfe32acb))

## [3.1.1](https://github.com/vtex/faststore/compare/v3.1.0...v3.1.1) (2024-12-09)

### Bug Fixes

- `Sentinel` rendering and wrong PLP's pagination behavior ([#2585](https://github.com/vtex/faststore/issues/2585)) ([ea59e77](https://github.com/vtex/faststore/commit/ea59e77fccee7866bd4e44b73e855dd5cee4ba6e)), closes [vtex-sites/starter.store#630](https://github.com/vtex-sites/starter.store/issues/630)

# [3.1.0](https://github.com/vtex/faststore/compare/v3.0.160...v3.1.0) (2024-12-09)

### Features

- add ads label product card ([#2582](https://github.com/vtex/faststore/issues/2582)) ([ae6f655](https://github.com/vtex/faststore/commit/ae6f6558dd76fb2061fa5992e5cea5bcd2142ac5))

## 3.0.160 (2024-12-09)

### Features

- generate semantic release from the commit merged into main ([#2576](https://github.com/vtex/faststore/issues/2576)) ([9b45140](https://github.com/vtex/faststore/commit/9b45140cc25a04eb9168fa98c523b0419937da4c))
